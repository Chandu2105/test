const config = {
    server: 'PG', //Please enter 'PG' for postgres server and 'MSSQL' for SQL server

    //to connect to postgresql server hosted on openshift
    configPg: {
        user: 'postgres',
        database: 'DOFIntegrated',
        password: 'postgres',
        port: parseInt(process.env.PG_PORT) || 5432,
        host: process.env.PG_HOST || 'postgresql.crems.svc'
    }
}


module.exports = config;
