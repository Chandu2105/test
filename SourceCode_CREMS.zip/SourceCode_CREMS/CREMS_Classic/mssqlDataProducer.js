var http = require("http");
var request = require('request');
var mssql = require('mssql');

//Blade3
//var config = {"userName":"sa","password":"Infy123+","server":"blrkecblade3.ad.infosys.com","db":"HOEC_CREMS"};

//Divya system
// var config = {"userName":"sa","password":"Infy123+","server":"192.168.137.87","db":"HOEC_CREMS_V2"};
 
//Blade1
 //var config = {"userName":"dbadmin","password":"Infy123+","server":"blrkecblade1.ad.infosys.com","db":"CREMSTrial"};

 //Aishwarya
 //var config = {"userName":"sa","password":"Infy123+","server":"BLRKEC334427D.ad.infosys.com","db":"DOFIntegrated"};
 var config = {"userName":"sa","password":"crems@123","server":"mssql-server.crems.svc.cluster.local","db":"DOFIntegrated"};

//darshini
//var config = {"userName":"sa","password":"Infy123+","server":"blrkec350909d","db":"HOEC_CREMS_V2"};

var connectorUrl = "mssql://"+config.userName+":"+config.password+"@"+config.server+"/"+config.db+"?requestTimeout=180000";
var moment = require('moment');

var bcrypt = require("bcrypt-nodejs");
var salt = "$2a$10$zjS5xAW3/ar81RUgFzryOeIJywPIJMKfhsuRXweIfnsGcqbhnUmYW";

//Blade3
//var basePath = "http://blrkecblade3:8972";

//Divya system
//var basePath = "http://192.168.137.87:8933";

//Blade1
 //var basePath = "http://blrkecblade1:8972";

//darshini
//var basePath = "http://blrkec350909d:8944";

//Aishwarya
var basePath = "http://BLRKEC334427D:8933";

var pmPath = "http://BLRKEC334427D:8040";

var areas = [];
var assets = [];
var rigCategory = [];
var rigClass = [];
var rigCode = [];
var uom = [];
var rigType = [];
var wellStatus = [];
var userId = [];
var country = [];
var county = [];
var depthDatumType = [];
var dropDownConfig = {};
var parameterList = {};
//var dropDownList = [];
var configurationTables = {};
var sensorGraphs = {};

var required = ["UOM","Rig Category","Rig Class","Rig Code","Rig Type","User ID","Well Status","Country","County","Depth Datum Type","Asset","Area"];

var listOfValues = {};
mssql.connect(connectorUrl).then(function(){
	console.log('Connected...');
	//to get the values for the sidebar dropdown in dashboard
	var getDropDownMenu=function(){
		return new Promise(function (fulfill, reject){
			//if(dropDownList.length==0){
				new mssql.Request().query('SELECT ass.ASSET_ID AS "AssetId",ass.ASSET_NAME AS "AssetName",a.AREA_ID, a.PREFERRED_NAME, w.UWI, w.WELL_NAME, w.SURFACE_LATITUDE, w.SURFACE_LONGITUDE,e.DESCRIPTION,'+
					' w.COUNTRY, w.ASSET_ID, r.RIG_ID, r.RIG_NAME, r.RIG_TYPE, e.EQUIPMENT_ID, e.EQUIPMENT_NAME'+
					' FROM ASSET ass'+
					' JOIN ASSET_AREA_MAP aam ON(aam.ASSET_ID = ass.ASSET_ID)'+
					' JOIN AREA a ON(a.AREA_ID = aam.AREA_ID)'+
					' JOIN WELL w ON (a.AREA_ID = w.AREA_ID AND w.ACTIVE = 1)'+
					' JOIN RIG_WELL_MAP rm ON (w.UWI = rm.UWI AND rm.ACTIVE = 1)'+
					' JOIN RIG r ON (r.RIG_ID = rm.RIG_ID AND r.ACTIVE = 1)'+
					' JOIN RIG_EQUIPMENT re ON (re.RIG_ID = r.RIG_ID AND re.ACTIVE = 1)'+
					// ' JOIN RIG_USER_ROLE_MAP rurm ON (rurm.RIG_ID = re.RIG_ID)'+
					' JOIN EQUIPMENT e ON (e.EQUIPMENT_ID = re.EQUIPMENT_ID AND e.ACTIVE = 1)'+
					' where e.TENANT_ID = 1 ORDER BY a.AREA_ID, r.RIG_NAME, e.EQUIPMENT_NAME')
					.then(function(recordset){
					//dropDownList = recordset;
					return fulfill(recordset);
				}).catch(function(err){
					
					return reject(err);
				})
			// }else{
			// 	return fulfill(dropDownList);
			// }
		});
	}
	exports.getDropDownMenu=getDropDownMenu;

	//to fetch Specifications
	var getGensetSpecifications=function(type){
		return new Promise(function(fulfill,reject){
				new mssql.Request().query('Select eai.EQUIP_ATTR, eai.ATTR_VALUE'
										+' from EQUIPMENT_ADDITIONAL_INFORMATION eai'
										+' where eai.EQUIPMENT_ID='+type).then(function(recordset){
					return fulfill(recordset);
				}).catch(function(err){
					return reject(err);
				});
		});
	};

	exports.getGensetSpecifications=getGensetSpecifications;

	//to fetch Parameters Data
	var getGensetParameters=function(type){
		return new Promise(function(fulfill,reject){
			var topRows=200;
			new mssql.Request().query('SELECT top 200 ema.ATTR_VALUE,eds.SPEC_DESC,ema.MEASURED_DATE, re.EQUIPMENT_ID, ppdm.UOM_QUANTITY_TYPE, eds.MIN_VALUE, eds.MAX_VALUE'
									+' FROM EQUIPMENT_MEASUREMENT_ATTRIBUTE ema'
									+' JOIN EQUIPMENT_DESIGN_SPEC eds ON ema.ATTR_ID = eds.ATTR_ID AND eds.EQUIPMENT_ID = '+type
									+' join PPDM_UNIT_OF_MEASURE ppdm ON(ppdm.UOM_ID= eds.REFERENCE_VALUE_UOM)'
									+' JOIN RIG_EQUIPMENT re ON ema.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID AND re.EQUIPMENT_ID = '+type
								+' where ema.TENANT_ID=1 order by ema.MEASURED_DATE desc , eds.SPEC_DESC asc').then(function(recordset){
											
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
			});
		});
	};

	exports.getGensetParameters=getGensetParameters;

	//get current state of equipment for displaying real time state in equipment page
	var getEquipmentState=function(id){
		return new Promise(function(fulfill,reject){
			new mssql.Request().query('SELECT DESCRIPTION,EQUIP_STATUS_ID FROM EQUIPMENT WHERE EQUIPMENT_ID = '+id).then(function(recordset){			
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
			});
		});
	};

	exports.getEquipmentState=getEquipmentState;

	//to get all the maintenance data
	var getMaintenanceScheduleData=function(type){
		return new Promise(function(fulfill,reject){
			var queryString = ' select ABBREVIATION as Type, MAX(end_date) as last_1, max(start_date) as next_1, max(remark) as REMARK'+
								'  from (select emt.ABBREVIATION, em.ACTUAL_END_DATE as end_date, null AS start_date, em.REMARK as remark,'+
								'  RANK() over (PARTITION BY emt.ABBREVIATION order by em.ACTUAL_END_DATE DESC ) AS Rank_1'+
								'  from EQUIPMENT_MAINTAIN em'+
								'  join EQUIPMENT_MAINT_TYPE emt on (em.MAINT_TYPE_ID = emt.MAINT_TYPE_ID AND em.MAINTAIN_STATUS_ID = 2001)'+
								'  join RIG_EQUIPMENT re on re.RIG_EQUIPMENT_ID= em.RIG_EQUIPMENT_ID'+
								'  where re.EQUIPMENT_ID = '+type+
								'  and CAST(em.ACTUAL_END_DATE AS DATE) <= CAST(GETUTCDATE() AS DATE) and em.TENANT_ID = 1'+
								'  union'+
								'  select emt.ABBREVIATION, null as end_date, em.SCHEDULED_START_DATE as start_date, null as remark, '+
								'  RANK() over (PARTITION BY emt.ABBREVIATION order by em.SCHEDULED_START_DATE ASC) AS Rank_1'+
								'  from EQUIPMENT_MAINTAIN em'+
								'  join EQUIPMENT_MAINT_TYPE emt on (em.MAINT_TYPE_ID = emt.MAINT_TYPE_ID AND em.MAINTAIN_STATUS_ID = 2000)'+
								'  join RIG_EQUIPMENT re on re.RIG_EQUIPMENT_ID= em.RIG_EQUIPMENT_ID'+
								'  where re.EQUIPMENT_ID = '+type+
								'  and CAST(em.SCHEDULED_START_DATE AS DATE) >= CAST(GETUTCDATE() AS DATE) and em.TENANT_ID=1'+
								'  ) as temp'+
								'  where rank_1 = 1 and lower(ABBREVIATION) not in (\'ubd\')'+
								'  GROUP BY ABBREVIATION';
								
				// var queryString = 'select ABBREVIATION as Type, MAX(end_date) as last_1, max(start_date) as next_1, max(remark) as REMARK'
				// 					+' from (select emt.ABBREVIATION, em.ACTUAL_END_DATE as end_date, null AS start_date, em.REMARK as remark,'
				// 					+' RANK() over (PARTITION BY emt.ABBREVIATION order by em.ACTUAL_END_DATE DESC ) AS Rank_1'
				// 					+' from EQUIPMENT_MAINTAIN em'
				// 					+' join EQUIPMENT_MAINT_TYPE emt on (em.MAINT_TYPE_ID = emt.MAINT_TYPE_ID AND em.MAINTAIN_STATUS_ID != -9999)'
				// 					+' join RIG_EQUIPMENT re on re.RIG_EQUIPMENT_ID= em.RIG_EQUIPMENT_ID'
				// 					+' where re.EQUIPMENT_ID='+type
				// 					+' and em.ACTUAL_END_DATE <= GETUTCDATE() union'
				// 					+' select emt.ABBREVIATION, null as end_date, em.SCHEDULED_START_DATE as start_date, null as remark, '
				// 					+' RANK() over (PARTITION BY emt.ABBREVIATION order by em.SCHEDULED_START_DATE ASC) AS Rank_1'
				// 					+' from EQUIPMENT_MAINTAIN em'
				// 					+' join EQUIPMENT_MAINT_TYPE emt on (em.MAINT_TYPE_ID = emt.MAINT_TYPE_ID AND em.MAINTAIN_STATUS_ID != -9999)'
				// 					+' join RIG_EQUIPMENT re on re.RIG_EQUIPMENT_ID= em.RIG_EQUIPMENT_ID'
				// 					+' where re.EQUIPMENT_ID='+type
				// 					+' and em.SCHEDULED_START_DATE >= GETUTCDATE() and em.TENANT_ID=1'
				// 					+' ) as temp'
				// 					+' where rank_1 = 1 and lower(ABBREVIATION) not in (\'ubd\')'
				// 					+' group by ABBREVIATION';

			new mssql.Request().query(queryString)
									.then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
			});
		});
	};

	exports.getMaintenanceScheduleData=getMaintenanceScheduleData;

	// to get Activity checklist
	var getActivityChecklist=function(type,equipType){
		return new Promise(function(fulfill,reject){
			// var querString = 	' select * from ('+
			// 					' select'+
			// 					' RANK() over (partition by em.MAINT_TYPE_ID order by em.SCHEDULED_START_DATE asc) as ROW_NUM,'+
			// 					' ma.ACTIVITY_DESC, at.STATUS_DATETIME as Date, emt.ABBREVIATION as Type, at.STATUS, at.ACTIVITY_ID,at.TRACKER_ID,'+
			// 					' at.CLOSING_DATE, us.USER_FIRST_NAME,us.USER_LAST_NAME'+
			// 					' from EQUIPMENT_MAINTENANCE_ACTIVITY ema'+
			// 					' join EQUIPMENT_MAINTAIN em on (ema.EQUIP_ACT_ID = em.EQUIP_ACT_ID)'+
			// 					' join EQUIPMENT_MAINT_TYPE emt on (em.MAINT_TYPE_ID = emt.MAINT_TYPE_ID)'+
			// 					' join ACTIVITY_TRACKER at on (at.EQUIP_MAINT_ID = em.EQUIP_MAINT_ID)'+
			// 					' join MAINTENANCE_ACTIVITY ma on (at.ACTIVITY_ID = ma.ACTIVITY_ID)'+
			// 					' join EQUIP_MAINT_STATUS ems on (em.MAINTAIN_STATUS_ID = ems.MAINTAIN_STATUS_ID)'+
			// 					' join RIG_EQUIPMENT re on (em.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID)'+
			// 					' join "USER" us on at.LAST_UPDATE_USER_ID=us.USER_ID'+
			// 					' where re.EQUIPMENT_ID = '+type+
			// 					' AND CAST(em.SCHEDULED_START_DATE AS DATE) >= CAST(GETUTCDATE() AS DATE)'+
			// 					' and emt.ABBREVIATION = \''+equipType+'\''+
			// 					' ) t'+
			// 					' where ROW_NUM < 2'+
			// 					' union'+
			var querString = "";
				if(equipType == 'PM'){
					querString = ' select * from ('+
								' select'+
								' RANK() over (partition by em.MAINT_TYPE_ID order by em.SCHEDULED_START_DATE desc) as ROW_NUM,'+
								' ma.ACTIVITY_DESC, at.STATUS_DATETIME as Date, emt.ABBREVIATION as Type, at.STATUS, at.ACTIVITY_ID,at.TRACKER_ID,'+
								' at.CLOSING_DATE, us.USER_FIRST_NAME,us.USER_LAST_NAME,re.RIG_EQUIPMENT_ID'+
								' from EQUIPMENT_MAINTENANCE_ACTIVITY ema'+
								' join EQUIPMENT_MAINTAIN em on (ema.EQUIP_ACT_ID = em.EQUIP_ACT_ID)'+
								' join EQUIPMENT_MAINT_TYPE emt on (em.MAINT_TYPE_ID = emt.MAINT_TYPE_ID)'+
								' join ACTIVITY_TRACKER at on (at.EQUIP_MAINT_ID = em.EQUIP_MAINT_ID)'+
								' join MAINTENANCE_ACTIVITY ma on (at.ACTIVITY_ID = ma.ACTIVITY_ID)'+
								' join EQUIP_MAINT_STATUS ems on (em.MAINTAIN_STATUS_ID = ems.MAINTAIN_STATUS_ID)'+
								' join RIG_EQUIPMENT re on (em.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID AND re.ACTIVE = 1 AND re.TENANT_ID = 1)'+
								' join "USER" us on at.LAST_UPDATE_USER_ID = us.USER_ID'+
								' where re.EQUIPMENT_ID = '+type+ 'and em.MAINTAIN_STATUS_ID = 2000'+
								' and emt.ABBREVIATION = \''+equipType+'\''+
								' ) t';

				}else{
					querString = ' select * from ('+
								' select'+
								' RANK() over (partition by em.MAINT_TYPE_ID order by em.SCHEDULED_START_DATE desc) as ROW_NUM,'+
								' ma.ACTIVITY_DESC, at.STATUS_DATETIME as Date, emt.ABBREVIATION as Type, at.STATUS, at.ACTIVITY_ID,at.TRACKER_ID,'+
								' at.CLOSING_DATE, us.USER_FIRST_NAME,us.USER_LAST_NAME'+
								' from EQUIPMENT_MAINTENANCE_ACTIVITY ema'+
								' join EQUIPMENT_MAINTAIN em on (ema.EQUIP_ACT_ID = em.EQUIP_ACT_ID)'+
								' join EQUIPMENT_MAINT_TYPE emt on (em.MAINT_TYPE_ID = emt.MAINT_TYPE_ID)'+
								' join ACTIVITY_TRACKER at on (at.EQUIP_MAINT_ID = em.EQUIP_MAINT_ID)'+
								' join MAINTENANCE_ACTIVITY ma on (at.ACTIVITY_ID = ma.ACTIVITY_ID)'+
								' join EQUIP_MAINT_STATUS ems on (em.MAINTAIN_STATUS_ID = ems.MAINTAIN_STATUS_ID)'+
								' join RIG_EQUIPMENT re on (em.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID AND re.ACTIVE = 1 AND re.TENANT_ID = 1)'+
								' join "USER" us on at.LAST_UPDATE_USER_ID = us.USER_ID'+
								' where re.EQUIPMENT_ID = '+type+ 'and (em.MAINTAIN_STATUS_ID = 2000 OR em.MAINTAIN_STATUS_ID = 2001)'+
								' AND CAST(em.SCHEDULED_START_DATE AS DATE) = CAST(GETUTCDATE() AS DATE)'+
								' and emt.ABBREVIATION = \''+equipType+'\''+
								' ) t';
								// ' where ROW_NUM < 2';
				}
								
			// switch(equipType){
			// 	// today's day
			// 	case 'DM':
			// 	var querString='Select DISTINCT ma.ACTIVITY_DESC, at.STATUS_DATETIME as Date, emt.ABBREVIATION as Type, at.STATUS, at.ACTIVITY_ID'
			// 				+' ,at.CLOSING_DATE, us.USER_FIRST_NAME,us.USER_LAST_NAME from ACTIVITY_TRACKER at'
			// 				+' join MAINTENANCE_ACTIVITY ma on ma.ACTIVITY_ID=at.ACTIVITY_ID'
			// 				+' join RIG_EQUIPMENT re on (re.RIG_EQUIPMENT_ID= ma.RIG_EQUIPMENT_ID AND re.ACTIVE = 1)'
			// 				+' join EQUIPMENT_MAINT_TYPE emt on emt.MAINT_TYPE_ID=ma.MAINTAIN_TYPE_ID'
			// 				+' join "USER" us on at.LAST_UPDATE_USER_ID=us.USER_ID'
			// 				+' where re.EQUIPMENT_ID='+type+' and lower(emt.ABBREVIATION)=\'dm\''
			// 				+' and at.STATUS_DATETIME >= dateadd(day, datediff(day, 0, GETUTCDATE()), 0)'
			// 				+' and at.STATUS_DATETIME < dateadd(day, datediff(day, 0, GETUTCDATE()+1), 0)'
			// 				+' and at.TENANT_ID = 1 order by at.STATUS_DATETIME';
			// 	break;

			// 	//current week
			// 	case 'WM':
			// 	var querString='select DISTINCT ma.ACTIVITY_DESC, at.STATUS_DATETIME as Date, emt.ABBREVIATION as Type, at.STATUS, at.ACTIVITY_ID'
			// 				+' ,at.CLOSING_DATE, us.USER_FIRST_NAME,us.USER_LAST_NAME from ACTIVITY_TRACKER at'
			// 				+' join MAINTENANCE_ACTIVITY ma on ma.ACTIVITY_ID=at.ACTIVITY_ID'
			// 				+' join RIG_EQUIPMENT re on (re.RIG_EQUIPMENT_ID= ma.RIG_EQUIPMENT_ID AND re.ACTIVE = 1)'
			// 				+' join EQUIPMENT_MAINT_TYPE emt on emt.MAINT_TYPE_ID=ma.MAINTAIN_TYPE_ID'
			// 				+' join "USER" us on at.LAST_UPDATE_USER_ID=us.USER_ID'
			// 				+' where re.EQUIPMENT_ID='+type+' and lower(emt.ABBREVIATION)=\'wm\''
			// 				+' and at.STATUS_DATETIME >= dateadd(week, DATEDIFF(week,0,GETUTCDATE()), 0)'
			// 				+' and at.STATUS_DATETIME < dateadd(week, DATEDIFF(week,0,GETUTCDATE())+1, 0)'
			// 				+' and at.TENANT_ID=1 order by at.STATUS_DATETIME';
			// 	break;

			// 	//current month
			// 	case 'MM':
			// 	var querString='select DISTINCT ma.ACTIVITY_DESC, at.STATUS_DATETIME as Date, emt.ABBREVIATION as Type, at.STATUS, at.ACTIVITY_ID'
			// 				+' ,at.CLOSING_DATE, us.USER_FIRST_NAME,us.USER_LAST_NAME from ACTIVITY_TRACKER at'
			// 				+' join MAINTENANCE_ACTIVITY ma on ma.ACTIVITY_ID=at.ACTIVITY_ID'
			// 				+' join RIG_EQUIPMENT re on (re.RIG_EQUIPMENT_ID= ma.RIG_EQUIPMENT_ID AND re.ACTIVE = 1)'
			// 				+' join EQUIPMENT_MAINT_TYPE emt on emt.MAINT_TYPE_ID=ma.MAINTAIN_TYPE_ID'
			// 				+' join "USER" us on at.LAST_UPDATE_USER_ID=us.USER_ID'
			// 				+' where re.EQUIPMENT_ID='+type+' and lower(emt.ABBREVIATION)=\'mm\''
			// 				+' and at.STATUS_DATETIME >= dateadd(month, datediff(month, 0, GETUTCDATE()), 0)'
			// 				+' and at.STATUS_DATETIME < dateadd(month, datediff(month, 0, GETUTCDATE())+1, 0)'
			// 				+' and at.TENANT_ID=1 order by at.STATUS_DATETIME';
			// 	break;

			// 	//current quarter
			// 	case 'QM':

			// 	var querString='select DISTINCT ma.ACTIVITY_DESC, at.STATUS_DATETIME as Date, emt.ABBREVIATION as Type, at.STATUS, at.ACTIVITY_ID'
			// 				+' ,at.CLOSING_DATE, us.USER_FIRST_NAME,us.USER_LAST_NAME from ACTIVITY_TRACKER at'
			// 				+' join MAINTENANCE_ACTIVITY ma on ma.ACTIVITY_ID=at.ACTIVITY_ID'
			// 				+' join RIG_EQUIPMENT re on (re.RIG_EQUIPMENT_ID= ma.RIG_EQUIPMENT_ID AND re.ACTIVE = 1)'
			// 				+' join EQUIPMENT_MAINT_TYPE emt on emt.MAINT_TYPE_ID=ma.MAINTAIN_TYPE_ID'
			// 				+' join "USER" us on at.LAST_UPDATE_USER_ID=us.USER_ID'
			// 				+' where re.EQUIPMENT_ID='+type+' and lower(emt.ABBREVIATION)=\'qm\''
			// 				+' and at.STATUS_DATETIME >= dateadd(quarter, DATEDIFF(quarter,0,GETUTCDATE()), 0)'
			// 				+' and at.STATUS_DATETIME < dateadd(quarter, DATEDIFF(quarter,0,GETUTCDATE())+1, 0)'
			// 				+' and at.TENANT_ID=1 order by at.STATUS_DATETIME';
			// 	break;

			// 	//current half year
			// 	case 'HYM':
			// 	//first six
			// 	if(new Date().getMonth()>=0 &&new Date().getMonth()<=5){
			// 					var querString='select DISTINCT ma.ACTIVITY_DESC, at.STATUS_DATETIME as Date, emt.ABBREVIATION as Type, at.STATUS, at.ACTIVITY_ID'
			// 				+' ,at.CLOSING_DATE, us.USER_FIRST_NAME,us.USER_LAST_NAME from ACTIVITY_TRACKER at'
			// 				+' join MAINTENANCE_ACTIVITY ma on ma.ACTIVITY_ID=at.ACTIVITY_ID'
			// 				+' join RIG_EQUIPMENT re on (re.RIG_EQUIPMENT_ID= ma.RIG_EQUIPMENT_ID AND re.ACTIVE = 1)'
			// 				+' join EQUIPMENT_MAINT_TYPE emt on emt.MAINT_TYPE_ID=ma.MAINTAIN_TYPE_ID'
			// 				+' join "USER" us on at.LAST_UPDATE_USER_ID=us.USER_ID'
			// 				+' where re.EQUIPMENT_ID='+type+' and lower(emt.ABBREVIATION)=\'hym\''
			// 				+' and at.STATUS_DATETIME >= dateadd(year, DATEDIFF(year,0,GETUTCDATE()), 0)'
			// 				+' and at.STATUS_DATETIME < dateadd(month,6,dateadd(year, DATEDIFF(year,0,GETUTCDATE()), 0))'
			// 				+' and at.TENANT_ID=1 order by at.STATUS_DATETIME';
			// 				}
			// 				//last six
			// 				else{
			// 					var querString='select DISTINCT ma.ACTIVITY_DESC, at.STATUS_DATETIME as Date, emt.ABBREVIATION as Type, at.STATUS, at.ACTIVITY_ID'
			// 				+' ,at.CLOSING_DATE, us.USER_FIRST_NAME,us.USER_LAST_NAME from ACTIVITY_TRACKER at'
			// 				+' join MAINTENANCE_ACTIVITY ma on ma.ACTIVITY_ID=at.ACTIVITY_ID'
			// 				+' join RIG_EQUIPMENT re on (re.RIG_EQUIPMENT_ID= ma.RIG_EQUIPMENT_ID AND re.ACTIVE = 1)'
			// 				+' join EQUIPMENT_MAINT_TYPE emt on emt.MAINT_TYPE_ID=ma.MAINTAIN_TYPE_ID'
			// 				+' join "USER" us on at.LAST_UPDATE_USER_ID=us.USER_ID'
			// 				+' where re.EQUIPMENT_ID='+type+' and lower(emt.ABBREVIATION)=\'hym\''
			// 				+' and at.STATUS_DATETIME >= dateadd(month,6,dateadd(year, DATEDIFF(year,0,GETUTCDATE()), 0))'
			// 				+' and at.STATUS_DATETIME < dateadd(year, DATEDIFF(year,0,GETUTCDATE())+1, 0)'
			// 				+' and at.TENANT_ID=1 order by at.STATUS_DATETIME';
			// 				}
			// 	break;

			// 	//current year
			// 	case 'YM':
			// 	var querString='select DISTINCT ma.ACTIVITY_DESC, at.STATUS_DATETIME as Date, emt.ABBREVIATION as Type, at.STATUS, at.ACTIVITY_ID'
			// 				+' ,at.CLOSING_DATE, us.USER_FIRST_NAME,us.USER_LAST_NAME from ACTIVITY_TRACKER at'
			// 				+' join MAINTENANCE_ACTIVITY ma on ma.ACTIVITY_ID=at.ACTIVITY_ID'
			// 				+' join RIG_EQUIPMENT re on (re.RIG_EQUIPMENT_ID= ma.RIG_EQUIPMENT_ID AND re.ACTIVE = 1)'
			// 				+' join EQUIPMENT_MAINT_TYPE emt on emt.MAINT_TYPE_ID=ma.MAINTAIN_TYPE_ID'
			// 				+' join "USER" us on at.LAST_UPDATE_USER_ID=us.USER_ID'
			// 				+' where re.EQUIPMENT_ID='+type+' and lower(emt.ABBREVIATION)=\'ym\''
			// 				+' and at.STATUS_DATETIME >= dateadd(year, DATEDIFF(year,0,GETUTCDATE()), 0)'
			// 				+' and at.STATUS_DATETIME < dateadd(year, DATEDIFF(year,0,GETUTCDATE())+1, 0)'
			// 				+' and at.TENANT_ID=1 order by at.STATUS_DATETIME';
			// 	break;
			// }

			new mssql.Request().query(querString).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
			})
		});
	};

	exports.getActivityChecklist=getActivityChecklist;

	var getExistingMaintenancesForEquipment = function(equipmentId){
		return new Promise(function(fulfill,reject){
			var queryString = "SELECT COUNT(*) AS COUNT,em.MAINT_TYPE_ID FROM EQUIPMENT_MAINTAIN em"+
								" JOIN RIG_EQUIPMENT re ON (re.RIG_EQUIPMENT_ID = em.RIG_EQUIPMENT_ID)"+
								" WHERE re.EQUIPMENT_ID = "+equipmentId+
								" AND em.MAINTAIN_STATUS_ID = 2000"+
								" AND CAST(em.SCHEDULED_START_DATE AS DATE) >= CAST(GETUTCDATE() AS DATE)"+
								" GROUP BY em.MAINT_TYPE_ID"+
								" ORDER BY em.MAINT_TYPE_ID ASC";

			new mssql.Request().query(queryString).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
			})
		})
	}
	exports.getExistingMaintenancesForEquipment = getExistingMaintenancesForEquipment;
	// to get last six instances of maintenance data
	var getSixInstanceData=function(equip_id,equipType){	
		return new Promise(function(fulfill,reject){

			// var queryString =  	' Select TOP 6 em.ACTUAL_END_DATE as last_1, em.SCHEDULED_START_DATE as next_1,emt.ABBREVIATION as Type,DATEPART ( Month , GETUTCDATE()) as CurrentMonth, em.REMARK '+
			// 					'  from EQUIPMENT_MAINTAIN em'+
			// 					'  join EQUIPMENT_MAINT_TYPE emt on (em.MAINT_TYPE_ID=emt.MAINT_TYPE_ID AND em.MAINTAIN_STATUS_ID = 2001)'+
			// 					'  join RIG_EQUIPMENT re on (re.RIG_EQUIPMENT_ID = em.RIG_EQUIPMENT_ID AND re.ACTIVE = 1)'+
			// 					'  where re.EQUIPMENT_ID = '+equip_id+' and  lower(emt.ABBREVIATION) in (\''+equipType+'\')'+
			// 					'  and em.TENANT_ID=1 and CAST(em.ACTUAL_END_DATE AS DATE) <= CAST(GETUTCDATE() AS DATE)'+

			// 					'  UNION'+

			// var queryString =	'  Select TOP 6 em.SCHEDULED_START_DATE as last_1, em.SCHEDULED_END_DATE as next_1,emt.ABBREVIATION as Type,DATEPART ( Month , GETUTCDATE()) as CurrentMonth, em.REMARK '+
			// 					'  from EQUIPMENT_MAINTAIN em'+
			// 					'  join EQUIPMENT_MAINT_TYPE emt on (em.MAINT_TYPE_ID=emt.MAINT_TYPE_ID AND em.MAINTAIN_STATUS_ID = 2001)'+
			// 					'  join RIG_EQUIPMENT re on (re.RIG_EQUIPMENT_ID = em.RIG_EQUIPMENT_ID AND re.ACTIVE = 1)'+
			// 					'  where re.EQUIPMENT_ID = '+equip_id+' and  lower(emt.ABBREVIATION) in (\'ubd\')'+
			// 					'  and em.TENANT_ID=1 and CAST(em.SCHEDULED_END_DATE AS DATE) <= CAST(GETUTCDATE() AS DATE)'+
			// 					'  ORDER BY last_1 DESC';			
			var queryString = ' SELECT * FROM '+
								' (Select TOP 6 em.ACTUAL_START_DATE as last_1, em.ACTUAL_END_DATE as next_1,emt.ABBREVIATION as Type,DATEPART ( Month , GETUTCDATE()) as CurrentMonth, em.REMARK '+
								' from EQUIPMENT_MAINTAIN em '+
								' join EQUIPMENT_MAINT_TYPE emt on (em.MAINT_TYPE_ID=emt.MAINT_TYPE_ID AND em.MAINTAIN_STATUS_ID = 2001) '+
								' join RIG_EQUIPMENT re on (re.RIG_EQUIPMENT_ID = em.RIG_EQUIPMENT_ID AND re.ACTIVE = 1) '+
								' where re.EQUIPMENT_ID = '+equip_id+' and  lower(emt.ABBREVIATION) in (\'ubd\') '+
								' and em.TENANT_ID = 1 and CAST(em.ACTUAL_END_DATE AS DATE) <= CAST(GETUTCDATE() AS DATE) '+
								' ORDER BY em.ACTUAL_END_DATE DESC) a '+
								' UNION '+
								' SELECT * FROM '+
								' (Select TOP 6 em.ACTUAL_START_DATE as last_1, em.ACTUAL_END_DATE as next_1,emt.ABBREVIATION as Type,DATEPART ( Month , GETUTCDATE()) as CurrentMonth, em.REMARK '+
								' from EQUIPMENT_MAINTAIN em '+
								' join EQUIPMENT_MAINT_TYPE emt on (em.MAINT_TYPE_ID=emt.MAINT_TYPE_ID AND em.MAINTAIN_STATUS_ID = 2001) '+
								' join RIG_EQUIPMENT re on (re.RIG_EQUIPMENT_ID = em.RIG_EQUIPMENT_ID AND re.ACTIVE = 1 AND re.TENANT_ID = 1) '+
								' where re.EQUIPMENT_ID = '+equip_id+' and  lower(emt.ABBREVIATION) in (\''+equipType.toLowerCase()+'\') '+
								' and em.TENANT_ID=1 and CAST(em.ACTUAL_END_DATE AS DATE) <= CAST(GETUTCDATE() AS DATE) '+
								' ORDER BY em.ACTUAL_END_DATE DESC) b';
			
			new mssql.Request().query(queryString).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
			})
		});
	};

	exports.getSixInstanceData=getSixInstanceData;

	// to get maintenance info on area page
	var getAreaMaintData=function(areaId,equipType){
		return new Promise(function(fulfill,reject){
			var maint_type_id = 9901;
			switch(equipType){
				case 'DM':
					maint_type_id = 9901;
					break;
				case 'WM':
					maint_type_id = 9902;
					break;
				case 'MM':
					maint_type_id = 9903;
					break;
				case 'QM':
					maint_type_id = 9904;
					break;
				case 'HYM':
					maint_type_id = 9905;
					break;
				case 'YM':
					maint_type_id = 9906;
					break;				
			}	
			
			var queryString = 'SELECT q1.RIG_ID,q1.RIG_NAME,q1.EQUIPMENT_ID,q1.EQUIPMENT_NAME,q1.ABBREVIATION,q1.DESCRIPTION,MIN(q1.SCHEDULED_START_DATE) AS SCHEDULED_START_DATE,MAX(q1.ACTUAL_END_DATE) AS ACTUAL_END_DATE FROM'+
								' (SELECT r.RIG_ID,r.RIG_NAME,e.EQUIPMENT_ID,e.EQUIPMENT_NAME,emt.ABBREVIATION,e.DESCRIPTION,NULL AS SCHEDULED_START_DATE,MAX(em.ACTUAL_END_DATE) AS ACTUAL_END_DATE'+
								' FROM EQUIPMENT_MAINTAIN em'+
								' JOIN EQUIPMENT_MAINT_TYPE emt ON (emt.MAINT_TYPE_ID = em.MAINT_TYPE_ID AND em.MAINTAIN_STATUS_ID = 2001)'+
								' JOIN RIG_EQUIPMENT re ON (re.RIG_EQUIPMENT_ID = em.RIG_EQUIPMENT_ID AND re.ACTIVE = 1 AND re.TENANT_ID = 1 AND em.MAINT_TYPE_ID = '+maint_type_id+')'+
								' JOIN EQUIPMENT e ON (e.EQUIPMENT_ID = re.EQUIPMENT_ID AND e.ACTIVE = 1 AND e.TENANT_ID = 1)'+
								' JOIN RIG r ON (r.RIG_ID = re.RIG_ID)'+
								' JOIN RIG_WELL_MAP rwm ON (rwm.RIG_ID = r.RIG_ID)'+
								' JOIN WELL w ON (w.UWI = rwm.UWI)'+
								' JOIN AREA a ON (a.AREA_ID = w.AREA_ID)'+
								' WHERE a.AREA_ID = '+areaId+' AND em.ACTUAL_END_DATE <= GETUTCDATE()'+
								' GROUP BY r.RIG_ID,r.RIG_NAME,e.EQUIPMENT_ID,e.EQUIPMENT_NAME,emt.ABBREVIATION,e.DESCRIPTION'+  
								' UNION'+
								' SELECT r.RIG_ID,r.RIG_NAME,e.EQUIPMENT_ID,e.EQUIPMENT_NAME,emt.ABBREVIATION,e.DESCRIPTION,MIN(em.SCHEDULED_START_DATE) AS SCHEDULED_START_DATE,NULL AS ACTUAL_END_DATE'+
								' FROM EQUIPMENT_MAINTAIN em'+
								' JOIN EQUIPMENT_MAINT_TYPE emt ON (emt.MAINT_TYPE_ID = em.MAINT_TYPE_ID AND em.MAINTAIN_STATUS_ID = 2000)'+
								' JOIN RIG_EQUIPMENT re ON (re.RIG_EQUIPMENT_ID = em.RIG_EQUIPMENT_ID AND re.ACTIVE = 1 AND re.TENANT_ID = 1 AND em.MAINT_TYPE_ID = '+maint_type_id+')'+
								' JOIN EQUIPMENT e ON (e.EQUIPMENT_ID = re.EQUIPMENT_ID AND e.ACTIVE = 1 AND e.TENANT_ID = 1)'+
								' JOIN RIG r ON (r.RIG_ID = re.RIG_ID)'+
								' JOIN RIG_WELL_MAP rwm ON (rwm.RIG_ID = r.RIG_ID)'+
								' JOIN WELL w ON (w.UWI = rwm.UWI)'+
								' JOIN AREA a ON (a.AREA_ID = w.AREA_ID)'+
								' WHERE a.AREA_ID = '+areaId+' AND em.SCHEDULED_START_DATE >= GETUTCDATE()'+
								' GROUP BY r.RIG_ID,r.RIG_NAME,e.EQUIPMENT_ID,e.EQUIPMENT_NAME,emt.ABBREVIATION,e.DESCRIPTION) q1'+
								' GROUP BY q1.RIG_ID,q1.RIG_NAME,q1.EQUIPMENT_ID,q1.EQUIPMENT_NAME,q1.ABBREVIATION,q1.DESCRIPTION';
			new mssql.Request().query(queryString).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				console.log(err);
				return reject(err);
			});
		});
	};

	exports.getAreaMaintData=getAreaMaintData;

	// to get maintenance info on rig page

	var getRigMaintenanceData=function(rigId,equipType){
		return new Promise(function(fulfill,reject){
			var maint_type_id = 9901;

			switch(equipType){
				case 'DM':
					maint_type_id = 9901;
					break;
				case 'WM':
					maint_type_id = 9902;
					break;
				case 'MM':
					maint_type_id = 9903;
					break;
				case 'QM':
					maint_type_id = 9904;
					break;
				case 'HYM':
					maint_type_id = 9905;
					break;
				case 'YM':
					maint_type_id = 9906;
					break;				
			}

			var queryString= 'SELECT q1.RIG_ID,q1.RIG_NAME,q1.EQUIPMENT_ID,q1.EQUIPMENT_NAME,q1.ABBREVIATION,q1.DESCRIPTION,MIN(q1.SCHEDULED_START_DATE) AS SCHEDULED_START_DATE,MAX(q1.ACTUAL_END_DATE) AS ACTUAL_END_DATE FROM'+
							' (SELECT r.RIG_ID,r.RIG_NAME,e.EQUIPMENT_ID,e.EQUIPMENT_NAME,emt.ABBREVIATION,e.DESCRIPTION,NULL AS SCHEDULED_START_DATE,MAX(em.ACTUAL_END_DATE) AS ACTUAL_END_DATE'+
							' FROM EQUIPMENT_MAINTAIN em'+
							' JOIN EQUIPMENT_MAINT_TYPE emt ON (emt.MAINT_TYPE_ID = em.MAINT_TYPE_ID AND em.MAINTAIN_STATUS_ID = 2001)'+
							' JOIN RIG_EQUIPMENT re ON (re.RIG_EQUIPMENT_ID = em.RIG_EQUIPMENT_ID AND re.ACTIVE = 1 AND em.MAINT_TYPE_ID = '+maint_type_id+')'+
							' JOIN EQUIPMENT e ON (e.EQUIPMENT_ID = re.EQUIPMENT_ID AND e.ACTIVE = 1)'+
							' JOIN RIG r ON (r.RIG_ID = re.RIG_ID)'+
							' WHERE r.RIG_ID = '+rigId+' AND em.ACTUAL_END_DATE <= GETUTCDATE()'+
							' GROUP BY r.RIG_ID,r.RIG_NAME,e.EQUIPMENT_ID,e.EQUIPMENT_NAME,emt.ABBREVIATION,e.DESCRIPTION'+
							' UNION'+
							' SELECT r.RIG_ID,r.RIG_NAME,e.EQUIPMENT_ID,e.EQUIPMENT_NAME,emt.ABBREVIATION,e.DESCRIPTION,MIN(em.SCHEDULED_START_DATE) AS SCHEDULED_START_DATE,NULL AS ACTUAL_END_DATE'+
							' FROM EQUIPMENT_MAINTAIN em'+
							' JOIN EQUIPMENT_MAINT_TYPE emt ON (emt.MAINT_TYPE_ID = em.MAINT_TYPE_ID AND em.MAINTAIN_STATUS_ID = 2000)'+
							' JOIN RIG_EQUIPMENT re ON (re.RIG_EQUIPMENT_ID = em.RIG_EQUIPMENT_ID AND re.ACTIVE = 1 AND em.MAINT_TYPE_ID = '+maint_type_id+')'+
							' JOIN EQUIPMENT e ON (e.EQUIPMENT_ID = re.EQUIPMENT_ID AND e.ACTIVE = 1)'+
							' JOIN RIG r ON (r.RIG_ID = re.RIG_ID)'+
							' WHERE r.RIG_ID = '+rigId+' AND em.SCHEDULED_START_DATE >= GETUTCDATE()'+
							' GROUP BY r.RIG_ID,r.RIG_NAME,e.EQUIPMENT_ID,e.EQUIPMENT_NAME,emt.ABBREVIATION,e.DESCRIPTION) q1'+
							' GROUP BY q1.RIG_ID,q1.RIG_NAME,q1.EQUIPMENT_ID,q1.EQUIPMENT_NAME,q1.ABBREVIATION,q1.DESCRIPTION';
			new mssql.Request().query(queryString).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				
				return reject(err);
			})
		});
	};

	exports.getRigMaintenanceData=getRigMaintenanceData;

	// to get maintenance history
	this.getMaintenanceHistory=function(type,startDate,endDate){
		return new Promise(function(fulfill,reject){
			
			var queryString = ' select EQUIP_MAINT_ID, ABBREVIATION, ACTUAL_END_DATE, SCHEDULED_START_DATE, REMARK,'+
								' assignee, closed_by from ('+
								' select em.EQUIP_MAINT_ID, em.ACTUAL_END_DATE, em.SCHEDULED_START_DATE,'+
								' em.REMARK, CONCAT(assignee.USER_FIRST_NAME, \' \', assignee.USER_LAST_NAME) as assignee,'+
								' CONCAT(updatedby.USER_FIRST_NAME, \' \', updatedby.USER_LAST_NAME) as closed_by, at.CLOSING_DATE, emt.ABBREVIATION,'+
								' RANK() over (PARTITION BY at.EQUIP_MAINT_ID order by at.CLOSING_DATE DESC ) as RANK_1'+
								' from EQUIPMENT_MAINTAIN em'+
								' join EQUIPMENT_MAINT_TYPE emt on (em.MAINT_TYPE_ID = emt.MAINT_TYPE_ID AND em.MAINTAIN_STATUS_ID = 2001)'+
								' join RIG_EQUIPMENT re on re.RIG_EQUIPMENT_ID = em.RIG_EQUIPMENT_ID'+
								' LEFT join ACTIVITY_TRACKER at on (at.EQUIP_MAINT_ID = em.EQUIP_MAINT_ID)'+
								' LEFT join "USER" assignee on (assignee.USER_ID = em.ASSIGNEE_ID)'+
								' LEFT join "User" updatedby on (updatedby.USER_ID = at.LAST_UPDATE_USER_ID)'+
								' where re.EQUIPMENT_ID = '+type+' and em.TENANT_ID=1 '+
								' and ((em.ACTUAL_END_DATE IS NULL OR CAST(em.ACTUAL_END_DATE AS DATE) >= \''+startDate+'\' and CAST(em.ACTUAL_END_DATE AS DATE) <= \''+endDate+'\'))) t '+
								' where Rank_1 = 1';
								//console.log(queryString);
			new mssql.Request().query(queryString).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
			});
		});
	};

	exports.getMaintenanceHistory=getMaintenanceHistory;

	// to get MaintenanceBreakdownSummary
	this.getMaintenanceBreakdownSummary=function(type){
		var date=moment.utc().format('YYYY-MM-DD HH:mm:ss.SSS');
		return new Promise(function(fulfill,reject){
			new mssql.Request().query('Select em.ACTUAL_END_DATE as last_1, em.SCHEDULED_START_DATE as next_1,emt.ABBREVIATION as Type,DATEPART ( Month , GETUTCDATE()) as CurrentMonth'
									+' , em.REMARK from EQUIPMENT_MAINTAIN em'
									+' join EQUIPMENT_MAINT_TYPE emt on (em.MAINT_TYPE_ID=emt.MAINT_TYPE_ID AND em.MAINTAIN_STATUS_ID != -9999)'
									+' join RIG_EQUIPMENT re on re.RIG_EQUIPMENT_ID= em.RIG_EQUIPMENT_ID'
									+' where re.EQUIPMENT_ID='+type+' and  lower(emt.ABBREVIATION) in (\'mm\',\'ubd\')'
									+' and em.TENANT_ID=1 and em.ACTUAL_END_DATE > DATEADD(MONTH,-6,  DATEADD(DAY,-DATEPART ( Day , GETUTCDATE() )  ,  GETUTCDATE()))'
									+' and em.ACTUAL_END_DATE <=DATEADD(DAY,-DATEPART ( Day , GETUTCDATE() )  ,  GETUTCDATE())').then(function(recordset){
				return fulfill(recordset);
			},function(err){
				return reject(err);
			})
		})
	};

	exports.getMaintenanceBreakdownSummary=getMaintenanceBreakdownSummary;

	//to get coordinates for rig for rig page
	var getRigCoordinates = function(rigId,type){
		var queryString;
		switch(type){
			case 'area':
				queryString = 'SELECT DISTINCT r.RIG_ID AS rig_id,r.RIG_NAME AS place, w.SURFACE_LATITUDE AS lat,w.SURFACE_LONGITUDE AS lon'+
								' FROM RIG r'+
								' JOIN RIG_WELL_MAP rwm On (rwm.RIG_ID = r.RIG_ID)'+
								' JOIN WELL w ON (w.UWI = rwm.UWI)'+
								' JOIN AREA a ON (a.AREA_ID = w.AREA_ID)'+
								' WHERE a.AREA_ID = '+rigId+' AND a.TENANT_ID = 1 AND r.ACTIVE = 1';
				break;
			case 'rig':
				queryString = 'SELECT DISTINCT TOP 1 r.RIG_ID AS rig_id,r.RIG_NAME AS place, w.SURFACE_LATITUDE AS lat,w.SURFACE_LONGITUDE AS lon'+
								' FROM RIG r'+
								' JOIN RIG_WELL_MAP rwm On (rwm.RIG_ID = r.RIG_ID)'+
								' JOIN WELL w ON (w.UWI = rwm.UWI)'+
								' WHERE r.RIG_ID = '+rigId +' and r.TENANT_ID=1 AND r.ACTIVE = 1'
				break;
			default:
				break;
		}
		
		return new Promise(function(fulfill,reject){
			//mssql.connect(connectorUrl).then(function(){
				new mssql.Request().query(queryString).then(function(recordset){
					return fulfill(recordset);
				}).catch(function(err){
					return reject(err);
				});
			//});
		});
	}


	exports.getRigCoordinates = getRigCoordinates;

	//get the list of active and deployed equipments for the active/deployed widget in area page						
	var getRigEquipmentsDeploymentList = function(areaId){
		return new Promise(function(fulfill,reject){
			new mssql.Request().query('SELECT q1.RIG_ID AS rigId,q1.RIG_NAME AS rigName,q1.DESCRIPTION,SUM(q1.status) AS ACTIVE,SUM(q1.total_equip) AS TOTAL,MAX(q2.STATUS) AS STATUS'+
						' FROM '+ 
						' (SELECT r.RIG_ID , r.RIG_NAME,'+
						' CASE'+
							' WHEN e.EQUIP_STATUS_ID = 104 THEN 1'+
							' ELSE 0'+
						' END AS status'+
						' ,re.RIG_EQUIPMENT_ID,'+
						' CASE'+
							' WHEN e.EQUIP_STATUS_ID IN (104,103,102,101) THEN 1'+
							' ELSE 0'+
						' END AS total_equip,e.DESCRIPTION'+
						' FROM RIG_EQUIPMENT re'+
						' JOIN EQUIPMENT e ON (re.EQUIPMENT_ID = e.EQUIPMENT_ID AND e.ACTIVE = 1 AND re.ACTIVE = 1)'+
						' JOIN RIG r ON (r.RIG_ID = re.RIG_ID AND r.ACTIVE = 1)'+
						' JOIN RIG_WELL_MAP rwm on (rwm.RIG_ID = r.RIG_ID)'+
						' JOIN WELL w on (w.UWI = rwm.UWI)'+
						' JOIN AREA a on (w.AREA_ID = a.AREA_ID AND a.AREA_ID = '+areaId+')'+
						' where r.TENANT_ID=1 GROUP BY r.RIG_ID,e.DESCRIPTION,r.RIG_NAME,re.RIG_EQUIPMENT_ID,e.ACTIVE,e.DESCRIPTION,e.EQUIP_STATUS_ID) q1'+
						' JOIN'+
						' (SELECT re.RIG_EQUIPMENT_ID,MAX(COALESCE(ei.INCIDENT_STATUS,-1)) AS STATUS'+
						' FROM RIG_EQUIPMENT re'+
						' LEFT JOIN EQUIPMENT_INCIDENT ei ON (ei.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID and ei.INCIDENT_STATUS = 0 AND re.ACTIVE = 1)'+
						' where re.TENANT_ID=1 GROUP BY re.RIG_EQUIPMENT_ID) q2 ON (q1.RIG_EQUIPMENT_ID = q2.RIG_EQUIPMENT_ID)'+
						' GROUP BY q1.RIG_ID,q1.RIG_NAME,q1.DESCRIPTION').then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
			});
		});
	}

	exports.getRigEquipmentsDeploymentList = getRigEquipmentsDeploymentList;

	//to get all the equipments deployed in this rig along with their incident status
	var getAllRigEquipments = function(rigId){
		return new Promise(function(fulfill,reject){
			//mssql.connect(connectorUrl).then(function(){
				new mssql.Request().query('SELECT e.EQUIPMENT_NAME AS equip_name, e.EQUIPMENT_ID AS equip_id,MIN(COALESCE(ei.INCIDENT_STATUS,-1)) AS ACTIVE, e.DESCRIPTION,e.EQUIP_STATUS_ID AS STATUS'+
							' FROM dbo.EQUIPMENT e'+
							' JOIN dbo.RIG_EQUIPMENT re ON (e.EQUIPMENT_ID = re.EQUIPMENT_ID and e.ACTIVE = 1 and re.ACTIVE =1)'+
							' LEFT JOIN dbo.EQUIPMENT_INCIDENT ei ON (ei.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID AND ei.INCIDENT_STATUS = 0)'+
							' WHERE re.RIG_ID = '+rigId+
							' and e.ACTIVE = 1 and e.TENANT_ID=1 GROUP BY e.EQUIPMENT_NAME,e.EQUIPMENT_ID,e.DESCRIPTION,e.EQUIP_STATUS_ID').then(function(recordset){
							
					return fulfill(recordset);
				}).catch(function(err){
					return reject(err);
				});
			//});
		});
	}

	exports.getAllRigEquipments = getAllRigEquipments;

	//to get the events for all the pages
	var getEventDetails = function(type,id){
		var query = '';
		switch(type){
			case 'area':
				query = ' SELECT TOP 10 q.* FROM'+
						' ((SELECT TOP 10 eel.EVENT_TYPE,eel.EVENT_DESC,eel.EVENT_DATETIME,r.RIG_NAME,r.RIG_ID'+
						' FROM EQUIPMENT_EVENT_LOG eel'+
						' JOIN RIG_EQUIPMENT re ON (eel.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID AND re.ACTIVE = 1)'+
						' JOIN RIG r ON (r.RIG_ID = re.RIG_ID)'+
						' JOIN RIG_WELL_MAP rwm ON (rwm.RIG_ID = r.RIG_ID)'+
						' JOIN WELL w ON (w.UWI = rwm.UWI)'+
						' JOIN AREA a ON (a.AREA_ID = w.AREA_ID)'+
						' WHERE a.AREA_ID = '+id+' AND eel.EVENT_TYPE LIKE \'EQUIP%\' ORDER BY eel.EVENT_DATETIME DESC)'+
						' UNION'+
						' (SELECT TOP 10 eel.EVENT_TYPE,eel.EVENT_DESC,eel.EVENT_DATETIME,r.RIG_NAME,r.RIG_ID'+
						' FROM EQUIPMENT_EVENT_LOG eel'+
						' JOIN RIG_EQUIPMENT re ON (eel.RIG_EQUIPMENT_ID = re.EQUIPMENT_ID AND re.ACTIVE = 1)'+
						' JOIN RIG r ON (r.RIG_ID = re.RIG_ID)'+
						' JOIN RIG_WELL_MAP rwm ON (rwm.RIG_ID = r.RIG_ID)'+
						' JOIN WELL w ON (w.UWI = rwm.UWI)'+
						' JOIN AREA a ON (a.AREA_ID = w.AREA_ID)'+
						' WHERE a.AREA_ID = '+id+' AND eel.EVENT_TYPE LIKE \'EQUIP%\' ORDER BY eel.EVENT_DATETIME DESC)) AS q'+
						' ORDER BY q.EVENT_DATETIME DESC';

				break;
			case 'rig':
				query = 'SELECT TOP 10 q.* FROM'+
						' ((SELECT TOP 10 eel.EVENT_TYPE,eel.EVENT_DESC,eel.EVENT_DATETIME,re.RIG_ID,eel.RIG_EQUIPMENT_ID'+
						' FROM EQUIPMENT_EVENT_LOG eel'+
						' JOIN RIG_EQUIPMENT re ON (eel.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID AND re.ACTIVE = 1)'+
						' WHERE re.RIG_ID = '+id+' AND eel.EVENT_TYPE LIKE \'EQUIP%\' ORDER BY eel.EVENT_DATETIME DESC)'+
						' UNION'+
						' (SELECT TOP 10 eel.EVENT_TYPE,eel.EVENT_DESC,eel.EVENT_DATETIME,re.RIG_ID,eel.RIG_EQUIPMENT_ID'+
						' FROM EQUIPMENT_EVENT_LOG eel'+
						' JOIN RIG_EQUIPMENT re ON (eel.RIG_EQUIPMENT_ID = re.EQUIPMENT_ID AND re.ACTIVE = 1)'+
						' WHERE re.RIG_ID = '+id+' AND eel.EVENT_TYPE LIKE \'EQUIP%\' ORDER BY eel.EVENT_DATETIME DESC)) AS q'+
						' ORDER BY q.EVENT_DATETIME DESC';

				break;
			case 'genset':
			case 'compressor':
			case 'mudpump':
			case 'agitator':
			case 'shaker':
			case 'drawworks':
				query = 'SELECT TOP 10 q.* FROM'+
						' ((SELECT TOP 10 eel.EVENT_TYPE,eel.EVENT_DESC,eel.EVENT_DATETIME,re.RIG_ID,eel.RIG_EQUIPMENT_ID'+
						' FROM EQUIPMENT_EVENT_LOG eel'+
						' JOIN RIG_EQUIPMENT re ON (eel.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID AND re.ACTIVE = 1)'+
						' WHERE re.EQUIPMENT_ID = '+id+' AND eel.EVENT_TYPE LIKE \'EQUIP%\' ORDER BY eel.EVENT_DATETIME DESC)'+

						' UNION'+

						' (SELECT TOP 10 eel.EVENT_TYPE,eel.EVENT_DESC,eel.EVENT_DATETIME,re.RIG_ID,eel.RIG_EQUIPMENT_ID'+
						' FROM EQUIPMENT_EVENT_LOG eel'+
						' JOIN RIG_EQUIPMENT re ON (eel.RIG_EQUIPMENT_ID = re.EQUIPMENT_ID AND re.ACTIVE = 1)'+
						' WHERE re.EQUIPMENT_ID = '+id+' AND eel.EVENT_TYPE LIKE \'EQUIP%\' ORDER BY eel.EVENT_DATETIME DESC)) AS q'+
						' ORDER BY q.EVENT_DATETIME DESC';
				break;
			default:
				break;
		}

		return new Promise(function(fulfill,reject){
			new mssql.Request().query(query).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
			});
		});
	}

	exports.getEventDetails = getEventDetails;

	//o get the open incidents' details for all the pages
	var getIncidentDetails = function(type,id){
		var query = '';
		switch(type){
			case 'area':
				query = 'SELECT re.RIG_EQUIPMENT_ID,r.RIG_NAME,r.RIG_ID,ei.INCIDENT_DATETIME,ei.INCIDENT_DESCRIPTION, ei.INCIDENT_STATUS, ei.EQUIP_INCIDENT_ID, ei.INCIDENT_ASSIGNEE_COMMENT'+
						' FROM dbo.EQUIPMENT_INCIDENT ei'+
						' JOIN dbo.RIG_EQUIPMENT re ON (re.RIG_EQUIPMENT_ID = ei.RIG_EQUIPMENT_ID AND ei.INCIDENT_STATUS = 0 AND re.ACTIVE = 1)'+
						' JOIN dbo.RIG r ON (r.RIG_ID = re.RIG_ID)'+
						' JOIN dbo.RIG_WELL_MAP rwm ON (rwm.RIG_ID = r.RIG_ID)'+
						' JOIN dbo.WELL w ON (rwm.UWI = w.UWI)'+
						' JOIN dbo.AREA a ON (w.AREA_ID = a.AREA_ID)'+
						' WHERE a.AREA_ID = '+id+
						' and a.TENANT_ID=1 and a.ACTIVE = 1 ORDER BY ei.INCIDENT_DATETIME DESC';
				break;
			case 'rig':
				query = 'SELECT re.RIG_EQUIPMENT_ID,ei.INCIDENT_DATETIME,ei.INCIDENT_DESCRIPTION,ei.INCIDENT_STATUS,ei.EQUIP_INCIDENT_ID,ei.INCIDENT_ASSIGNEE_COMMENT'+
						' FROM dbo.EQUIPMENT_INCIDENT ei'+
						' JOIN dbo.RIG_EQUIPMENT re ON (re.RIG_EQUIPMENT_ID = ei.RIG_EQUIPMENT_ID AND ei.INCIDENT_STATUS = 0 AND re.ACTIVE = 1)'+
						' JOIN dbo.RIG r ON (re.RIG_ID = r.RIG_ID)'+
						' WHERE re.RIG_ID = '+id+
						' and re.TENANT_ID=1 AND r.ACTIVE = 1 ORDER BY ei.INCIDENT_DATETIME DESC';
				break;
			case 'genset':
			case 'compressor':
			case 'mudpump':
			case 'agitator':
			case 'shaker':
			case 'drawworks':
			case 'equipment':
				query = 'SELECT re.RIG_EQUIPMENT_ID,ei.INCIDENT_DESCRIPTION, ei.INCIDENT_DATETIME, ei.INCIDENT_STATUS, ei.EQUIP_INCIDENT_ID,ei.INCIDENT_ASSIGNEE_COMMENT'+
						' FROM dbo.EQUIPMENT_INCIDENT ei'+
						' JOIN dbo.RIG_EQUIPMENT re ON (ei.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID AND ei.INCIDENT_STATUS = 0 AND re.ACTIVE = 1)'+
						' WHERE re.EQUIPMENT_ID = '+id+
						' and re.TENANT_ID=1 and re.ACTIVE = 1 ORDER BY ei.INCIDENT_DATETIME DESC';
				break;
			default:
				query = 'SELECT a.AREA_ID,re.RIG_EQUIPMENT_ID,e.DESCRIPTION, e.EQUIPMENT_NAME,a.PREFERRED_NAME,r.RIG_NAME,r.RIG_ID,ei.INCIDENT_DATETIME,ei.INCIDENT_DESCRIPTION, ei.INCIDENT_STATUS, ei.EQUIP_INCIDENT_ID, ei.INCIDENT_ASSIGNEE_COMMENT'+
						' FROM dbo.EQUIPMENT_INCIDENT ei'+
						' JOIN dbo.RIG_EQUIPMENT re ON (re.RIG_EQUIPMENT_ID = ei.RIG_EQUIPMENT_ID AND re.ACTIVE = 1 AND ei.INCIDENT_STATUS = 0)'+
						' JOIN dbo.RIG r ON (r.RIG_ID = re.RIG_ID)'+
						' JOIN dbo.RIG_WELL_MAP rwm ON (rwm.RIG_ID = r.RIG_ID)'+
						' JOIN dbo.WELL w ON (rwm.UWI = w.UWI)'+
						' JOIN dbo.AREA a ON (w.AREA_ID = a.AREA_ID)'+
						' JOIN dbo.EQUIPMENT e ON (e.EQUIPMENT_ID = re.EQUIPMENT_ID) where a.TENANT_ID=1'+
						' ORDER BY ei.INCIDENT_DATETIME DESC';
			break;
		}

		return new Promise(function(fulfill,reject){
			new mssql.Request().query(query).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
			});
		});
	}

	exports.getIncidentDetails = getIncidentDetails;

	//filter the incidents based on the given conditions for the incidents/alarms page
	var getFilteredIncidents = function(obj){
		var user = [];
		var user = obj.user.split(' ');
		
		user[0] = user[0]!='' && user[0] !=undefined && user[0] != null ? user[0]:'';
		user[1] = user[1]!='' && user[1] !=undefined && user[1] != null ? user[1]:'';

		var queryString = 'SELECT top 50 a.AREA_ID,re.RIG_EQUIPMENT_ID,e.DESCRIPTION, e.EQUIPMENT_NAME,e.EQUIPMENT_ID,a.PREFERRED_NAME,r.RIG_NAME,r.RIG_ID,ei.INCIDENT_DATETIME,ei.INCIDENT_DESCRIPTION, ei.INCIDENT_STATUS, ei.EQUIP_INCIDENT_ID, ei.INCIDENT_ASSIGNEE_COMMENT, u.USER_FIRST_NAME, u.USER_LAST_NAME'+
							' FROM dbo.EQUIPMENT_INCIDENT ei'+
							' JOIN dbo.RIG_EQUIPMENT re ON (re.RIG_EQUIPMENT_ID = ei.RIG_EQUIPMENT_ID AND ei.INCIDENT_STATUS LIKE \'%'+obj.status+'%\')'+
							' JOIN dbo.RIG r ON (r.RIG_ID = re.RIG_ID)'+
							' JOIN dbo.RIG_WELL_MAP rwm ON (rwm.RIG_ID = r.RIG_ID AND LOWER(r.RIG_NAME) LIKE \'%'+obj.rig.toLowerCase()+'%\')'+
							' JOIN dbo.WELL w ON (rwm.UWI = w.UWI)'+
							' JOIN dbo.AREA a ON (w.AREA_ID = a.AREA_ID AND LOWER(a.PREFERRED_NAME) LIKE \'%'+obj.area.toLowerCase()+'%\')'+
							' JOIN dbo.EQUIPMENT e ON (e.EQUIPMENT_ID = re.EQUIPMENT_ID AND LOWER(e.DESCRIPTION) LIKE \'%'+obj.asset.toLowerCase()+'%\' AND LOWER(e.EQUIPMENT_NAME) LIKE \'%'+obj.equipment.toLowerCase()+'%\')'+
							' JOIN "USER" u ON (ei.INCIDENT_ASSIGNEE_ID = u.USER_ID AND LOWER(u.USER_FIRST_NAME) LIKE \'%'+user[0].toLowerCase()+'%\' AND LOWER(u.USER_LAST_NAME) LIKE \'%'+user[1].toLowerCase()+'%\')'+
							' where e.TENANT_ID=1 ORDER BY ei.INCIDENT_DATETIME DESC';
		
		return new Promise(function(fulfill,reject){
				new mssql.Request().query(queryString).then(function(recordset){
					
					return fulfill(recordset);
				}).catch(function(err){
					return reject(err);
				});
		});
	}

	exports.getFilteredIncidents = getFilteredIncidents;

	//to close the incident from any of the pages containing incident details
	var updateIncident = function(id,comment,status){
		return new Promise(function(fulfill,reject){
			new mssql.Request().query('UPDATE dbo.EQUIPMENT_INCIDENT SET INCIDENT_STATUS = '+status+',INCIDENT_ASSIGNEE_COMMENT = \''+comment+'\' WHERE EQUIP_INCIDENT_ID = '+id).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
			});
		});
	}

	exports.updateIncident = updateIncident;

	//to get the file path of the operation manual for downloading
	var downloadFile = function(id){
		return new Promise(function(fulfill,reject){
			new mssql.Request().query('SELECT eda.ARTIFACT_CONTENTS'+
					' FROM EQUIPMENT_DESIGN_ARTIFACTS eda'+
					' WHERE eda.EQUIPMENT_ID = '+id).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
			});
		});
	}

	exports.downloadFile = downloadFile;

	//to get the weekly maintenance details for the maintenance widget in the area and rig pages
	var getWeeklyMaintenanceDetails = function(type,id){
		return new Promise(function(fulfill,reject){
			var queryString = "";
			if(type=='area'){
				queryString = ' SELECT r.RIG_ID,r.RIG_NAME,e.EQUIPMENT_ID,e.EQUIPMENT_NAME,e.DESCRIPTION,em.ACTUAL_END_DATE,'+
						' (	'+
						' 	SELECT TOP 1 em1.SCHEDULED_START_DATE '+
						' 	FROM EQUIPMENT_MAINTAIN em1 '+
						' 	WHERE em1.SCHEDULED_START_DATE > em.ACTUAL_END_DATE and em1.MAINT_TYPE_ID = 9902 AND em1.MAINTAIN_STATUS_ID != -9999'+
						' 	ORDER BY em1.SCHEDULED_START_DATE ASC'+
						' ) SCHEDULED_START_DATE'+
						' FROM EQUIPMENT_MAINTAIN em'+
						' JOIN RIG_EQUIPMENT re ON (re.RIG_EQUIPMENT_ID = em.RIG_EQUIPMENT_ID AND em.MAINT_TYPE_ID = 9902 AND em.MAINTAIN_STATUS_ID != -9999 AND em.ACTUAL_END_DATE IN'+
						' (SELECT TOP 1 em.ACTUAL_END_DATE'+
						' FROM EQUIPMENT_MAINTAIN em1'+
						' where em1.RIG_EQUIPMENT_ID=re.RIG_EQUIPMENT_ID AND em1.MAINT_TYPE_ID = 9902 AND em1.MAINTAIN_STATUS_ID != -9999'+
						' order by em1.ACTUAL_END_DATE DESC)'+
						' )'+
						' JOIN EQUIPMENT e ON (e.EQUIPMENT_ID = re.EQUIPMENT_ID)'+
						' JOIN RIG r ON (r.RIG_ID = re.RIG_ID)'+
						' JOIN RIG_WELL_MAP rwm ON (r.RIG_ID = rwm.RIG_ID)'+
						' JOIN WELL w ON (rwm.UWI = w.UWI)'+
						' JOIN AREA a ON (w.AREA_ID = a.AREA_ID)'+
						' WHERE a.AREA_ID = '+id+
						' and a.TENANT_ID=1 ORDER BY em.SCHEDULED_START_DATE';
			}else if(type=='rig'){
				queryString = ' SELECT r.RIG_ID,r.RIG_NAME,e.EQUIPMENT_ID,e.EQUIPMENT_NAME,e.DESCRIPTION,em.ACTUAL_END_DATE,'+
						' (	'+
						' 	SELECT TOP 1 em1.SCHEDULED_START_DATE '+
						' 	FROM EQUIPMENT_MAINTAIN em1 '+
						' 	WHERE em1.SCHEDULED_START_DATE > em.ACTUAL_END_DATE and em1.MAINT_TYPE_ID = 9902 AND em1.MAINTAIN_STATUS_ID != -9999 '+
						' 	ORDER BY em1.SCHEDULED_START_DATE ASC'+
						' ) SCHEDULED_START_DATE'+
						' FROM EQUIPMENT_MAINTAIN em'+
						' JOIN RIG_EQUIPMENT re ON (re.RIG_EQUIPMENT_ID = em.RIG_EQUIPMENT_ID AND em.MAINT_TYPE_ID = 9902 AND em.MAINTAIN_STATUS_ID != -9999 AND em.ACTUAL_END_DATE IN'+
						' (SELECT TOP 1 em1.ACTUAL_END_DATE'+
						' FROM EQUIPMENT_MAINTAIN em1'+
						' where em1.RIG_EQUIPMENT_ID=re.RIG_EQUIPMENT_ID AND em1.MAINT_TYPE_ID = 9902 AND em1.MAINTAIN_STATUS_ID != -9999'+
						' order by em1.ACTUAL_END_DATE DESC)'+
						' )'+
						' JOIN EQUIPMENT e ON (e.EQUIPMENT_ID = re.EQUIPMENT_ID)'+
						' JOIN RIG r ON (r.RIG_ID = re.RIG_ID)'+
						' WHERE r.RIG_ID = '+id+
						' and r.TENANT_ID=1 ORDER BY em.SCHEDULED_START_DATE';
			}
			new mssql.Request().query(queryString).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
			});
		});
	}

	exports.getWeeklyMaintenanceDetails = getWeeklyMaintenanceDetails;

	//to update the activity status(open/closed) from the equipment page
	var updateActivityStatus = function(activityId,userId){
		return new Promise(function(fulfill,reject){
				new mssql.Request().query('update ACTIVITY_TRACKER set STATUS=1'
					+' ,CLOSING_DATE = GETUTCDATE(),'
					+' LAST_UPDATE_USER_ID='+userId
					+' where TRACKER_ID='+activityId).then(function(recordset){
					return fulfill(recordset);
				}).catch(function(err){
					return reject(err);
				});
		});
	}
	exports.updateActivityStatus = updateActivityStatus;

	//to update the maintenance comment after all the activities for the particular maintenance is completed 
	var updateCheckListComment = function(activityId,comment){
		return new Promise(function(fulfill,reject){
				new mssql.Request().query('update EQUIPMENT_MAINTAIN'
										+' set REMARK=\''+comment+'\',ACTUAL_END_DATE = GETUTCDATE(),MAINTAIN_STATUS_ID = 2001'
										+' where EQUIP_MAINT_ID = '
										+' (select EQUIP_MAINT_ID'
										+' from ACTIVITY_TRACKER at'
										+' where at.TRACKER_ID = '+activityId+') AND MAINTAIN_STATUS_ID != -9999').then(function(recordset){
										
					return fulfill(recordset);
				}).catch(function(err){
					return reject(err);
				});
		});
	}
	exports.updateCheckListComment = updateCheckListComment;

	//update closing date in equip maint table
	var updateEquipMaintClosingDate = function(activityId){
		return new Promise(function(fulfill,reject){
				new mssql.Request().query('update EQUIPMENT_MAINTAIN'
										+' set ACTUAL_END_DATE = GETUTCDATE()'
										+' where EQUIP_MAINT_ID='
										+' (select EQUIP_MAINT_ID'
										+' from ACTIVITY_TRACKER at'
										+' where at.TRACKER_ID='+activityId+') AND MAINTAIN_STATUS_ID != -9999').then(function(recordset){
					return fulfill(recordset);
				}).catch(function(err){
					
					return reject(err);
				});
		});
	}
	exports.updateEquipMaintClosingDate = updateEquipMaintClosingDate;

	//insert an entry into the event log for the activity update
	var updateEventLog = function(activityId,equipId,activity){
		var date=moment.utc().format('YYYY-MM-DD HH:mm:ss.SSS');
		return new Promise(function(fulfill,reject){
				new mssql.Request().query('insert into EQUIPMENT_EVENT_LOG (RIG_EQUIPMENT_ID, EVENT_TYPE, EVENT_DESC,EVENT_DATETIME,TENANT_ID )'
										+' values (  where EQUIPMENT_ID='+equipId+'), \'EQUIP-I\''
										+' , CONCAT((select CONCAT(DESCRIPTION,\' \', EQUIPMENT_NAME) from EQUIPMENT where EQUIPMENT_ID = '+equipId+'), \': Activity "'+activity+'" completed.\'), GETUTCDATE(),1)').then(function(recordset){
					return fulfill(recordset);
				}).catch(function(err){
					
					return reject(err);
				});
		});
	}

	exports.updateEventLog = updateEventLog;

	//insert an entry into the event log for the incident closing
	var updateEventLogForIncidents = function(equipId,incidentDesc){
		var date=moment.utc().format('YYYY-MM-DD HH:mm:ss.SSS');
		return new Promise(function(fulfill,reject){
			new mssql.Request().query('insert into EQUIPMENT_EVENT_LOG (RIG_EQUIPMENT_ID, EVENT_TYPE, EVENT_DESC,EVENT_DATETIME,TENANT_ID)'
									+' values ('+equipId+', \'EQUIP-I\''
									+' , \'Alarm "'+incidentDesc+'" closed.\', GETUTCDATE(),1)').then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){

				return reject(err);
			});
		});
	}

	exports.updateEventLogForIncidents = updateEventLogForIncidents;

	//get the well details for the rig page
	var getRigWellInfo = function(rigId){
		return new Promise(function(fulfill,reject){
			new mssql.Request().query('SELECT w.UWI,w.WELL_NAME,w.SURFACE_LATITUDE,w.SURFACE_LONGITUDE,rwm.RIG_ID'+
						' FROM WELL w'+
						' JOIN RIG_WELL_MAP rwm ON (w.UWI = rwm.UWI)'+
						' WHERE rwm.RIG_ID = '+rigId+' AND w.ACTIVE = 1 and w.TENANT_ID=1').then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				
				return reject(err);
			});
		});
	}

	exports.getRigWellInfo = getRigWellInfo;

	//get the rig details for the rig page
	var getRigInfo = function(rigId){
		return new Promise(function(fulfill,reject){
			new mssql.Request().query(" SELECT R.RIG_NAME AS 'Rig Name',BAE.BA_NAME AS Owner,BA.BA_NAME AS Operator,R.COMMISSION_DATE AS 'Commission Date',R.EFFECTIVE_DATE AS 'Effective Date'"+
						" FROM RIG R"+
						" JOIN BUSINESS_ASSOCIATE BA ON(BA.BUSINESS_ASSOCIATE_ID = R.OPERATOR_BA_ID)"+
						" JOIN BUSINESS_ASSOCIATE BAE ON(BAE.BUSINESS_ASSOCIATE_ID = R.OWNER_BA_ID)"+
						" WHERE RIG_ID = "+rigId).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				
				return reject(err);
			});
		});
	}

	exports.getRigInfo = getRigInfo;

	//get the config params for the display tables for the master configuration pages
	var getConfiguratorTables = function(type){
		var queryString = "";
		switch(type){
			case 'area':
				queryString = "SELECT AREA_ID AS Id,PREFERRED_NAME AS Name FROM AREA WHERE ACTIVE = 1 and TENANT_ID=1 ORDER BY AREA_ID DESC";
				break;
			case 'rig':
				queryString = "SELECT RIG_ID AS Id,RIG_NAME AS Name,COMMISSION_DATE AS 'Commission Date',DECOMMISSION_DATE AS 'Decommission Date',EXPIRY_DATE AS 'Expiry Date' FROM RIG WHERE ACTIVE = 1 and TENANT_ID=1 ORDER BY RIG_ID DESC"
				break;
			case 'asset':
				queryString = "SELECT ASSET_ID AS Id,ASSET_NAME AS Name FROM ASSET WHERE ASSET_INACTIVE = 0 and TENANT_ID=1 ORDER BY ASSET_ID DESC"
				break;
			case 'well':
				queryString = "SELECT UWI AS UWI,WELL_NAME AS Name,SURFACE_LATITUDE AS Latitude,SURFACE_LONGITUDE AS Longitude FROM WELL WHERE ACTIVE = 1 and TENANT_ID=1 ORDER BY CREATED_DATETIME DESC"
				break;
			case 'equipment':
				queryString = ' SELECT e.EQUIPMENT_ID AS Id, e.EQUIP_OEM_NUMBER AS "OEM Number",'+
								' e.EQUIPMENT_NAME AS Name,e.DESCRIPTION AS Description,e.PURCHASE_DATE AS "Purchase Date",e.EFFECTIVE_DATE AS "Effective Date",'+
								' e.EXPIRY_DATE AS "Expiry Date",s.LONG_NAME AS Status,s.EQUIP_STATUS_ID AS "Equip Status Id"'+
								' FROM EQUIPMENT e JOIN EQUIP_STATUS s '+
								' ON(s.EQUIP_STATUS_ID = e.EQUIP_STATUS_ID AND e.EQUIP_STATUS_ID != 99 AND e.ACTIVE != 0)'
								+ ' where e.TENANT_ID=1 ORDER BY e.EQUIPMENT_ID DESC';
				break;
			case 'user':
				queryString = 'SELECT u.USER_ID as Id ,concat(u.USER_FIRST_NAME,\' \',u.USER_LAST_NAME) as Name, u.USER_EMAIL as Email,'
							+'u.USER_CONTACT_NUMBER as Number, ro.ROLE_NAME as Role,'
						+' 	CASE'
						+'	WHEN urm.URM_ROLE_ID = 4 THEN a.ASSET_NAME'
						+'	WHEN urm.URM_ROLE_ID = 1 THEN ar.PREFERRED_NAME'
						+'	WHEN urm.URM_ROLE_ID = 2 THEN r.RIG_NAME'
						+'	WHEN urm.URM_ROLE_ID = 3 THEN CONCAT(eq.DESCRIPTION, \' - \', eq.EQUIP_OEM_NUMBER)'
						+'	ELSE \'N/A\''
					+'	END AS Owner'
					+' FROM "USER" u'
					+' JOIN RIG_USER_ROLE_MAP urm ON (u.USER_ID = urm.URM_USER_ID AND urm.URM_INACTIVE = 0)'
					+' JOIN ROLE ro ON (ro.ROLE_ID = urm.URM_ROLE_ID)'
					+' LEFT JOIN ASSET a ON (a.ASSET_ID = urm.RIG_ID)'
					+' LEFT JOIN AREA ar ON  (ar.AREA_ID = urm.RIG_ID)'
					+' LEFT JOIN RIG r ON (r.RIG_ID = urm.RIG_ID)'
					+' LEFT JOIN EQUIPMENT eq ON (eq.EQUIPMENT_ID = urm.RIG_ID)'
					+' WHERE u.USER_INACTIVE = 0 and u.TENANT_ID=1 ORDER BY u.USER_ID DESC'
				break;
			case 'sensor':
				queryString = ' SELECT s.SENSOR_ID AS Id,s.SENSOR_ID AS \'Sensor MAC\',s.SENSOR_NAME AS \'Sensor Name\',s.SENSOR_DESC AS Description,ba.BA_NAME AS Manufacturer,e.EQUIPMENT_NAME AS \'Attached To\''+
								' FROM SENSOR s'+
								' JOIN BUSINESS_ASSOCIATE ba ON(s.MANUFACTURER_ID = ba.BUSINESS_ASSOCIATE_ID)'+
								' LEFT JOIN SENSOR_EQUIPMENT se ON (s.SENSOR_ID = se.SENSOR_ID)'+
								' LEFT JOIN EQUIPMENT e ON (e.EQUIPMENT_ID = se.EQUIPMENT_ID AND e.ACTIVE = 1 AND e.TENANT_ID = 1)'+
								' where s.TENANT_ID=1 ORDER BY CREATED_DATETIME DESC';
				break;
			case 'Maintenance':
				queryString="select distinct ema.EQUIP_ACT_ID as Id, eq.EQUIPMENT_NAME as 'Equipment Name', emt.ABBREVIATION as 'Recurring Type', ema.SCHEDULED_START_DATE as 'Scheduled Start Date', ema.SCHEDULED_END_DATE as 'Scheduled End Date'"
							+" ,eq.EQUIPMENT_ID as 'Equipment Id' , ema.ASSIGNEE_ID as 'Assignee Id',emt.MAINT_TYPE_ID,"
							+" concat(u.USER_FIRST_NAME ,' ', u.USER_LAST_NAME) as Assignee "
							+" from EQUIPMENT_MAINTENANCE_ACTIVITY ema "
							+" join EQUIPMENT_MAINTAIN em on (em.EQUIP_ACT_ID = ema.EQUIP_ACT_ID AND em.MAINTAIN_STATUS_ID = 2000)"
							+" join EQUIPMENT_MAINT_TYPE emt on ema.MAINTENANCE_TYPE=emt.MAINT_TYPE_ID"
							+" join RIG_EQUIPMENT re on re.RIG_EQUIPMENT_ID=em.RIG_EQUIPMENT_ID"
							+" join EQUIPMENT eq on eq.EQUIPMENT_ID = re.EQUIPMENT_ID"
							+" join \"User\" u on em.ASSIGNEE_ID=u.USER_ID"
							+" where CAST(em.SCHEDULED_START_DATE AS DATE) >= CAST(GETUTCDATE() AS DATE) and emt.ABBREVIATION not like 'UBD' and ema.TENANT_ID=1"
							+" order by eq.EQUIPMENT_NAME,emt.MAINT_TYPE_ID,ema.SCHEDULED_START_DATE desc";
			break;
		}
		return new Promise(function(fulfill,reject){
			//if(configurationTables[type.toLowerCase()]==undefined){
				new mssql.Request().query(queryString).then(function(recordset){
					//configurationTables[type.toLowerCase()] = recordset;
					return fulfill(recordset);
				}).catch(function(err){
					
					return reject(err);
				});
			// }else{
			// 	return fulfill(configurationTables[type.toLowerCase()]);
			// }
		});
	}

	exports.getConfiguratorTables = getConfiguratorTables;

	//get the complete config parameters for editing them in the config page
	var editConfiguratorTables = function(type,id){
		var queryString = "";
		switch(type){
			case 'area':
				queryString = "SELECT a.PREFERRED_NAME AS 'Area Name',a.SURFACE_LATITUDE AS Latitude,a.SURFACE_LONGITUDE AS Longitude, aam.ASSET_ID AS 'Asset' FROM AREA a JOIN ASSET_AREA_MAP aam ON(a.AREA_ID = aam.AREA_ID AND a.AREA_ID LIKE \'%"+id+"%\') and a.TENANT_ID=1";
				break;
			case 'rig':
				queryString = "SELECT RIG_NAME AS Name,"
								+" COMMISSION_DATE AS 'Commission Date',DECOMMISSION_DATE AS 'Decommission Date',EFFECTIVE_DATE AS 'Effective Date',"
								+" EXPIRY_DATE AS 'Expiry Date',HOOK_LOAD_CAPACITY AS 'Hook Load Capacity',"
								+" HOOK_LOAD_CAPACITY_UOM AS 'Hook Load Capacity UOM',KB_GROUND_DISTANCE AS 'KB Ground Distance',"
								+" KB_GROUND_DISTANCE_UOM AS 'KB Ground Distance UOM',MAST_HEIGHT AS 'Mast Height',"
								+" MAST_HEIGHT_UOM AS 'Mast Height UOM',MAST_TYPE AS 'Mast Type',MAX_DEPTH AS 'Max Depth',"
								+" MAX_DEPTH_UOM AS 'Max Depth UOM',OPERATOR_BA_ID AS 'Operator',OWNER_BA_ID AS 'Owner',REMARK AS 'Remark',"
								+" RIG_CATEGORY AS 'Rig Category',RIG_CLASS AS 'Rig Class',RIG_CODE AS 'Rig Code',RIG_NAME AS 'Rig Name',"
								+" RIG_TYPE AS 'Rig Type',ROTARY_TABLE_SIZE AS 'Rotary Table Size',ROTARY_TABLE_SIZE_UOM AS 'Rotary Table Size UOM',"
								+" WATER_DEPTH AS 'Water Depth',WATER_DEPTH_DATUM AS 'Water Depth Datum',WATER_DEPTH_UOM AS 'Water Depth UOM'"
								+" FROM RIG r "
								+" WHERE r.RIG_ID = "+id+" and r.TENANT_ID=1"
				break;
			case 'asset':
				queryString = "SELECT ASSET_NAME AS 'Asset Name' FROM ASSET a WHERE a.ASSET_ID LIKE \'%"+id+"%\' and a.TENANT_ID=1"
				break;
			case 'well':
				queryString = "SELECT w.UWI ,WELL_NAME AS 'Well Name',WELL_STATUS_ID AS 'Well Status',SPUD_DATE AS 'Spud Date',COMPLETION_DATE AS 'Completion Date',ABANDONMENT_DATE AS 'Abandonment Date',COUNTRY AS 'Country', ASSET_ID AS 'Asset' ,AREA_ID AS 'Area',RIG_ID AS 'Rig',COUNTY AS 'County',CURRENT_STATUS_DATE AS 'Current Status Date',DEPTH_DATUM_TYPE_ID AS 'Depth Datum Type',DEPTH_DATUM_ELEV AS 'Depth Datum Elevation',DEPTH_DATUM_ELEV_UOM AS 'Depth Datum Elevation UOM',OPERATOR AS 'Operator',REGION AS 'Region',TOTAL_DEPTH AS 'Total Depth',WELL_TYPE AS 'Well Type',PROD_METHOD as 'Production Method',RESERVOIR_NAME AS 'Reservoir Name',ARTIFICIAL_LIFT_TYPE as 'Artificial Lift Type',ARTIFICIAL_START_DATE AS 'Artificial Start Date',CURRENT_STATUS AS 'Current Status',PRODUCTION_START_DATE AS 'Production Start Date',SURFACE_LATITUDE AS Latitude,SURFACE_LONGITUDE AS Longitude FROM WELL w JOIN RIG_WELL_MAP rwm ON(w.UWI = rwm.UWI) WHERE w.TENANT_ID=1 and w.ACTIVE = 1 and w.UWI = '"+id+"'";
				break;
			case 'equipment':
				queryString = "SELECT e.EQUIPMENT_NAME AS 'Equipment Name',e.EQUIP_OEM_NUMBER AS 'Equipment OEM Number',e.DESCRIPTION AS Description,"+
								" e.PURCHASE_DATE AS 'Purchase Date',e.EFFECTIVE_DATE AS 'Effective Date',e.EXPIRY_DATE AS 'Expiry Date',b.BUSINESS_ASSOCIATE_ID AS Manufacturer,"+
								" e.LATITUDE AS Latitude, e.LONGITUDE AS Longitude, eda.ARTIFACT_CONTENTS AS 'File'"+
								" FROM EQUIPMENT e"+
								" LEFT JOIN EQUIPMENT_DESIGN_ARTIFACTS eda ON (eda.EQUIPMENT_ID = e.EQUIPMENT_ID)"+
								" JOIN BUSINESS_ASSOCIATE b ON (b.BUSINESS_ASSOCIATE_ID = e.MANUFACTURER_ID AND e.ACTIVE = 1 AND e.EQUIPMENT_ID LIKE \'%"+id+"%\')"+
								" where e.TENANT_ID=1";
				break;
			case 'user':
				
				queryString = 'SELECT u.USER_FIRST_NAME, u.USER_LAST_NAME, u.USER_EMAIL,u.USER_PASSWORD ,u.USER_CONTACT_NUMBER ,'
							+' ro.ROLE_ID, ro.ROLE_NAME, a.ASSET_ID,a.ASSET_NAME,ar.AREA_ID, ar.PREFERRED_NAME as Area_Name,'
							+' r.RIG_ID, r.RIG_NAME, eq.DESCRIPTION as Equipment_Type,eq.EQUIPMENT_ID, eq.EQUIPMENT_NAME'
							+' FROM "USER" u'
							+' JOIN RIG_USER_ROLE_MAP urm ON (u.USER_ID = urm.URM_USER_ID AND urm.URM_INACTIVE = 0)'
							+' JOIN ROLE ro ON (ro.ROLE_ID = urm.URM_ROLE_ID)'
							+' LEFT JOIN ASSET a ON (a.ASSET_ID = urm.RIG_ID)'
							+' LEFT JOIN AREA ar ON  (ar.AREA_ID = urm.RIG_ID)'
							+' LEFT JOIN RIG r ON (r.RIG_ID = urm.RIG_ID)'
							+' LEFT JOIN EQUIPMENT eq ON (eq.EQUIPMENT_ID = urm.RIG_ID)'
							+' WHERE u.USER_INACTIVE = 0 and u.TENANT_ID=1 and u.USER_ID = '+id

				break;
			case 'equipmentSensors':
				queryString = 	' SELECT DISTINCT s.SENSOR_ID AS sensorId,se.SENSOR_LOCATION AS sensorLocation'+
								' FROM SENSOR s'+
								' JOIN SENSOR_EQUIPMENT se ON (se.SENSOR_ID = s.SENSOR_ID)'+
								' JOIN EQUIPMENT e ON (e.EQUIPMENT_ID = se.EQUIPMENT_ID AND e.ACTIVE = 1)'+
								' WHERE e.EQUIPMENT_ID = '+id+' and s.TENANT_ID = 1 AND e.TENANT_ID = 1';
				break;
			case 'equip_params':
				queryString = ' SELECT eds.SPEC_DESC AS name,eds.MIN_VALUE AS minthresh,eds.MAX_VALUE AS maxthresh,eds.REFERENCE_VALUE AS "avg",eds.MINIMUM_DEVIATION AS mindev,eds.MAXIMUM_DEVIATION AS maxdev,eds.AVERAGE_DEVIATION AS avgdev,eds.REFERENCE_VALUE_UOM AS uom'+
								' FROM EQUIPMENT_DESIGN_SPEC eds'+
								' WHERE eds.EQUIPMENT_ID = '+id+' and eds.TENANT_ID = 1';
				break;
			case 'sensor':
				queryString = ' SELECT s.SENSOR_ID AS "Sensor MAC ID",s.SENSOR_NAME AS \'Sensor Name\',s.SENSOR_DESC AS Description,ba.BUSINESS_ASSOCIATE_ID AS Manufacturer'+
								' FROM SENSOR s'+
								' JOIN BUSINESS_ASSOCIATE ba ON(s.MANUFACTURER_ID = ba.BUSINESS_ASSOCIATE_ID)'+
								' WHERE s.SENSOR_ID LIKE \'%'+id+'%\' and s.TENANT_ID=1'
				break;
			case 'sensor_params':
				queryString = 'SELECT sa.ATTR_ID AS "attrId", asa.ATTR_NAME AS "name",sa.MINIMUM_DEVIATION AS mindev,sa.MAXIMUM_DEVIATION AS maxdev,sa.AVERAGE_DEVIATION AS avgdev,sa.MINIMUM_THRESHOLD AS minthresh,sa.MAXIMUM_THRESHOLD AS maxthresh,sa.AVERAGE_VALUE AS "avg",sa.ATTR_UOM AS uom'+
								' FROM SENSOR_ATTRIBUTE sa JOIN ATTRIBUTE_CATALOGUE asa ON (asa.ATTR_ID = sa.ATTR_ID)'+
								' WHERE sa.TENANT_ID=1 and  SENSOR_ID = \''+id+'\'';
				break;
			case 'Maintenance':
			 	queryString='select ast.ASSET_ID, ast.ASSET_NAME, ar.AREA_ID, ar.PREFERRED_NAME as Area_name, r.RIG_ID, r.RIG_NAME, re.EQUIPMENT_ID, eqp.DESCRIPTION as eqp_type, eqp.EQUIPMENT_NAME'
							+' from  ASSET ast'
							+' join ASSET_AREA_MAP aam on (ast.ASSET_ID=aam.ASSET_ID)'
							+' join AREA ar on (aam.AREA_ID=ar.AREA_ID )'
							+' join WELL wl on (wl.AREA_ID=ar.AREA_ID)'
							+' join RIG_WELL_MAP rwm on (rwm.UWI=wl.UWI)'
							+' join RIG r on (r.RIG_ID=rwm.RIG_ID)'
							+' join RIG_EQUIPMENT re on (re.RIG_ID=r.RIG_ID)'
							+' join EQUIPMENT eqp on (eqp.EQUIPMENT_ID=re.EQUIPMENT_ID)'
							+' where ast.TENANT_ID=1 and eqp.EQUIPMENT_ID LIKE ' +id;
			 	break;
			 case 'activityChecklist':
			 	queryString='select distinct ema.EQUIP_ACT_ID,  at.ACTIVITY_ID, ma.ACTIVITY_NAME ,'
						+' em.MAINT_TYPE_ID, ema.SCHEDULED_START_DATE, ema.SCHEDULED_END_DATE, em.ASSIGNEE_ID as \'Assignee Id\'  ,'
						+' concat(u.USER_FIRST_NAME ,\' \', u.USER_LAST_NAME) as Assignee'
						+' from EQUIPMENT_MAINTENANCE_ACTIVITY ema '
						+' join EQUIPMENT_MAINTAIN em on (em.EQUIP_ACT_ID=ema.EQUIP_ACT_ID AND em.MAINTAIN_STATUS_ID != -9999)'
						+' join ACTIVITY_TRACKER at on  at.EQUIP_MAINT_ID=em.EQUIP_MAINT_ID'
						+' join MAINTENANCE_ACTIVITY ma on ma.ACTIVITY_ID=at.ACTIVITY_ID'
						+' join "User" u on em.ASSIGNEE_ID=u.USER_ID'
						+' where ema.EQUIP_ACT_ID='+id +'and ma.ACTIVITY_INACTIVE=0 and ma.TENANT_ID=1';
			 	break;
			}
		return new Promise(function(fulfill,reject){
			new mssql.Request().query(queryString).then(function(recordset){
				//console.log(recordset);
				if(type == 'user'){
					var queryString2;
					if(recordset[0].EQUIPMENT_ID!=undefined && recordset[0].EQUIPMENT_ID !=null){
						queryString2 = ' SELECT ASS.ASSET_ID,ASS.ASSET_NAME , A.AREA_ID,A.PREFERRED_NAME AS "Area_Name" ,R.RIG_ID,R.RIG_NAME,'+
										' E.DESCRIPTION AS "Equipment_Type",E.EQUIPMENT_ID,E.EQUIPMENT_NAME'+
										' FROM EQUIPMENT E'+
										' JOIN RIG_EQUIPMENT RE ON (RE.EQUIPMENT_ID = E.EQUIPMENT_ID AND E.EQUIPMENT_ID = '+recordset[0].EQUIPMENT_ID+')'+
										' JOIN RIG R ON (R.RIG_ID = RE.RIG_ID)'+
										' JOIN RIG_WELL_MAP RWM ON (R.RIG_ID = RWM.RIG_ID)'+
										' JOIN WELL W ON (W.UWI = RWM.UWI)'+
										' JOIN AREA A ON (A.AREA_ID = W.AREA_ID)'+
										' JOIN ASSET_AREA_MAP AAM ON (AAM.AREA_ID = A.AREA_ID)'+
										' JOIN ASSET ASS ON (ASS.ASSET_ID = AAM.ASSET_ID)';
					}
					else if(recordset[0].RIG_ID!=undefined && recordset[0].RIG_ID !=null){
						queryString2 = ' SELECT ASS.ASSET_ID,ASS.ASSET_NAME , A.AREA_ID,A.PREFERRED_NAME AS "Area_Name" ,R.RIG_ID,R.RIG_NAME'+
										' FROM RIG R '+
										' JOIN RIG_WELL_MAP RWM ON (R.RIG_ID = RWM.RIG_ID AND R.RIG_ID = '+recordset[0].RIG_ID+')'+
										' JOIN WELL W ON (W.UWI = RWM.UWI)'+
										' JOIN AREA A ON (A.AREA_ID = W.AREA_ID)'+
										' JOIN ASSET_AREA_MAP AAM ON (AAM.AREA_ID = A.AREA_ID)'+
										' JOIN ASSET ASS ON (ASS.ASSET_ID = AAM.ASSET_ID)';
					}
					else if(recordset[0].AREA_ID!=undefined && recordset[0].AREA_ID !=null){
						queryString2 = ' SELECT ASS.ASSET_ID,ASS.ASSET_NAME , A.AREA_ID,A.PREFERRED_NAME AS "Area_Name" '+
										' FROM AREA A'+
										' JOIN ASSET_AREA_MAP AAM ON (AAM.AREA_ID = A.AREA_ID AND A.AREA_ID = '+recordset[0].AREA_ID+')'+
										' JOIN ASSET ASS ON (ASS.ASSET_ID = AAM.ASSET_ID)';
					}
					if(queryString2!=undefined && queryString2!=null){
						new mssql.Request().query(queryString2).then(function(recordsets){
							if(recordsets[0]!=undefined && recordsets[0]!=null && recordset[0]!=undefined && recordset[0]!=null){
								if(recordset[0].EQUIPMENT_ID!=undefined && recordset[0].EQUIPMENT_ID !=null){
									//console.log(recordsets);
									for(var i=0;i<recordset.length;i++){
										recordset[i].ASSET_ID = recordsets[0].ASSET_ID;
										recordset[i].ASSET_NAME = recordsets[0].ASSET_NAME;
										recordset[i].AREA_ID = recordsets[0].AREA_ID;
										recordset[i].Area_Name = recordsets[0].Area_Name;
										recordset[i].RIG_ID = recordsets[0].RIG_ID;
										recordset[i].RIG_NAME = recordsets[0].RIG_NAME;
									}
								}else if(recordset[0].RIG_ID!=undefined && recordset[0].RIG_ID !=null){
									for(var i=0;i<recordset.length;i++){
										recordset[i].ASSET_ID = recordsets[0].ASSET_ID;
										recordset[i].ASSET_NAME = recordsets[0].ASSET_NAME;
										recordset[i].AREA_ID = recordsets[0].AREA_ID;
										recordset[i].Area_Name = recordsets[0].Area_Name;
										recordset[i].RIG_ID = recordsets[0].RIG_ID;
										recordset[i].RIG_NAME = recordsets[0].RIG_NAME;
									}
								}else if(recordset[0].AREA_ID!=undefined && recordset[0].AREA_ID !=null){
									
									for(var i=0;i<recordset.length;i++){
										recordset[i].ASSET_ID = recordsets[0].ASSET_ID;
										recordset[i].ASSET_NAME = recordsets[0].ASSET_NAME;
										recordset[i].AREA_ID = recordsets[0].AREA_ID;
										recordset[i].Area_Name = recordsets[0].Area_Name;
										recordset[i].RIG_ID = recordsets[0].RIG_ID;
										recordset[i].RIG_NAME = recordsets[0].RIG_NAME;
									}
								}

								return fulfill(recordset);
							}
							else{
								return reject({errorMessage:"Sorry! Could not fetch the json 1"});
							}
							
						}).catch(function(err){
							return reject(err);
						});
					}
					else{
						return reject({errorMessage:"Sorry! Could not fetch the json 2"});
					}	
				}
				else{
					return fulfill(recordset);	
				}
				
			}).catch(function(err){
				
				return reject(err);
			});
		});
	}

	exports.editConfiguratorTables = editConfiguratorTables;

	//get data for all the dropdowns in the app
	var getConfigDropDown = function(type){
		var queryString = "";
		switch(type){
			case 'UOM':
				queryString = "SELECT DISTINCT UOM_ID, UOM_NAME, UOM_TYPE FROM PPDM_UNIT_OF_MEASURE WHERE UOM_TYPE IN ('length','mass')";
				break;
			case 'Rig':
				queryString = "SELECT DISTINCT RIG_ID,RIG_NAME FROM RIG r WHERE TENANT_ID = 1 AND ACTIVE = 1";
				break;
			case 'Area':
				queryString = "SELECT AREA_ID ,PREFERRED_NAME FROM AREA where ACTIVE=1 and TENANT_ID=1";
				break;
			case 'Asset':
				queryString = "SELECT ASSET_ID, ASSET_NAME FROM ASSET where ASSET_INACTIVE=0 and TENANT_ID=1";
				break;
			case 'Rig Category':
				queryString = "SELECT RIG_CATEGORY, LONG_NAME FROM RIG_CATEGORY";
				break;
			case 'Rig Class':
				queryString = "SELECT RIG_CLASS, LONG_NAME FROM RIG_CLASS";
				break;
			case 'Rig Code':
				queryString = "SELECT RIG_CODE, LONG_NAME FROM RIG_CODE";
				break;
			case 'Rig Type':
				queryString = "SELECT RIG_TYPE, LONG_NAME FROM RIG_TYPE";
				break;
			case 'User Name':
				queryString = 'SELECT USER_ID, USER_DISPLAY_NAME FROM \"USER\" where USER_INACTIVE=0 and TENANT_ID=1';
				break;
			case "Well Status":
				queryString = 'SELECT WELL_STATUS_ID,LONG_NAME FROM WELL_STATUS';
				break;
			case "Country":
				queryString = 'SELECT COUNTRY,LONG_NAME FROM COUNTRY';
				break;
			case "County":
				queryString = 'SELECT COUNTY,LONG_NAME FROM COUNTY';
				break;
			case "Depth Datum Type":
				queryString = 'SELECT WELL_DATUM_TYPE_ID,LONG_NAME FROM WELL_DATUM_TYPE';
				break;
			case "userMasterData":
				queryString = 'select ROLE_ID,ROLE_NAME from ROLE where ROLE_NAME !=\'Administrator\' and TENANT_ID=1';
				break;
			case "Rig":
				queryString = 'SELECT r.RIG_ID,RIG_NAME FROM RIG r JOIN RIG_WELL_MAP rwm ON (r.RIG_ID = rwm.RIG_ID AND rwm.ACTIVE = 1) where r.TENANT_ID=1';
				break;
			case "Manufacturer":
				queryString = 'SELECT ba.BUSINESS_ASSOCIATE_ID, ba.BA_NAME FROM BUSINESS_ASSOCIATE ba WHERE ba.ACTIVE = 1';
				break;
			case 'Description':
				queryString = 'SELECT DISTINCT e.DESCRIPTION AS VALUE,e.DESCRIPTION AS ITEM FROM EQUIPMENT e where e.TENANT_ID=1';
				break;
			case 'Well':
				queryString = 'SELECT DISTINCT UWI,WELL_NAME FROM WELL WHERE ACTIVE = 1 and TENANT_ID=1';
				break;
			case 'Operator':
				queryString = 'SELECT DISTINCT BUSINESS_ASSOCIATE_ID, BA_NAME FROM BUSINESS_ASSOCIATE WHERE ACTIVE = 1';
				break;
			case 'Mast Type':
				queryString = 'SELECT DISTINCT MAST_TYPE,LONG_NAME FROM RIG_MAST';
				break;
		}
		return new Promise(function(fulfill,reject){
			//if(dropDownConfig[type.toLowerCase()]==undefined){
				new mssql.Request().query(queryString).then(function(recordset){
					//dropDownConfig[type.toLowerCase()] = recordset;
					return fulfill(recordset);
				}).catch(function(err){
					
					return reject(err);
				});
			// }
			// else{
			// 	return fulfill(dropDownConfig[type.toLowerCase()]);
			// }
		});
	}

	exports.getConfigDropDown = getConfigDropDown;

	//get all the roles applicable to the users
	var getAllRoles = function(){
		var queryString = "SELECT ROLE_NAME,ROLE_ID FROM ROLE where TENANT_ID=1";
		return new Promise(function(fulfill,reject){
			new mssql.Request().query(queryString).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				
				return reject(err);
			});
		});
	}

	exports.getAllRoles = getAllRoles;

	//authenticate the user before logging in
	var authenticateUser = function(username,password,role){
		var queryString = 'SELECT ro.ROLE_ID,urm.RIG_ID,u.USER_ID as Id ,concat(u.USER_FIRST_NAME,\' \',u.USER_LAST_NAME) as Name, u.USER_EMAIL as Email,'+
						'u.USER_CONTACT_NUMBER as Number, ro.ROLE_NAME as Role,u.USER_PASSWORD as password,'+
						' 	CASE'+
						'	WHEN urm.URM_ROLE_ID = 4 THEN a.ASSET_NAME'+
						'	WHEN urm.URM_ROLE_ID = 1 THEN ar.PREFERRED_NAME'+
						'	WHEN urm.URM_ROLE_ID = 2 THEN r.RIG_NAME'+
						'	WHEN urm.URM_ROLE_ID = 3 THEN eq.EQUIPMENT_NAME'+
						'	ELSE \'N/A\''+
						'	END AS Owner'+
						' FROM "USER" u'+
						' JOIN RIG_USER_ROLE_MAP urm ON (u.USER_ID = urm.URM_USER_ID AND urm.URM_INACTIVE = 0)'+
						' JOIN ROLE ro ON (ro.ROLE_ID = urm.URM_ROLE_ID)'+
						' LEFT JOIN ASSET a ON (a.ASSET_ID = urm.RIG_ID)'+
						' LEFT JOIN AREA ar ON  (ar.AREA_ID = urm.RIG_ID)'+
						' LEFT JOIN RIG r ON (r.RIG_ID = urm.RIG_ID)'+
						' LEFT JOIN EQUIPMENT eq ON (eq.EQUIPMENT_ID = urm.RIG_ID)'+
						' WHERE u.USER_INACTIVE = 0'+
						' AND urm.URM_ROLE_ID = '+role+' AND u.USER_EMAIL = \''+username+'\' and u.TENANT_ID=1';
		
		
		return new Promise(function(fulfill,reject){
			
			new mssql.Request().query(queryString).then(function(recordset){
			
				if(recordset!=undefined && recordset !=null && recordset.length!=0){
					if(bcrypt.compareSync(password,recordset[0].password)){
						
						return fulfill(recordset);
					}
					else{
						
						return fulfill({errorMessage:"Invalid Password"});
					}
				}
				else{
					return fulfill(recordset);
				}

			}).catch(function(err){
				
				return reject(err);
			});
		});
	}

	exports.authenticateUser = authenticateUser;

	//get master data for the user config page and other pages as needed 
	var getUserMasterData=function(type,assetId,areaId,rigId,equipType){
		
		return new Promise(function(fulfill,reject){
			var query="";
			switch(type){
				case 'asset':
					query="select ASSET_ID, ASSET_NAME from ASSET where ASSET_INACTIVE=0 and TENANT_ID=1";
					break;

				case 'area':
					query='select ar.AREA_ID, ar.PREFERRED_NAME'
						+' from  ASSET ast'
						+' join ASSET_AREA_MAP aam on (ast.ASSET_ID=aam.ASSET_ID)'
						+' join AREA ar on (aam.AREA_ID=ar.AREA_ID )'
						+' where ast.ASSET_ID = '+assetId+' and ar.ACTIVE=1 and ar.TENANT_ID=1'
					break;

				case 'rig':
				 query='select r.RIG_ID,r.RIG_NAME'
					+' from  ASSET ast'
					+' join ASSET_AREA_MAP aam on (ast.ASSET_ID=aam.ASSET_ID)'
					+' join AREA ar on (aam.AREA_ID=ar.AREA_ID )'
					+' join WELL wl on (wl.AREA_ID=ar.AREA_ID)'
					+' join RIG_WELL_MAP rwm on (rwm.UWI=wl.UWI)'
					+' join RIG r on (r.RIG_ID=rwm.RIG_ID)'
					+' where ast.ASSET_ID = '+assetId+' and ar.AREA_ID ='+areaId+' and r.ACTIVE=1 and r.TENANT_ID=1'
					break;

				case 'equipType':
				 query='select distinct eqp.DESCRIPTION'
					+' from  ASSET ast '
					+' join ASSET_AREA_MAP aam on (ast.ASSET_ID=aam.ASSET_ID)'
					+' join AREA ar on (aam.AREA_ID=ar.AREA_ID )'
					+' join WELL wl on (wl.AREA_ID=ar.AREA_ID)'
					+' join RIG_WELL_MAP rwm on (rwm.UWI=wl.UWI)'
					+' join RIG r on (r.RIG_ID=rwm.RIG_ID AND r.ACTIVE = 1)'
					+' join RIG_EQUIPMENT re on (re.RIG_ID=r.RIG_ID AND re.ACTIVE = 1)'
					+' join EQUIPMENT eqp on (eqp.EQUIPMENT_ID=re.EQUIPMENT_ID AND eqp.ACTIVE = 1)'
					+' where ast.ASSET_ID = '+assetId+' and ar.AREA_ID = '+areaId+' and r.RIG_ID ='+rigId+' and eqp.TENANT_ID=1'
					break;

				case 'equipment':
					query="select DISTINCT eqp.EQUIPMENT_ID, eqp.EQUIPMENT_NAME"
					+" from  ASSET ast "
					+" join ASSET_AREA_MAP aam on (ast.ASSET_ID=aam.ASSET_ID)"
					+" join AREA ar on (aam.AREA_ID=ar.AREA_ID )"
					+" join WELL wl on (wl.AREA_ID=ar.AREA_ID)"
					+" join RIG_WELL_MAP rwm on (rwm.UWI=wl.UWI)"
					+" join RIG r on (r.RIG_ID=rwm.RIG_ID AND r.ACTIVE = 1)"
					+" join RIG_EQUIPMENT re on (re.RIG_ID=r.RIG_ID AND re.ACTIVE = 1)"
					+" join EQUIPMENT eqp on (eqp.EQUIPMENT_ID=re.EQUIPMENT_ID AND eqp.ACTIVE = 1)"
					+" where ast.ASSET_ID = "+assetId+" and ar.AREA_ID ="+areaId+" and r.RIG_ID ="+rigId+" and LOWER(eqp.DESCRIPTION) LIKE '%"+equipType.toLowerCase()+"%' and eqp.TENANT_ID=1"
					break;

				case 'assignee':
				 query='select DISTINCT USER_ID , concat(u.USER_FIRST_NAME ,\' \', u.USER_LAST_NAME) as AssigneeName'
					+' from "USER" u'
					+' join RIG_USER_ROLE_MAP rurm on (u.USER_ID = rurm.URM_USER_ID AND rurm.URM_INACTIVE = 0)'
					+' where u.USER_INACTIVE=0 and u.TENANT_ID=1 and rurm.URM_ROLE_ID=3';
				 break;

				 case 'type':
					query='select emt.MAINT_TYPE_ID as id, emt.LONG_NAME as name'
							+' from EQUIPMENT_MAINT_TYPE emt';
					break;
				 }
				 
			new mssql.Request().query(query).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				
				return reject(err);
			})
		});
	};

	exports.getUserMasterData=getUserMasterData;

	//get the rig to which equipment is deployed
	var getEquipmentProvisionData = function(equipmentId){
		var queryString = 'SELECT r.RIG_ID'+
							' FROM RIG_EQUIPMENT re'+
							' JOIN RIG r ON (r.RIG_ID = re.RIG_ID AND r.ACTIVE = 1)'+
							' WHERE re.TENANT_ID=1 and re.EQUIPMENT_ID = '+equipmentId+' AND re.ACTIVE = 1';
		return new Promise(function(fulfill,reject){
			new mssql.Request().query(queryString).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				
				return reject(err);
			});
		});
	}

	exports.getEquipmentProvisionData = getEquipmentProvisionData;

	var options;
	var getTheJsonData = function(type,obj){
    	obj=JSON.parse(obj);
    	if(obj.password!=undefined && obj.password !=null){
    		obj.password = bcrypt.hashSync(obj.password,salt);
    	}
		
    	options = {
    		 url: basePath+'/insertData/'+type,
		     body: JSON.stringify(obj),
		      headers: {
			      'Content-Type': 'application/json'
			    },
		     method: 'POST'
    	};

        return new Promise(function(fulfill,reject){
            request(options, function (error, response, body) {
                if (!error && response.statusCode == 200) {
                   if(body.includes('Done')){
                		if(type=='activity'){
                    		dropDownConfig['maintenance'] = undefined;
							configurationTables['maintenance'] = undefined;
                    	}else{
                    		dropDownConfig[type.toLowerCase()] = undefined;
							configurationTables[type.toLowerCase()] = undefined;
                    	}
						sensorGraphs = {};
                	}
                    return fulfill(body);
                }

                if(error){
					if(error.code == "ECONNREFUSED"){
						return reject("ECONNREFUSED: Failure to connect to DB services.");
					}else{
						return reject(error);
					}
                }
            });
        });
    }
    exports.getTheJsonData = getTheJsonData;

	var disassociateRig = function(id){
		var options = {
    		 url: basePath+'/disassociateRig/'+id,
		     method: 'GET'
    	};

		return new Promise(function(fulfill,reject){
            request(options, function (error, response, body) {
                if (!error && response.statusCode == 200) {
                   if(body.includes('Done')){
                		// if(type=='activity'){
                    	// 	dropDownConfig['maintenance'] = undefined;
						// 	configurationTables['maintenance'] = undefined;
                    	// }else{
                    	// 	dropDownConfig[type.toLowerCase()] = undefined;
						// 	configurationTables[type.toLowerCase()] = undefined;
                    	// }
						// sensorGraphs = {};
						return fulfill(body);
                	}
                    return fulfill("There has been a problem in deassociating the rig. Please try again in a while.");
                }

                if(error){
                   return reject(error);
                }
            });
        });
	}

	exports.disassociateRig = disassociateRig;
	
	var storeFilePath = function(obj){

		var options = {
    		 url: basePath+'/insertManual',
		     body: JSON.stringify(obj),
		      headers: {
			      'Content-Type': 'application/json'
			    },
		     method: 'POST'
    	};

		return new Promise(function(fulfill,reject){
            request(options, function (error, response, body) {
                if (!error && response.statusCode == 200) {
                    return fulfill(body);
                }

                if(error){
                   return reject(error);
                }
            });
        });
	}

	 exports.storeFilePath = storeFilePath;

	var editTheJsonData = function(type,obj){
	        options = {
		        url: basePath+'/updateData/'+type,
		   		body: obj,
			    headers: {
			     	'Content-Type': 'application/json'
			   	},
		    	method: 'POST'
	        };

	        return new Promise(function(fulfill,reject){

	            request(options, function (error, response, body) {
	            
	                if (!error && response.statusCode == 200) {
	                    if(body.includes('Done')){
	                    	if(type=='activity'){
	                    		dropDownConfig['maintenance'] = undefined;
								configurationTables['maintenance'] = undefined;
	                    	}else{
	                    		dropDownConfig[type.toLowerCase()] = undefined;
								configurationTables[type.toLowerCase()] = undefined;
	                    	}
							sensorGraphs = {};
	                	}
	                    return fulfill(body);
	                }

	                if(error.code == "ECONNREFUSED"){
						return reject("ECONNREFUSED: Failure to connect to DB services.");
					}else{
						return reject(error);
					}
	            });
	        });
	    }
	    exports.editTheJsonData = editTheJsonData;

    var updateEquipmentStatus = function(obj){
       options = {
		        url: basePath+'/updateStatus',
		   		body: obj,
			    headers: {
			     	'Content-Type': 'application/json'
			   	},
		    	method: 'POST'
	        };

	        return new Promise(function(fulfill,reject){
	            request(options, function (error, response, body) {
	                if (!error && response.statusCode == 200) {
	                	if(body.includes('Done')){
	                		dropDownConfig['equipment'] = undefined;
							configurationTables['equipment'] = undefined;
							sensorGraphs = {};
	                	}
	                    return fulfill(body);
	                }

	                if(error){
	                   return reject(error);
	                }
	            });
	        });
    }
    exports.updateEquipmentStatus = updateEquipmentStatus;

    var deleteTheJsonData = function(type,obj){
        return new Promise(function(fulfill,reject){
        	var obj1 = JSON.parse(obj);

            request(basePath+'/deleteData/'+type+'/'+JSON.stringify(obj1), function (error, response, body) {
                if (!error && response.statusCode == 200) {
                	if(body.includes('Done')){
	                	if(type == 'activity'){
	                		dropDownConfig['maintenance'] = undefined;
							configurationTables['maintenance'] = undefined;
	                	}else{
	                		dropDownConfig[type.toLowerCase()] = undefined;
							configurationTables[type.toLowerCase()] = undefined;
	                	}
						sensorGraphs = {};
                	}
					else{
						dropDownConfig[type.toLowerCase()] = undefined;
						configurationTables[type.toLowerCase()] = undefined;
						sensorGraphs = {};
					}
                    return fulfill(body);
                }
                else if(error.code == "ECONNREFUSED"){
					return reject("ECONNREFUSED: Failure to connect to DB services.");
				}else{
					return reject(error);
				}
            });
        });
    }
	
    exports.deleteTheJsonData = deleteTheJsonData;
	
	//get available parameters for the sensors given the type
	var getAvailableParameters = function(type){
		
		var queryString = 'SELECT DISTINCT ATTR_NAME AS Value,ATTR_NAME AS Item,ATTR_ID AS attrId,ATTR_UOM_TYPE AS type,ppdm.UOM_ID,ppdm.UOM_NAME '+
						'FROM ATTRIBUTE_CATALOGUE ac '+
						'JOIN PPDM_UNIT_OF_MEASURE ppdm ON(ac.ATTR_UOM_TYPE = ppdm.UOM_TYPE) '+
						'WHERE LOWER(ATTR_TYPE) = \''+type.toLowerCase()+'\' AND TENANT_ID = 1';

		return new Promise(function(fulfill,reject){
			//if(parameterList[type.toLowerCase()]==undefined){
				new mssql.Request().query(queryString).then(function(recordset){
					// parameterList[type.toLowerCase()]=recordset;
					// if(type.toLowerCase()==""){
					// 	parameterList['all'] = recordset;
					// }else{
					// 	parameterList[type.toLowerCase()] = recordset;
					// }
					return fulfill(recordset);
				}).catch(function(err){
					
					return reject(err);
				});
			// }else{
			// 	if(type.toLowerCase()==""){
			// 		return fulfill(parameterList['all']);
			// 	}else{
			// 		return fulfill(parameterList[type.toLowerCase()]);
			// 	}
			// }
		});
	};

	exports.getAvailableParameters = getAvailableParameters;
	
	//get all the units for the parameters
	var getAvailableUoms = function(){
		var queryString = 'SELECT DISTINCT UOM_ID,UOM_NAME FROM PPDM_UNIT_OF_MEASURE';
		return new Promise(function(fulfill,reject){
			new mssql.Request().query(queryString).then(function(recordset){
					return fulfill(recordset);
				}).catch(function(err){
					
					return reject(err);
				});
		});
	}
	
	exports.getAvailableUoms = getAvailableUoms;
	
	//get well attributes for well configuration
	var getWellAttributes = function(id){
        var queryString = "SELECT wa.ATTR_VALUE, ac.ATTR_DESC, puom.UOM_QUANTITY_TYPE"+
							" FROM WELL_ATTRIBUTES wa"+
							" JOIN ATTRIBUTE_CATALOGUE ac ON (wa.ATTR_ID = ac.ATTR_ID)"+
							" JOIN RIG_WELL_MAP rwm ON (rwm.UWI = wa.UWI)"+
							" left JOIN PPDM_UNIT_OF_MEASURE puom ON (puom.UOM_ID = ac.ATTR_UOM)"+
							" WHERE rwm.UWI = "+id;

        return new Promise(function(fulfill,reject){
            new mssql.Request().query(queryString).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				
				return reject(err);
            });
        });
	}
	
	exports.getWellAttributes = getWellAttributes;
	
	//get well attributes ofrig for displaying in rig page 
	var getRigWellAttributes = function(id){
        var queryString = "SELECT wa.ATTR_VALUE,ac.ATTR_DESC,puom.UOM_QUANTITY_TYPE"+
							" FROM WELL_ATTRIBUTES wa"+
							" JOIN ATTRIBUTE_CATALOGUE ac ON (wa.ATTR_ID = ac.ATTR_ID)"+
							" left JOIN PPDM_UNIT_OF_MEASURE puom ON (puom.UOM_ID = ac.ATTR_UOM)"+
							" JOIN RIG_WELL_MAP rwm ON (rwm.UWI = wa.UWI)"+
							" WHERE rwm.RIG_ID = "+id;
        return new Promise(function(fulfill,reject){
            new mssql.Request().query(queryString).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
            });
        });
	}

	exports.getRigWellAttributes = getRigWellAttributes;

	//get data for the bird eye view
	var getBirdEyeViewData = function(type,id){
		var queryString = "";
		switch(type){
			case 'area':
				queryString = "SELECT DISTINCT"+
							" CASE"+
								" WHEN LOWER(e.DESCRIPTION) = 'generator' THEN 'G'"+
								" WHEN LOWER(e.DESCRIPTION) = 'compressor' THEN 'C'"+
								" WHEN LOWER(e.DESCRIPTION) = 'mud pump' THEN 'M'"+
								" WHEN LOWER(e.DESCRIPTION) = 'agitator' THEN 'A'"+
								" WHEN LOWER(e.DESCRIPTION) = 'shaker' THEN 'S'"+
								" WHEN LOWER(e.DESCRIPTION) = 'drawworks' THEN 'D'"+
							" END AS type,e.EQUIPMENT_NAME AS des, Min(em.SCHEDULED_START_DATE) AS next_date , count(distinct ei.EQUIP_INCIDENT_ID) AS inc_count,e.EQUIP_STATUS_ID"+
							" FROM EQUIPMENT e"+
							" JOIN RIG_EQUIPMENT re ON (re.EQUIPMENT_ID = e.EQUIPMENT_ID AND re.ACTIVE = 1)"+
							" LEFT JOIN EQUIPMENT_MAINTAIN em ON (em.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID AND em.MAINT_TYPE_ID = 9903 AND em.MAINTAIN_STATUS_ID != -9999 AND (em.SCHEDULED_START_DATE >= GETUTCDATE() OR em.SCHEDULED_START_DATE IS NULL))"+
							" LEFT JOIN EQUIPMENT_INCIDENT ei ON (ei.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID AND ei.INCIDENT_STATUS = 0)"+
							" JOIN RIG_WELL_MAP rwm ON (rwm.RIG_ID = re.RIG_ID)"+
							" JOIN WELL w ON (w.UWI = rwm.UWI)"+
							" JOIN AREA a ON (a.AREA_ID = w.AREA_ID)"+
							" WHERE a.AREA_ID = "+id+
							" group by e.EQUIPMENT_NAME, e.DESCRIPTION,e.EQUIP_STATUS_ID"+
							" ORDER BY type";

				break;
			case 'rig':
				queryString = "SELECT DISTINCT"+
							" CASE"+
								" WHEN LOWER(e.DESCRIPTION) = 'generator' THEN 'G'"+
								" WHEN LOWER(e.DESCRIPTION) = 'compressor' THEN 'C'"+
								" WHEN LOWER(e.DESCRIPTION) = 'mud pump' THEN 'M'"+
								" WHEN LOWER(e.DESCRIPTION) = 'agitator' THEN 'A'"+
								" WHEN LOWER(e.DESCRIPTION) = 'shaker' THEN 'S'"+
								" WHEN LOWER(e.DESCRIPTION) = 'drawworks' THEN 'D'"+
							" END AS type,e.EQUIPMENT_NAME AS des, Min(em.SCHEDULED_START_DATE) AS next_date , count(distinct ei.EQUIP_INCIDENT_ID) AS inc_count,e.EQUIP_STATUS_ID"+
							" FROM EQUIPMENT e"+
							" JOIN RIG_EQUIPMENT re ON (re.EQUIPMENT_ID = e.EQUIPMENT_ID AND re.ACTIVE = 1)"+
							" LEFT JOIN EQUIPMENT_MAINTAIN em ON (em.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID AND em.MAINT_TYPE_ID = 9903 AND em.MAINTAIN_STATUS_ID != -9999 AND (em.SCHEDULED_START_DATE >= GETUTCDATE() OR em.SCHEDULED_START_DATE IS NULL))"+
							" LEFT JOIN EQUIPMENT_INCIDENT ei ON (ei.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID AND ei.INCIDENT_STATUS = 0)"+
							" WHERE re.RIG_ID = "+id+
							" group by e.EQUIPMENT_NAME, e.DESCRIPTION,e.EQUIP_STATUS_ID"+
							" ORDER BY type";
				break;
		}
        
        return new Promise(function(fulfill,reject){
            new mssql.Request().query(queryString).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				
				return reject(err);
            });
        });
	}

	exports.getBirdEyeViewData = getBirdEyeViewData;

	//get all available rigs for that area for bird eye view 
	var getAllRigsForArea = function(id){
        var queryString = "SELECT r.RIG_NAME,r.RIG_ID"+
							" FROM RIG r "+
							" JOIN RIG_WELL_MAP rwm ON (rwm.RIG_ID = r.RIG_ID AND r.ACTIVE = 1)"+
							" JOIN WELL w ON (w.UWI = rwm.UWI)"+
							" JOIN AREA a ON (a.AREA_ID = w.AREA_ID)"+
							" WHERE a.AREA_ID = "+id;
        return new Promise(function(fulfill,reject){
            new mssql.Request().query(queryString).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				
				return reject(err);
            });
        });
	}

	exports.getAllRigsForArea = getAllRigsForArea;

	//get all available rigs for that area for bird eye view 
	var getLatestCriticalParams = function(id){
        var queryString = 	' SELECT * FROM '+
							' (select ema.ATTR_VALUE, se.SENSOR_LOCATION, ppdm.UOM_QUANTITY_TYPE, ppdm.UOM_NAME,s.SENSOR_NAME,ema.SENSOR_ID,ema.MEASURED_DATE'+
							' from equipment_measurement_attribute ema'+
							' JOIN RIG_EQUIPMENT re ON (ema.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID)'+
							' JOIN ATTRIBUTE_CATALOGUE ac ON (ac.ATTR_ID = ema.ATTR_ID)'+
							' JOIN SENSOR_EQUIPMENT se ON (se.SENSOR_ID = ema.SENSOR_ID)'+
							' JOIN SENSOR s ON (se.SENSOR_ID = s.SENSOR_ID)'+
							' JOIN PPDM_UNIT_OF_MEASURE ppdm ON (ppdm.UOM_ID = ac.ATTR_UOM)'+
							' WHERE re.EQUIPMENT_ID = '+id+'AND ac.ATTR_DESC = \'Temperature\') a'
							' WHERE a.RANK1 < 2';
							// '  group by ema.SENSOR_ID, ema.attr_value, se.SENSOR_LOCATION, ppdm.UOM_NAME,ppdm.UOM_QUANTITY_TYPE,s.SENSOR_NAME,ema.MEASURED_DATE'+
							// '  having ema.MEASURED_DATE = '+
							// '  (select max(MEASURED_DATE) from equipment_measurement_attribute emas'+
							// '  JOIN ATTRIBUTE_CATALOGUE acs ON (acs.ATTR_ID = emas.ATTR_ID)'+
							// '  where sensor_id = ema.sensor_id AND acs.ATTR_DESC = \'Temperature\')';
		
        return new Promise(function(fulfill,reject){
            new mssql.Request().query(queryString).then(function(recordset){
				return fulfill(recordset);
			}).catch(function(err){
				return reject(err);
            });
        });
	}

	exports.getLatestCriticalParams = getLatestCriticalParams;

	//get top 400 events for admin view 
	var getEventLogsAdmin = function(id){
        var queryString = "SELECT TOP 400"+
                            " CASE"+ 
                            " WHEN EVENT_TYPE LIKE '%EQUI%' THEN 'Equipment'"+
                            " WHEN EVENT_TYPE LIKE '%WELL%' THEN 'Well'"+
                            " WHEN EVENT_TYPE LIKE '%RIG%' THEN 'Rig'"+
                            " WHEN EVENT_TYPE LIKE '%AREA%' THEN 'Area'"+
                            " WHEN EVENT_TYPE LIKE '%ASSET%' THEN 'Asset'"+
                            " WHEN EVENT_TYPE LIKE '%MAINT%' THEN 'Maintenance/Activity'"+
                            " WHEN EVENT_TYPE LIKE '%USER%' THEN 'User'"+
							" WHEN EVENT_TYPE LIKE '%SENS%' THEN 'Sensor'"+
                            " END AS NAME,"+
                            " EVENT_DESC,EVENT_DATETIME,EVENT_TYPE"+
                            " FROM EQUIPMENT_EVENT_LOG EEL"+
                            " LEFT JOIN RIG_EQUIPMENT RE ON (EEL.RIG_EQUIPMENT_ID = RE.RIG_EQUIPMENT_ID AND RE.TENANT_ID = 1)"+
                            " LEFT JOIN RIG R ON(EEL.RIG_EQUIPMENT_ID = R.RIG_ID AND R.TENANT_ID = 1)"+
                            " LEFT JOIN EQUIPMENT E ON (RE.EQUIPMENT_ID = E.EQUIPMENT_ID AND E.TENANT_ID = 1)"+
                            " LEFT JOIN WELL W ON (EEL.RIG_EQUIPMENT_ID = W.UWI AND W.TENANT_ID = 1)"+
                            " LEFT JOIN AREA A ON(EEL.RIG_EQUIPMENT_ID = A.AREA_ID AND A.TENANT_ID = 1)"+
                            " LEFT JOIN ASSET ASS ON(EEL.RIG_EQUIPMENT_ID = ASS.ASSET_ID AND ASS.TENANT_ID = 1)"+
                            " LEFT JOIN \"USER\" U ON(EEL.RIG_EQUIPMENT_ID = U.USER_ID AND U.TENANT_ID = 1)"+
                            " ORDER BY EVENT_DATETIME DESC";

        return new Promise(function(fulfill,reject){
			new mssql.Request().query(queryString).then(function(recordset){
					return fulfill(recordset);
	            }).catch(function(err){
                    
                    return reject(err);
	            });
	        });
		}

		exports.getEventLogsAdmin = getEventLogsAdmin;

		//get sensor data for graphs in equipment page
		var getEquipmentSensorData = function(equipmentId){
				// var queryString = ' select ema.MEASURED_DATE, ema.SENSOR_ID, ema.ATTR_VALUE, ema.ATTR_ID, ac.ATTR_DESC'+
									// ' from equipment_measurement_attribute ema'+
									// ' JOIN RIG_EQUIPMENT re ON (ema.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID)'+
									// ' JOIN ATTRIBUTE_CATALOGUE ac ON (ac.ATTR_ID = ema.ATTR_ID)'+
									// ' WHERE re.EQUIPMENT_ID = '+equipmentId+
									// ' group by ema.sensor_id, ema.attr_value, ema.meas_attr_id, ema.MEASURED_DATE, ema.ATTR_ID, ac.ATTR_DESC'+
									// ' having ema.meas_attr_id = ('+
									// ' select max(meas_attr_id) '+
									// ' from equipment_measurement_attribute emas '+
									// ' JOIN ATTRIBUTE_CATALOGUE acs ON (acs.ATTR_ID = emas.ATTR_ID) '+
									// ' where sensor_id = ema.sensor_id AND acs.ATTR_DESC = \'Blower Vibration\')'+
									// ' UNION'+
									// ' select ema.MEASURED_DATE, ema.SENSOR_ID, ema.ATTR_VALUE, ema.ATTR_ID, ac.ATTR_DESC'+
									// ' from equipment_measurement_attribute ema'+
									// ' JOIN RIG_EQUIPMENT re ON (ema.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID)'+
									// ' JOIN ATTRIBUTE_CATALOGUE ac ON (ac.ATTR_ID = ema.ATTR_ID)'+
									// ' WHERE re.EQUIPMENT_ID = '+equipmentId+
									// ' group by ema.sensor_id, ema.attr_value, ema.meas_attr_id, ema.MEASURED_DATE, ema.ATTR_ID, ac.ATTR_DESC'+
									// ' having ema.meas_attr_id = ('+
									// ' select max(meas_attr_id) '+
									// ' from equipment_measurement_attribute emas '+
									// ' JOIN ATTRIBUTE_CATALOGUE acs ON (acs.ATTR_ID = emas.ATTR_ID) '+
									// ' where sensor_id = ema.sensor_id AND acs.ATTR_DESC = \'Blower Vibration Status\')';
				// var queryString = ' SELECT * FROM (select ema.MEASURED_DATE, ema.SENSOR_ID, ema.ATTR_VALUE, ema.ATTR_ID, ac.ATTR_DESC,'+
				// 					' RANK() OVER (PARTITION BY ema.SENSOR_ID ORDER BY ema.MEASURED_DATE DESC) AS RANK'+
				// 					' FROM EQUIPMENT_MEASUREMENT_ATTRIBUTE ema '+
				// 					' JOIN RIG_EQUIPMENT re ON (re.RIG_EQUIPMENT_ID = ema.RIG_EQUIPMENT_ID AND re.ACTIVE = 1 AND re.TENANT_ID = 1)'+
				// 					' JOIN ATTRIBUTE_CATALOGUE ac ON (ac.ATTR_ID = ema.ATTR_ID AND ac.TENANT_ID = 1)'+
				// 					' WHERE re.EQUIPMENT_ID = '+equipmentId+' AND ac.ATTR_DESC = \'Blower Vibration\') a'+
				// 					' WHERE a.RANK < 150'+
				// 					' UNION'+
				// 					' select ema.MEASURED_DATE, ema.SENSOR_ID, ema.ATTR_VALUE, ema.ATTR_ID, ac.ATTR_DESC, 1 AS RANK'+
				// 					' from equipment_measurement_attribute ema'+
				// 					' JOIN RIG_EQUIPMENT re ON (ema.RIG_EQUIPMENT_ID = re.RIG_EQUIPMENT_ID)'+
				// 					' JOIN ATTRIBUTE_CATALOGUE ac ON (ac.ATTR_ID = ema.ATTR_ID)'+
				// 					' WHERE re.EQUIPMENT_ID = '+equipmentId+
				// 					' group by ema.sensor_id, ema.attr_value, ema.meas_attr_id, ema.MEASURED_DATE, ema.ATTR_ID, ac.ATTR_DESC'+
				// 					' having ema.meas_attr_id = ('+
				// 					' select max(meas_attr_id) '+
				// 					' from equipment_measurement_attribute emas '+
				// 					' JOIN ATTRIBUTE_CATALOGUE acs ON (acs.ATTR_ID = emas.ATTR_ID) '+
				// 					' where sensor_id = ema.sensor_id AND acs.ATTR_DESC = \'Blower Vibration Status\')'+
				// 					' ORDER BY MEASURED_DATE DESC';
				var queryString = "SELECT * FROM "+
									"(SELECT ema.MEASURED_DATE,ema.ATTR_VALUE,ema.ATTR_ID,ac.ATTR_DESC,ema.SENSOR_ID,re.RIG_EQUIPMENT_ID, "+
									"RANK() OVER (PARTITION BY ema.SENSOR_ID,ema.ATTR_ID ORDER BY ema.MEASURED_DATE DESC) AS ROW_NUM "+
									"FROM EQUIPMENT_MEASUREMENT_ATTRIBUTE ema "+
									"JOIN RIG_EQUIPMENT re ON (re.RIG_EQUIPMENT_ID = ema.RIG_EQUIPMENT_ID AND re.ACTIVE = 1 AND re.TENANT_ID = 1) "+
									"JOIN ATTRIBUTE_CATALOGUE ac ON (ac.ATTR_ID = ema.ATTR_ID AND ac.TENANT_ID = 1) "+
									"WHERE ac.ATTR_DESC IN ('Blower Vibration','Blower Vibration Status') AND re.EQUIPMENT_ID = "+equipmentId+") a "+
									"WHERE ROW_NUM < 150 ORDER BY MEASURED_DATE ASC";

			return new Promise(function(fulfill,reject){
				new mssql.Request().query(queryString).then(function(recordset){
					return fulfill(recordset);
				}).catch(function(err){
					return reject(err);
				});
	        });
		}

		exports.getEquipmentSensorData = getEquipmentSensorData;

		//get equipment sensor configuration details without data for equipment page
		var getEquipmentSensorStats = function(equipmentId,description){
			var queryString = ' SELECT DISTINCT e.DESCRIPTION, re.RIG_EQUIPMENT_ID, se.SENSOR_LOCATION,ac.ATTR_NAME,ppdm.UOM_NAME,se.SENSOR_ID,s.SENSOR_NAME,e.EQUIPMENT_NAME'+
								' FROM SENSOR_EQUIPMENT se'+
								' JOIN SENSOR_ATTRIBUTE sa ON (se.SENSOR_ID = sa.SENSOR_ID)'+
								' JOIN SENSOR s ON (se.SENSOR_ID = s.SENSOR_ID)'+
								' JOIN ATTRIBUTE_CATALOGUE ac ON (ac.ATTR_ID = sa.ATTR_ID)'+
								' JOIN PPDM_UNIT_OF_MEASURE ppdm ON (ppdm.UOM_ID = sa.ATTR_UOM)'+
								' JOIN EQUIPMENT e ON (e.EQUIPMENT_ID = se.EQUIPMENT_ID AND e.ACTIVE = 1 AND e.TENANT_ID = 1)'+
								' JOIN RIG_EQUIPMENT re ON (re.EQUIPMENT_ID = e.EQUIPMENT_ID AND re.ACTIVE = 1 AND re.TENANT_ID = 1)'+
								' WHERE re.EQUIPMENT_ID = '+equipmentId+' AND ac.ATTR_DESC = \''+description+'\'';

			
			return new Promise(function(fulfill,reject){
				new mssql.Request().query(queryString).then(function(recordset){
					return fulfill(recordset);
				}).catch(function(err){
					console.log(err);
					return reject(err);
				});
	        });
		}

		exports.getEquipmentSensorStats = getEquipmentSensorStats;

		//get historical data for the equipment config page
		var getSensorHistoricalData = function(sensorId,startDate,endDate){
			var queryString = ' SELECT ema.ATTR_VALUE,ac.ATTR_NAME,ema.MEASURED_DATE'+
								' FROM EQUIPMENT_MEASUREMENT_ATTRIBUTE ema'+
								' JOIN ATTRIBUTE_CATALOGUE ac ON (ac.ATTR_ID = ema.ATTR_ID AND ac.ATTR_DESC = \'Blower Vibration\')'+
								' WHERE ema.SENSOR_ID = \''+sensorId+'\''+
								' AND CAST(ema.MEASURED_DATE AS DATE) >= \''+startDate+'\' AND CAST(ema.MEASURED_DATE AS DATE) <= \''+endDate+'\'';
			console.log(queryString);			
			return new Promise(function(fulfill,reject){
				new mssql.Request().query(queryString).then(function(recordset){
					return fulfill(recordset);
				}).catch(function(err){
					return reject(err);
				});
	        });
		}

		exports.getSensorHistoricalData = getSensorHistoricalData;

		//get temperature historical data for the equipment config page
		var getTemperatureHistoricalData = function(sensorId,startDate,endDate){
			var queryString = ' SELECT ema.ATTR_VALUE,ac.ATTR_NAME,ema.MEASURED_DATE'+
								' FROM EQUIPMENT_MEASUREMENT_ATTRIBUTE ema'+
								' JOIN ATTRIBUTE_CATALOGUE ac ON (ac.ATTR_ID = ema.ATTR_ID AND ac.ATTR_DESC = \'Temperature\')'+
								' WHERE ema.SENSOR_ID = \''+sensorId+'\''+
								' AND CAST(ema.MEASURED_DATE AS DATE) >= \''+startDate+'\' AND CAST(ema.MEASURED_DATE AS DATE) <= \''+endDate+'\' ORDER BY ema.MEASURED_DATE';
								
			return new Promise(function(fulfill,reject){
				new mssql.Request().query(queryString).then(function(recordset){
					return fulfill(recordset);
				}).catch(function(err){
					return reject(err);
				});
	        });
		}

		exports.getTemperatureHistoricalData = getTemperatureHistoricalData;


		//get available sensors for the equipment config page
		var getAvailableSensors = function(){

			var queryString = ' SELECT s.SENSOR_ID AS Id,s.SENSOR_NAME AS Name'+
								' FROM SENSOR s'+
								' LEFT JOIN SENSOR_EQUIPMENT se ON (s.SENSOR_ID = se.SENSOR_ID)'+
								' where s.TENANT_ID=1 AND se.SENSOR_ID IS NULL ORDER BY CREATED_DATETIME DESC';

			return new Promise(function(fulfill,reject){
				new mssql.Request().query(queryString).then(function(recordset){
					return fulfill(recordset);
				}).catch(function(err){
					
					return reject(err);
				});
	        });
		}

		exports.getAvailableSensors = getAvailableSensors;

		//get uploaded manual name during editing in equipment config page
		var getEquipmentManualName = function(equipId){
			var queryString = "SELECT ARTIFACT_CONTENTS FROM EQUIPMENT_DESIGN_ARTIFACTS WHERE EQUIPMENT_ID = "+equipId;

			return new Promise(function(fulfill,reject){
				new mssql.Request().query(queryString).then(function(recordset){
					return fulfill(recordset);
				}).catch(function(err){
					
					return reject(err);
				});
	        });
		}

		exports.getEquipmentManualName = getEquipmentManualName;

		var updatePredictiveMaintenance = function(rigEquipmentId,comment,lastUser){
			var obj = {
				RigEquipmentId: rigEquipmentId,
				Remark: comment,
				LastUpdatedUserId: lastUser
			}

			var options = {
				url: pmPath + '/closePMActivity',
				method: 'POST',
				body: JSON.stringify(obj),
				headers: {
					'Content-Type': 'application/json'
				}
			}

			return new Promise(function(fulfill,reject){
				request(options, function (error, response, body) {
					if(!error && response.statusCode == 200){
						return fulfill(body);
					}

					if(error){
						return reject(error);
					}
				})
			})
		}

		exports.updatePredictiveMaintenance = updatePredictiveMaintenance;

		var getTempAlertState = function(rigEquipmentId,type){

			var obj = {
				"RigEquipmentId": rigEquipmentId,
				"Type": type
			}

			console.log(obj);

			var options = {
				url: pmPath +'/getTempState',
				body: JSON.stringify(obj),
				headers: {
					'Content-Type': 'application/json'
					},
				method: 'POST'
			};

			return new Promise(function(fulfill,reject){
				request(options, function (error, response, body) {
					if(!error && response.statusCode == 200){
						return fulfill(body);
					}

					if(error){
						return reject(error);
					}
				})
			})
		}
		exports.getTempAlertState = getTempAlertState;

		var getVibrationThresholds = function(equipDesc){
			var options = {
				url: pmPath +'/vibrationThreshold/'+equipDesc,
				method: 'GET'
			};

			return new Promise(function(fulfill,reject){
				request(options, function (error, response, body) {
					if(!error && response.statusCode == 200){
						return fulfill(body);
					}

					if(error){
						return reject(error);
					}
				})
			})
		}
		exports.getVibrationThresholds = getVibrationThresholds;
});

//console.log(bcrypt.hashSync("admin",salt));
