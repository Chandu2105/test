var express = require('express');
var http = require('http');


//edit config file to connect to PostgreSQL or MSSQL
var config = require('./config');

if (config.server == 'PG') {
	var db = require('./postgresqlData');
} else if (config.server == 'MSSQL') {
	var db = require('./mssqlDataProducer');
}


var path = require('path');
var app = express();
var os = require('os');
var favicon = require("serve-favicon");
var formidable = require('formidable');
var fs = require('fs');


app.use(favicon(path.join(__dirname, 'favicon.ico')));
app.use(express.static(__dirname + "/public"));
var listOfValues = {};

app.get('/', function (req, res) {
	res.sendFile(path.join(__dirname, '/public', 'index.html'));
});


const port = process.env.HOST_PORT || 8080;
app.listen(port);

//getting all external script files
app.use('/scripts', express.static(__dirname + '/node_modules'));

//getting data for the sidebar dropdown
app.get('/getDropDownMenu', function (req, res) {
	db.getDropDownMenu().then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (ew) {
		res.send(ew);
	});
});

app.get('/getConfiguratorDropDownMenu', function (req, res) {
	db.getConfigDropDown(req.query.type).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});

});

app.get('/getListOfValues', function (req, res) {
	res.setHeader('Access-Control-Allow-Origin', '*');
	res.send(listOfValues[req.query.type]);
});


//to fetch Genset Specifications
app.get('/gensetSpecifications', function (req, res) {
	db.getGensetSpecifications(req.query.type).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

//to fetch Genset Parameters Data
app.get('/gensetParameters', function (req, res) {
	db.getGensetParameters(req.query.type).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

//to get all the maintenance data
app.get('/getMaintenanceScheduleData', function (req, res) {
	db.getMaintenanceScheduleData(req.query.type).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	})
});

//to get all the existing maintenance data for an equipment
app.get('/getExistingMaintenancesForEquipment', function (req, res) {
	db.getExistingMaintenancesForEquipment(req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	})
});

// to get last six instances of maintenance data
app.get('/getSixInstanceData', function (req, res) {
	db.getSixInstanceData(req.query.equip_id, req.query.equipType).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

// to get Activity checklist
app.get('/getActivityChecklist', function (req, res) {
	db.getActivityChecklist(req.query.type, req.query.equipType).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});


// to get Maintenance info for area page

app.get('/getAreaMaintData', function (req, res) {
	db.getAreaMaintData(req.query.areaId, req.query.equipType).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});


// to get Maintenance info for rig page

app.get('/getRigMaintenanceData', function (req, res) {
	db.getRigMaintenanceData(req.query.rigId, req.query.equipType).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});


// to get summary for drawworks

app.get('/getDrawworksSummaryData', function (req, res) {
	db.getDrawworksSummaryData(req.query.id, req.query.type).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

// to get maintenance history

app.get('/getMaintenanceHistory', function (req, res) {
	db.getMaintenanceHistory(req.query.type, req.query.startDate, req.query.endDate).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

// to get MaintenanceBreakdownSummary

app.get('/getMaintenanceBreakdownSummary', function (req, res) {
	db.getMaintenanceBreakdownSummary(req.query.type).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	})
});


app.get('/gensetParameters', function (req, res) {
	db.getGensetParameters(req.query.noOfEntries).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getRigCoordinates', function (req, res) {
	db.getRigCoordinates(req.query.rigId, req.query.type).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getRigEquipmentsDeploymentList', function (req, res) {
	db.getRigEquipmentsDeploymentList(req.query.areaId).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getAllRigEquipments', function (req, res) {
	db.getAllRigEquipments(req.query.rigId).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/updateActivityStatus', function (req, res) {
	db.updateActivityStatus(req.query.activityId, req.query.userId).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/updateCheckListComment', function (req, res) {
	db.updateCheckListComment(req.query.activityId, req.query.comment).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/updateEquipMaintClosingDate', function (req, res) {
	db.updateEquipMaintClosingDate(req.query.activityId).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/updateEventLog', function (req, res) {

	db.updateEventLog(req.query.activityId, req.query.equipId, req.query.activity).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getEventDetails', function (req, res) {
	db.getEventDetails(req.query.type, req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getIncidentDetails', function (req, res) {
	db.getIncidentDetails(req.query.type, req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/updateIncident', function (req, res) {
	db.updateIncident(req.query.id, req.query.comment, req.query.status).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/downloadFile', function (req, res) {
	db.downloadFile(req.query.id).then(function (data) {
		if (data.length == 0) {
			res.status(400).end('Error');
		} else {
			var path = __dirname + data[0].ARTIFACT_CONTENTS;
			if (fs.existsSync(path)) {
				res.download(path);
			} else {
				res.status(400).end('Not found');
			}
		}
	}).catch(function (err) {
		res.status(404).send(err);
	});
});

app.get('/downloadEquipmentConfig', function (req, res) {
	db.downloadEquipmentConfig(req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getWeeklyMaintenanceDetails', function (req, res) {
	db.getWeeklyMaintenanceDetails(req.query.type, req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getLatestCriticalParams', function (req, res) {
	db.getLatestCriticalParams(req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/updateEventLogForIncidents', function (req, res) {
	db.updateEventLogForIncidents(req.query.id, req.query.desc).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getRigWellInfo', function (req, res) {
	db.getRigWellInfo(req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getRigInfo', function (req, res) {
	db.getRigInfo(req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getFilteredIncidents', function (req, res) {
	db.getFilteredIncidents(JSON.parse(req.query.obj)).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getConfiguratorTables', function (req, res) {
	db.getConfiguratorTables(req.query.type).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/editConfiguratorTables', function (req, res) {
	db.editConfiguratorTables(req.query.type, req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getDropDownOptionsForConfigurator', function (req, res) {
	db.getConfiguratorTables(req.query.type).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getAllRoles', function (req, res) {
	var getAllRoles = db.getAllRoles();
	getAllRoles.then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	});
	getAllRoles.catch(function (err) {
		res.send(err);
	});
});

//To update predictive maintenance of the equipment thereby removing all alert data generation portions from the simulator
app.get('/updatePredictiveMaintenance', function (req, res) {
	var updatePredictiveMaintenance = db.updatePredictiveMaintenance(req.query.rigEquipmentId, req.query.comment, req.query.lastUser);
	updatePredictiveMaintenance.then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	});
	updatePredictiveMaintenance.catch(function (err) {
		res.send(err);
	});
});

//Get Vibration Thresholds for different types of equipments
app.get('/getVibrationThresholds', function (req, res) {
	var getVibrationThresholds = db.getVibrationThresholds(req.query.type);
	getVibrationThresholds.then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	});
	getVibrationThresholds.catch(function (err) {
		res.send(err);
	});
});

//Get the alert state boolean values for the temperature sensors
app.get('/getTempAlertState', function (req, res) {
	var getTempAlertState = db.getTempAlertState(req.query.id, req.query.type);
	getTempAlertState.then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	});
	getTempAlertState.catch(function (err) {
		res.send(err);
	});
});

app.get('/authenticateUser', function (req, res) {
	db.authenticateUser(req.query.username, req.query.password, req.query.role).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).then(function (err) {
		res.send(err);
	});
});

app.get('/getTheJsonData', function (req, res) {
	db.getTheJsonData(req.query.type, req.query.value).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/editTheJsonData', function (req, res) {
	db.editTheJsonData(req.query.type, req.query.value).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/deleteTheJsonData', function (req, res) {
	db.deleteTheJsonData(req.query.type, req.query.value).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getUserMasterData', function (req, res) {
	db.getUserMasterData(req.query.type, req.query.assetId, req.query.areaId, req.query.rigId, req.query.equipType).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getAvailableParameters', function (req, res) {
	db.getAvailableParameters(req.query.type).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/updateEquipmentStatus', function (req, res) {
	db.updateEquipmentStatus(req.query.data).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getEquipmentProvisionData', function (req, res) {
	db.getEquipmentProvisionData(req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getWellAttributes', function (req, res) {

	db.getWellAttributes(req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getRigWellAttributes', function (req, res) {

	db.getRigWellAttributes(req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getEquipmentState', function (req, res) {
	db.getEquipmentState(req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getBirdEyeViewData', function (req, res) {
	db.getBirdEyeViewData(req.query.type, req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});


app.get('/getAllRigsForArea', function (req, res) {
	db.getAllRigsForArea(req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (err) {
		res.send(err);
	});
});

app.get('/getEventLogsAdmin', function (req, res) {
	db.getEventLogsAdmin(req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (ew) {
		res.send(ew);
	});
});

app.get('/getEquipmentSensorStats', function (req, res) {
	db.getEquipmentSensorStats(req.query.id, req.query.description).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (ew) {
		res.status(404).send(ew);
	});
});

app.get('/getEquipmentSensorData', function (req, res) {
	db.getEquipmentSensorData(req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (ew) {
		res.status(404).send(ew);
	});
});

app.get('/getSensorHistoricalData', function (req, res) {
	db.getSensorHistoricalData(req.query.id, req.query.startDate, req.query.endDate).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (ew) {
		res.status(404).send(ew);
	});
});

app.get('/getTemperatureHistoricalData', function (req, res) {
	db.getTemperatureHistoricalData(req.query.id, req.query.startDate, req.query.endDate).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (ew) {
		res.status(404).send(ew);
	});
});

app.get('/getAvailableSensors', function (req, res) {
	db.getAvailableSensors().then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (ew) {
		res.status(404).send(ew);
	});
});

app.get('/getEquipmentManualName', function (req, res) {
	db.getEquipmentManualName(req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (ew) {
		res.status(404).send(ew);
	});
});

app.get('/disassociateRig', function (req, res) {
	db.disassociateRig(req.query.id).then(function (data) {
		res.setHeader('Access-Control-Allow-Origin', '*');
		res.send(data);
	}).catch(function (ew) {
		res.status(404).send(ew);
	});
});

app.get('/getDummyData', function (req, res) {
	res.setHeader('Access-Control-Allow-Origin', '*');
	var obj = {
		"EquipmentId": 1111,
		"EquipmentName": "14-P-220 TRIPLEX MUD PUMP",
		"AssetId": "KKLRIG1MP1",
		"SensorCount": 3,
		"Status": "Active",
		"Data": [{
			"SensorName": "Mud pump Sensor - 1",
			"Measurement": [{
				"MeasurementName": "Temperature",
				"MeasurementValue": 40,
				"MeasurementUnit": "C",
				"Timestamp": "2016-11-28 03:30:45 IST"
			}, {
				"MeasurementName": "Vibration",
				"MeasurementValue": "Normal",
				"MeasurementUnit": null,
				"Timestamp": "2016-11-28 03:30:45 IST"
			}]
		}, {
			"SensorName": "Mud pump Sensor - 2",
			"Measurement": [{
				"MeasurementName": "Temperature",
				"MeasurementValue": 40,
				"MeasurementUnit": "C",
				"Timestamp": "2016-11-28 03:30:45 IST"
			}, {
				"MeasurementName": "Vibration",
				"MeasurementValue": "Normal",
				"MeasurementUnit": null,
				"Timestamp": "2016-11-28 03:30:45 IST"
			}]
		}, {
			"SensorName": "Mud pump Sensor - 3",
			"Measurement": [{
				"MeasurementName": "Temperature",
				"MeasurementValue": 40,
				"MeasurementUnit": "C",
				"Timestamp": "2016-11-28 03:30:45 IST"
			}, {
				"MeasurementName": "Vibration",
				"MeasurementValue": "Normal",
				"MeasurementUnit": null,
				"Timestamp": "2016-11-28 03:30:45 IST"
			}]
		}]
	};
	res.send(obj);
});

app.post('/upload', function (req, res) {

	var form = new formidable.IncomingForm();
	form.multiples = false;
	form.uploadDir = path.join(__dirname, '/manuals');
	var filePath;

	// rename the file after appending timestamp
	form.on('file', function (field, file) {
		var extensionSeparator = file.name.lastIndexOf('.');
		var timestampedFilename = file.name.substring(0, extensionSeparator) + '_' + Date.now().toString() + '.' + file.name.substring(extensionSeparator + 1, file.name.length);
		filePath = path.join('\\manuals\\', timestampedFilename);
		fs.rename(file.path, path.join(form.uploadDir, timestampedFilename));
	});

	form.on('error', function (err) {
	});

	form.on('end', function () {
		if (filePath != undefined) {
			var obj = {
				"path": filePath,
				"equipmentId": parseInt(req.query.id)
			}
			//Store file path in DB
			db.storeFilePath(obj).then(function (data) {
				if (data.includes('Done')) {
					res.send('success');
				} else {
					res.send('error');
				}
			}).catch(function (err) {
				res.send(err);
			});
		} else {
			res.send('error');
		}
	});
	form.parse(req);
});