angular.module('myApp').directive('locationPicker',function($timeout,MainService){
	return {
		restrict: 'E',
		scope: {
			mapid: '=',
			latitude: '=',
			longitude: '='
		},
		templateUrl: 'partials/locationPicker.html',
		link: function(scope,element,attrs){

		},
		controller: function($scope){
			var map;
			var markers = [];
			var oldMarkers = [];
			$scope.latestEvent;
			$scope.mapInitialised = false;

			$scope.applyCoordinates = function(){
				$scope.toShow = false;
			}

			$scope.resetCoordinates = function(){
				$scope.latitude = oldMarkers[0];
				$scope.longitude = oldMarkers[1];
				$scope.toShow = false;
			}
			$scope.init = function(){
				if(!$scope.mapInitialised){
					map = L.map($scope.mapid).setView([51.505, -0.09], 13);
					L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}',
						{
							attribution : 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://mapbox.com">Mapbox</a>',
							maxZoom : 16,
							id : 'ravishankar028.cifs2slpw18p4s6m6gcqsnu4j',
							accessToken : 'pk.eyJ1IjoicmF2aXNoYW5rYXIwMjgiLCJhIjoiY2lmczJzbmJrMTd3bnNobTZvcmN6c2xybCJ9.PiI4Ui8ZqfxzFcdFoGsQhw'
						}).addTo(map);
					
					$scope.mapInitialised = true;
				}
				
				if(map){
					//map.locate({setView: true});
					markers = MainService.cleanExistingMarkers(map,markers);
					map.on('click',function(e){
						var location = e.latlng;
						if(markers.length!=0){
							$.each(markers,function(index,value){
								map.removeLayer(value);
							})
						}
						var marker = new L.marker(location);
						map.addLayer(marker);

						console.log(location);

						console.log(location.lat);
						console.log(location.lng);

						$scope.latitude = location.lat;
						$scope.longitude = location.lng;

						markers.push(marker);
					})

					if ($scope.latitude != null && $scope.latitude != undefined && $scope.longitude != null && $scope.longitude != undefined && !isNaN($scope.latitude) && !isNaN($scope.longitude) && $scope.latitude != '' && $scope.longitude != ''){
						if(map){
							var newMarker = new L.marker();
							var newLatLng = new L.LatLng($scope.latitude, $scope.longitude);
							map.panTo(newLatLng);
							newMarker.setLatLng(newLatLng);
							map.addLayer(newMarker);
							markers.push(newMarker);
						}
					}
				}
			}

			$scope.$watch('toShow',function(newVal,oldVal){
				if(newVal){
					oldMarkers = [];
					oldMarkers.push($scope.latitude);
					oldMarkers.push($scope.longitude);
					$timeout(function(){
						$scope.init();
					},1);
				}
			});

			$scope.$watchGroup(['latitude','longitude'],function(newVals,oldVals){
				if (newVals[0] != null && newVals[0] != undefined && newVals[1] != null && newVals[1] != undefined && !isNaN(newVals[0]) && !isNaN(newVals[1]) && newVals[0] != "" && newVals[1] != ""){
					if(map){
						var newMarker = new L.marker();
						var newLatLng = new L.LatLng(newVals[0], newVals[1]);
						map.panTo(newLatLng);
    					newMarker.setLatLng(newLatLng);
						map.addLayer(newMarker);
						markers.push(newMarker);
					}
				}
			})
		}
	}
})