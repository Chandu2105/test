angular.module('myApp').directive('addParam',function(){
	return {
		restrict: 'E',
		templateUrl: "partials/paramAdder.html",
		scope: {
			paramlist: "=",
			paramedit: "=",
			dropdownlist: "="
		},
		link: function(scope,element,attrs){

		},
		controller: function($scope){

			var temp = {};

			$scope.setInitValues = function(){
				$scope.paramedit.minthresh = 0;
				$scope.paramedit.avg = 0;
				$scope.paramedit.maxthresh = 0;
				$scope.paramedit.mindev = 0;
				$scope.paramedit.avgdev = 0;
				$scope.paramedit.maxdev = 0;
			}
			
			$scope.extraConfigs = false;

			$scope.saveParam = function(){
				temp = {};
				var x = false;
				$.each($scope.paramlist,function(ind,val){
					if(val.name==$scope.paramedit.name){
						$scope.paramlist.splice(ind,1,$scope.paramedit);
						x = true;
						
						$.each($scope.dropdownlist[0],function(index,value){
							if($scope.paramedit.name == value.Value){
								$scope.paramedit["attrId"] = value.attrId;
								return false;
							}
						});
						return false;
					}
				});
				if(!x){
					$.each($scope.dropdownlist[0],function(index,value){
						if($scope.paramedit.name == value.Value){
							$scope.paramedit["attrId"] = value.attrId;
							return false;
						}
					});
					$scope.paramlist.push($scope.paramedit);
				}
				$scope.clearFormAndShow();
				$scope.showModal = false;
				//$scope.$apply();
			}

			$scope.clearFormAndShow = function(){
				$scope.myForm.$setPristine();
				$scope.paramedit = {};
				$scope.$broadcast('clearAllFormFields');
				$scope.showModal = true;
			}

			$scope.options = [];

			// $scope.$watch('dropdownlist',function(newVal,oldVal){
			// 	if(newVal!=undefined && newVal!=null && newVal.length!=0){
			// 		if($scope.dropdownlist[0]!=undefined){
			// 			$scope.options[0] = $scope.dropdownlist[0].map(function(obj){
			// 				return {value: obj['Value'],item: obj['Item']}
			// 			})
			// 		}
					
			// 		if($scope.dropdownlist[1]!=undefined){
			// 			$scope.options[1] = $scope.dropdownlist[1];
			// 		}
			// 	}
			// },true);

			$scope.showModal = false;

			$scope.closeModal = function(){
				$scope.showModal = false;
			}

			$scope.percentPattern = (function(){
				var regexp1 = /^[0]?[0-9]?[0-9](\.\d+)?$/;
				var regexp2 = /^[1][0][0]$/

				return {
					test: function(value){
						return regexp2.test(value) || regexp1.test(value);
					}
				}
			})();

			$scope.extraValidation = function(arr){
				var x = false;
				$.each(arr,function(index,value){
					if(value == undefined || value == null || value == ""){
						x = true;
						return false;
					}
				});
				return x;
			}

			$scope.configure = function(){
				$scope.extraConfigs = !$scope.extraConfigs;

				if(!$scope.extraConfigs){
					$scope.paramedit.minthresh = ($scope.paramedit.minthresh != undefined && $scope.paramedit.minthresh != null && $scope.paramedit.minthresh != "" && !isNaN($scope.paramedit.minthresh))? parseFloat($scope.paramedit.minthresh) : 0;//($.isEmptyObject(temp) ? 0 : temp.minthresh);
					$scope.paramedit.avg = ($scope.paramedit.avg != undefined && $scope.paramedit.avg != null && $scope.paramedit.avg != "" && !isNaN($scope.paramedit.avg)) ? parseFloat($scope.paramedit.avg) : 0;//($.isEmptyObject(temp) ? 0 : temp.avg);
					$scope.paramedit.maxthresh = ($scope.paramedit.maxthresh != undefined && $scope.paramedit.maxthresh != null && $scope.paramedit.maxthresh != "" && !isNaN($scope.paramedit.maxthresh)) ? parseFloat($scope.paramedit.maxthresh) : 0;//($.isEmptyObject(temp) ? 0 : temp.maxthresh);
					$scope.paramedit.mindev = ($scope.paramedit.mindev != undefined && $scope.paramedit.mindev != null && $scope.paramedit.mindev != "" && !isNaN($scope.paramedit.mindev)) ? parseFloat($scope.paramedit.mindev) : 0;//($.isEmptyObject(temp) ? 0 : temp.mindev);
					$scope.paramedit.avgdev = ($scope.paramedit.avgdev != undefined && $scope.paramedit.avgdev != null && $scope.paramedit.avgdev != "" && !isNaN($scope.paramedit.avgdev)) ? parseFloat($scope.paramedit.avgdev) : 0;//($.isEmptyObject(temp) ? 0 : temp.avgdev);
					$scope.paramedit.maxdev = ($scope.paramedit.maxdev != undefined && $scope.paramedit.maxdev != null && $scope.paramedit.maxdev != "" && !isNaN($scope.paramedit.maxdev)) ? parseFloat($scope.paramedit.maxdev) : 0;//($.isEmptyObject(temp) ? 0 : temp.maxdev);
				}
			}

			$scope.$watch('dropdownlist',function(newVal,oldVal){
				if(newVal!=undefined && newVal!=null && newVal.length!=0){
					if($scope.dropdownlist[0]!=undefined){
						$scope.options[0] = $scope.dropdownlist[0].map(function(obj){
							return {value: obj['Value'],item: obj['Item']}
						})
					}
					
					if($scope.dropdownlist[1]!=undefined){
						$scope.options[1] = $scope.dropdownlist[1].map(function(obj){
							return {value: obj['UOM_ID'],item: obj['UOM_NAME']}
						})
					}
				}
			},true);

			$scope.$watch('paramedit.name',function(newVal,oldVal){
				if(newVal != undefined && newVal != null){
					var currVal = [];
					if($scope.dropdownlist[0] != undefined && $scope.dropdownlist[0] != null && $scope.dropdownlist[0].constructor === Array && $scope.dropdownlist[0].length > 0){
						currVal = $scope.dropdownlist[0].filter(function(m){
							return m.Value == newVal;
						});
					}

					if($scope.dropdownlist[1] != undefined && $scope.dropdownlist[1] != null && $scope.dropdownlist[1].constructor === Array && $scope.dropdownlist[1].length > 0){
						var tempArr = $scope.dropdownlist[1].filter(function(g){
							return (currVal[0].UOM_TYPE!=undefined)?g.UOM_TYPE == currVal[0].UOM_TYPE : false;
						}).map(function(obj){
							return {value: obj['UOM_ID'],item: obj['UOM_NAME']};
						});

						if(tempArr.constructor === Array && tempArr.length > 0){
							$scope.options[1] = tempArr;
						}
					}
				}else{
					if($scope.dropdownlist[1]!=undefined){
						$scope.options[1] = $scope.dropdownlist[1].map(function(obj){
							return {value: obj['UOM_ID'],item: obj['UOM_NAME']}
						})
					}
				}
			})

			$scope.$on('forceEdit',function(event,mess){
				temp = angular.copy(mess);
				$scope.showModal = true;
				$scope.paramedit = temp;

				$scope.extraConfigs = true;
			});

			$scope.$watch('paramedit',function(newVal,oldVal){
				if(newVal!=undefined && newVal!=null && newVal!="" && Object.keys(newVal).length != 0){
					$scope.showModal = true;
				}
			},true);

			$scope.$watch('showModal',function(newVal,oldVal){
				if(newVal && $.isEmptyObject(temp)){
					$scope.setInitValues();
				}
			});
		}
	}
})