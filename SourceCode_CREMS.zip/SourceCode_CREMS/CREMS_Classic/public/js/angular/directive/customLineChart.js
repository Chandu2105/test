angular.module('myApp').directive('customLineChart',function($rootScope){
	return {
		restrict: 'E',
		link: function(scope,element,attrs){
			var chart;
			function _init(){
				nv.addGraph(function() {				
					  chart = nv.models.lineChart()
					                .margin(scope.chartMargin)  //Adjust chart margins to give the x-axis some breathing room.
					                .x(function(d){return d[0]})
					                .y(function(d){return d[1]})
					                .useInteractiveGuideline(true)  //We want nice looking tooltips and a guideline!
					               // .transitionDuration(350)  //how fast do you want the lines to transition?
					                .showLegend(true)       //Show the legend, allowing users to turn on/off line series.
					                .showYAxis(true)        //Show the y-axis
					                .showXAxis(true)        //Show the x-axis
					               //.tooltips(false);
					
					//chart.interactiveLayer.tooltip.fixedTop(300);
					
					  if(scope.forceY){
						  chart.forceY(scope.forceY);
					  }
					  chart.xAxis     //Chart x-axis settings
					      .axisLabel(scope.xAxisLabel);
					  
					  if($.isArray(scope.tickValues)){
						  chart.xAxis.tickValues(scope.tickValues)
						  			 .tickFormat(function(d){
						  				return scope.storeValues[d];
						  			 });
					  }else if(typeof scope.xAxisTickFormatFunction == 'function'){
						chart.xAxis.tickFormat(scope.xAxisTickFormatFunction());	
					  }
					  
					  chart.xAxis.axisLabelDistance(scope.xAxisLabelDistance);
					  chart.yAxis     //Chart y-axis settings
					      .axisLabel(scope.yAxisLabel)
					      .tickFormat(d3.format('.02f')).axisLabelDistance(scope.yAxisLabelDistance);

					  /* Done setting the chart up? Time to render it!*/
					  var myData = scope.chartData;//sinAndCos();   //You need data...			  
					  
					  
					  
					
					  d3.select('#'+attrs.id+' svg')    //Select the <svg> element you want to render the chart in.   
					 .attr('width',function(){
						 if(attrs.width){
							 return attrs.width;
						 }
						 else
							 return '100%';
					 })
					 .attr('height',function(){
						 if(attrs.height){
					
							 return attrs.height;
						 }
						 else{
					
							 return '100%';
						 }
					 })	   
					  .datum(myData)         //Populate the <svg> element with chart data...
					  .call(chart);         //Finally, render the chart!
					chartUpdate();
					
					  //Update the chart when window resizes.
					  nv.utils.windowResize(function() {
						  chart.update();
						  //chartUpdate();
						  });
					  return chart;
					});				
			}
			_init();
			function chartUpdate(){
				$('#'+attrs.id+' svg .nvd3.nv-wrap.nv-axis .tick text').each(function(index){
					$(this).text("");
					});
			}
			
			$rootScope.$on('updateLineChart',function(event,mess){
					if(mess==attrs.id){
						//d3.select("#"+attrs.id+' svg').selectAll("*").remove();
						/*if(chart==undefined)
							_init();
						else{
							d3.select("#"+attrs.id+' svg').remove();
							if(d3.select('#' + attrs.id + ' svg').empty()) {
			                d3.select('#' + attrs.id)
			                    .append('svg');
			           		 }
							chart.forceY(scope.forceY);
							d3.select('#'+attrs.id+' svg')    //Select the <svg> element you want to render the chart in.
							  .attr('width',attrs.width)
							 .attr('height',attrs.height)
							 .datum(scope.chartData)        //Populate the <svg> element with chart data...
							  .call(chart);       //Finally, render the chart!
							  
							}*/
							_init();
					}
			});
			
			
			// $rootScope.$on('dataUpdatedChartSales',function(event,mess){	
				// //console.log("update chart sales");
				// jQuery.each(mess,function(i,value){
					// if(mess[i]==attrs.id){
						// chart.xAxis     //Chart x-axis settings
					      // .axisLabel(scope.xAxisLabel);
						// chart.forceY([0,scope.forceY]);
						// d3.select('#'+mess[i]+' svg')
					    // .remove();
						// if(d3.select('#' + mess[i] + ' svg').empty()) {
			                // d3.select('#' + attrs.id)
			                    // .append('svg');
			            // }						
						// d3.select('#'+mess[i]+' svg')    //Select the <svg> element you want to render the chart in.
						// .attr('width',attrs.width)
						// .attr('height',attrs.height)
					      // .datum(scope.chartData)        //Populate the <svg> element with chart data...
					      // .call(chart);       //Finally, render the chart!
					// }					
				// });
			// });
			
		}
	}
})