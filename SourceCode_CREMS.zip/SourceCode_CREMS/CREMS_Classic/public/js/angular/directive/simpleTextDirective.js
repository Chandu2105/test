angular.module('myApp').directive('simpleText',function($rootScope){
	return {
		restrict: 'E',
		transclude: true,
		templateUrl: 'partials/simpleTextDirective.html',
		link: function(scope,element,attrs){
			
			function _init(){
				
				var modArr = ["positiveModal","negativeModal"];
				var norArr = [];
				//scope.myClass = scope.$parent.textParams.highlightClassName
				scope.hero = attrs.classdwell;
				if(attrs.classdwell==undefined){
					$.each(scope.$parent.textParams,function(index,value){
						norArr[index] = value.highlightClassName;
					});
					//scope.$parent.textParams.highlightClassName = attrs.classdwell;
				}
				scope.getClass = function(index,hero){
					if(hero!=undefined)
						return modArr[index];
					else
						return norArr[index];
				}
				
				var w=attrs.width.slice(0,attrs.width.length-1)*$('#'+attrs.id).closest('.newWidgetBody').width()/100;
			
				var valueToInsert=scope.textToInsert;
				var font=attrs.fontsize;
				var transy=attrs.translatey;
				if(valueToInsert==undefined||valueToInsert==null||valueToInsert==""){
					valueToInsert="No Data Recorded";
					font=8;
					transy=25;
				}				
				var svg = d3.select('svg#'+attrs.id).attr('width',w).attr('height',attrs.height);
				svg.append('g').append('title').text(valueToInsert);
				svg.append('text').attr('text-anchor','middle')
						.attr('style',"font-size:"+font+"px")
						.attr('class',attrs.classname)
						/*.attr('class',attrs.classdwell)*/
						.attr('transform','translate('+attrs.translatex+','+transy+')')
						.text(valueToInsert);
				
				if(valueToInsert=="No Data Recorded"){
					$('svg#'+attrs.id+' text').attr("style","font-size:8px;font-family:'Segoe UI Semibold','Trebuchet MS','Times New Roman',Arial,Helvetica,sans-serif !important");
				}				
						
			}
			
			
			$rootScope.$on('updateChart',function(event,mess){
					var svg = d3.selectAll('svg#'+attrs.id);
					svg.selectAll('*').remove();
					_init(scope.textToInsert);
			})
			
			// $rootScope.$on('dataUpdatedChartAvgDwell',function(event,mess){				
				// jQuery.each(mess,function(i,val){
					// if(mess[i]==attrs.id){
						// //console.log(scope.textToInsert)
						// d3.select('svg#'+attrs.id+' text').text(scope.textToInsert);
					// }
					// });					
			// })
			_init(scope.textToInsert);
		}
	}
})