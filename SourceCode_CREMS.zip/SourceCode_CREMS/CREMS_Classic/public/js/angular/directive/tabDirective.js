angular.module('myApp').directive('tabDirective',function(){
	return {
		restrict: 'E',
		scope: {
			data: "=",
			currtab: '='
		},
		templateUrl: 'partials/tabDirective.html',
		link: function(scope,elems,attrs){

		},
		controller: function($scope){
			$scope.alterTabs = function(index){
				$scope.currtab = index;
			}
		}
	}
})