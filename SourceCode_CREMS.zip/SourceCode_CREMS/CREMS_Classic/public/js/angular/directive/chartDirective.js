angular.module('myApp').directive('chartDirective',function(){
    return{
        restrict: 'E',
        scope: {
            data: '=',
            chartconfig: '='
        },
        template: "<div id='{{chartconfig.chartId}}'><svg></svg></div>",
        link: function(scope,elems,attrs){
            var chart;
            scope.init = function(){
                var width = scope.chartconfig.width || parseInt(attrs.width);
                var height = scope.chartconfig.height || parseInt(attrs.height);

                if(scope.chartconfig.chartType == 'line'){
                    nv.addGraph(function() {
                        chart = nv.models.lineChart()
                                        .margin(scope.chartconfig.margin)  //Adjust chart margins to give the x-axis some breathing room.
                                        .useInteractiveGuideline(scope.chartconfig.useInteractiveGuideline || false)  //We want nice looking tooltips and a guideline!
                                        //.transition().duration(350)  //how fast do you want the lines to transition?
                                        //.x(function(d){if(d && d[0]) return moment(d[0],'YYYY-MM-DDTHH:mm:ss.SSSZ').valueOf()})
                                        //.y(function(d){return d[1]})
                                        .showLegend(true)       //Show the legend, allowing users to turn on/off line series.
                                        .showYAxis(true)        //Show the y-axis
                                        .showXAxis(true)        //Show the x-axis
                                        //.tooltips(true)
										.noData("No Data Recorded.")
                        ;
						
						if(typeof scope.chartconfig.xDataFunction == 'function'){
                            chart.x(scope.chartconfig.xDataFunction());
                        }else{
							chart.x(function(d){return d[0];});
						}
						
						if(typeof scope.chartconfig.yDataFunction == 'function'){
                            chart.y(scope.chartconfig.yDataFunction());
                        }else{
							chart.y(function(d){return d[1];});
						}
						
                        chart.xAxis     //Chart x-axis settings
                            .axisLabel(scope.chartconfig.xAxisLabel?scope.chartconfig.xAxisLabel : 'X Axis')
                            .tickFormat(function(d){return d3.time.format('%d %b %H:%M')(new Date(d))});//new Date(moment(d,'YYYY-MM-DDTHH:mm:ss.SSSZ').valueOf())

                        chart.yAxis     //Chart y-axis settings
                            .axisLabel(scope.chartconfig.yAxisLabel?scope.chartconfig.yAxisLabel : 'Y Axis');

                        if(scope.chartconfig.yAxisLabelDistance)
                            chart.yAxis.axisLabelDistance(scope.chartconfig.yAxisLabelDistance);
                        
                        chart.yAxis.tickFormat(d3.format('.02f'));
                        
                        if(typeof scope.chartconfig.xAxisTickFormatFunction == 'function'){
                            chart.xAxis.tickFormat(scope.chartconfig.xAxisTickFormatFunction());	
                        }
                        
                        /* Done setting the chart up? Time to render it!*/
                        var myData = scope.data;   //You need data...
                        //var myData = sinAndCos();

                        d3.select('#'+scope.chartconfig.chartId+' svg')    //Select the <svg> element you want to render the chart in.   
                            .attr('width',function(){
                                if(scope.chartconfig.width){
                                    return scope.chartconfig.width+"px";
                                }
                                else
                                    return '100%';
                            })
                            .attr('height',function(){
                                if(scope.chartconfig.height){
                                    return scope.chartconfig.height+"px";
                                }
                                else{
                                    return '100%';
                                }
                            })
                            .datum(myData)         //Populate the <svg> element with chart data...
                            .call(chart);          //Finally, render the chart!

                        //Update the chart when window resizes.
                        nv.utils.windowResize(function() { chart.update() });
                        return chart;
                    });
                }else if(scope.chartconfig.chartType == 'bar'){
                    nv.addGraph(function() {
                        chart = nv.models.multiBarChart()
                            .barColor(d3.scale.category20().range())
                            .duration(300)
                            .margin(scope.chartconfig.margin)
                            //.margin({bottom: 100, left: 70})
                            .rotateLabels(45)
                            .groupSpacing(0.1)
                        ;
                        
                        chart.reduceXTicks(false).staggerLabels(true);

                        chart.xAxis
                            .axisLabel(scope.chartconfig.xAxisLabel?scope.chartconfig.xAxisLabel : 'X Axis')
                            .axisLabelDistance(35)
                            .showMaxMin(false)
                            //.tickFormat(d3.format(',.6f'))
                        ;

                        if(typeof scope.chartconfig.xAxisTickFormatFunction == 'function'){
                            chart.xAxis.tickFormat(scope.chartconfig.xAxisTickFormatFunction());	
                        }

                        chart.yAxis
                            .axisLabel(scope.chartconfig.yAxisLabel?scope.chartconfig.yAxisLabel : 'Y Axis')
                            .axisLabelDistance(-5)
                            .tickFormat(d3.format(',.01f'))
                        ;

                        /* Done setting the chart up? Time to render it!*/
                        var myData = scope.data;   //You need data...
                        //var myData = sinAndCos();

                        d3.select('#'+scope.chartconfig.chartId+' svg')    //Select the <svg> element you want to render the chart in.   
                            .attr('width',function(){
                                if(scope.chartconfig.width){
                                    return scope.chartconfig.width+"px";
                                }
                                else
                                    return '100%';
                            })
                            .attr('height',function(){
                                if(scope.chartconfig.height){
                                    return scope.chartconfig.height+"px";
                                }
                                else{
                                    return '100%';
                                }
                            })
                            .datum(myData)         //Populate the <svg> element with chart data...
                            .call(chart);          //Finally, render the chart!

                        nv.utils.windowResize(chart.update);
                        return chart;
                    });
                }
            }
            //scope.init();

            scope.$watch('data',function(newVal,oldVal){
                if(chart != undefined){
                    
                    d3.select('#'+scope.chartconfig.chartId+' svg')
                    .datum(newVal)
                    .call(chart);
                }
            },true);

            scope.$watch('chartconfig',function(newVal,oldVal){
                scope.init();
            },true);

            function sinAndCos() {
                var sin = [],
                    cos = [];

                for (var i = 0; i < 3000; i++) {
                    sin.push({x: i, y: Math.sin(i/10)});
                    cos.push({x: i, y: .5 * Math.cos(i/10)});
                }

                return [
                    {
                    values: sin,
                    key: 'Sine Wave',
                    color: '#ff7f0e'
                    },
                    {
                    values: cos,
                    key: 'Cosine Wave',
                    color: '#2ca02c'
                    }
                ];
            }
        }
    } 
})