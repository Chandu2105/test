angular.module('myApp').directive('customTooltip',function(){
	return {
		restrict: 'E',
	}
});