angular.module('myApp').directive('focusDelete',function(){
	return {
		restrict:'A',
		link:function(scope,elements,attr){
			$(elements).click(function(){
				$(this).val('');
			});
		}
	}
})