angular.module('myApp').directive('autoCapitalize',function($filter){
	return {
		restrict: 'A',
		require: 'ngModel',
		link: function(scope,elems,attrs,ngModel){
			elems.bind('keyup',function(event){
				if(elems.val()!=undefined&&elems.val()!=null&&elems.val()!=''){
					elems.val($filter('uppercase')(elems.val()));
					ngModel.$setViewValue(elems.val());
				}
			})
		}
	}
})