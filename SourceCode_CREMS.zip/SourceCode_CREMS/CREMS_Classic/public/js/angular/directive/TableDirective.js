angular.module('myApp').directive('tableDirective',function(){
	return{
		restrict:'E',
		templateUrl:'partials/tableDirective.html',
		link: function(scope,element,attrs){

		}
	}
})