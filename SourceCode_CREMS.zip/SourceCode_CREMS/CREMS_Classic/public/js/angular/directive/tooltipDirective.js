angular.module('myApp').directive('dynamicTooltip',function(){
    return {
        restrict: 'A',
        templateUrl: 'partials/tooltipTemplate.html',
        scope: {
            data: '=?'
        },
        transclude: true,
        link: function(scope,elems,attrs){
            
            if(scope.data.constructor === Array){
                scope.array = true;
            }else{
                scope.array = false;
            }

            elems.bind('mouseenter',function(event){
                var x = event.clientX;
                var y = event.clientY;

                var windowX = window.innerWidth;
                var windowY = window.innerHeight;

                if(checkBounds(event)){
                    scope.$apply(function(){
                        scope.top = y;
                        scope.showable = true;
                        var widthNow = elems.find('div.customTooltip').eq(0).outerWidth();
                        //var right = widthNow == undefined ? (windowX - x - 60): (windowX - x + widthNow - 60);
                        var right = windowX - x + 14;
                        elems.find('div.customTooltip').eq(0).addClass('right').css({right: right});
                    })
                }else{
                    scope.$apply(function(){
                        scope.top = y;
                        scope.showable = true;
                        elems.find('div.customTooltip').eq(0).addClass('left').css({left: x + 20});
                    })
                }
            });

            elems.bind('mousemove',function(event){
                var x = event.clientX;
                var y = event.clientY;

                var windowX = window.innerWidth;
                var windowY = window.innerHeight;

                if(checkBounds(event)){
                    scope.$apply(function(){
                        scope.top = y;
                        scope.showable = true;
                        var widthNow = elems.find('div.customTooltip').eq(0).outerWidth();
                        //var right = widthNow == undefined ? (windowX - x - 60): (windowX - x + widthNow - 60); 
                        var right = windowX - x + 14;
                        elems.find('div.customTooltip').eq(0).addClass('right').css({right: right});
                    })
                }else{
                    scope.$apply(function(){
                        scope.top = y;
                        scope.showable = true;
                        elems.find('div.customTooltip').eq(0).addClass('left').css({left: x + 20});
                    })
                }
            });

            elems.bind('mouseleave',function(event){
                
                scope.$apply(function(){
                    scope.showable = false;
                })
            });
        },
        controller: function($scope){
            $scope.showable = false;
        }
    }
})

function checkBounds(event){
    var x = event.clientX;
    var y = event.clientY;

    var windowX = window.innerWidth;
    var windowY = window.innerHeight;

    if(x >= windowX/2){
        return 1;
    }else{
        return 0;
    }
}