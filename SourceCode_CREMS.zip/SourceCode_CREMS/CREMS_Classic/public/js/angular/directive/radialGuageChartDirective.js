angular.module('myApp').directive('customRadialGauge',function($rootScope){
	return {
		restrict: 'E',
		scope: {
			data: "=",
			config: "="
		},
		link: function($scope,element,attrs){
		},
		controller: function($scope){
			var data = [];
			var middle;
			function _init(data1){
				var w;
				var h;
				if($scope.config.width!=undefined&&$scope.config.width.indexOf('%')!=-1){
					w=($scope.config.width.slice(0,$scope.config.width.length-1))*$('#'+$scope.config.id).closest('.newWidgetBody').width()/100;					
				}
				else{
					w=$scope.config.width;
				}
				if($scope.config.height!=undefined&&$scope.config.height.indexOf('%')!=-1){
					h=($scope.config.height.slice(0,$scope.config.height.length-1))*$('#'+$scope.config.id).closest('.newWidgetBody').height()/100;
				}
				else{
					h=$scope.config.height;
				}
				

				  var  r = (w*55)/230,                           
				    ir = (w*40)/230,
				    pi = Math.PI;
				    var color;
				    
				  
				    if(data1>=$scope.config.min & data1<=$scope.config.max){
				    	
				    	color = ['rgb(1, 184, 170)','rgb(233, 233, 233)']; 
				    }
				    else{
				    	
				    	color=['rgb(253, 129, 126)','rgb(233, 233, 233)'];
				    }
				    	
					
					
					// to check data is available or not
					if(data1==undefined||data1==null||data1.length==0){
						//attr('transform','translate('+(r/3)+',0)').append('text').text(data1).attr("style","font-size:"+$scope.middlefont+"px;font-family:'Segoe UI Light' !important");
						vis=d3.select('svg#'+$scope.config.id).attr("width", function(){
								return w;
							})  
							            .attr("height", function(){
								return h;
							}).append("svg:g").attr('transform','translate('+(r/3)+',20)').append("text").text("No Data Recorded").attr("style","font-size:8px;font-family:'Segoe UI Semibold','Trebuchet MS','Times New Roman',Arial,Helvetica,sans-serif !important");
					var middleFont =$($('#'+$scope.config.id+' g>text')[0]).width();
					var pos=middleFont*2;
			$($('#'+$scope.config.id+' g>text')[0]).remove();
			d3.select('svg#'+$scope.config.id).append('svg:g').attr('transform','translate('+pos+',25)').append('text').text("No Data Recorded").attr("style","font-size:8px;font-family:'Segoe UI Semibold','Trebuchet MS','Times New Roman',Arial,Helvetica,sans-serif !important");
					}
					else{
						var middleValueinInt=Math.ceil(data1);
					var middleValueinString=middleValueinInt.toString()
					var length=middleValueinString.length;
					var maxValue=Math.pow(10,length-1);
					var rightData=maxValue;
					while(rightData<middleValueinInt){
						rightData=rightData+maxValue;
					}
						
				 
				  data = [{"label":"New", "value":data1}, 
				            {"label":"Repeat", "value":rightData-data1}];	
				            	  var vis = d3.select('svg#'+$scope.config.id)
							        .data([data])          
							            .attr("width", function(){
								return w;
							})  
							            .attr("height", function(){
								return h;
							}).append("svg:g")       
							            .attr("transform", "translate(" + (w/2) + "," + (h*85/100) + ")")
						
						
				    var arc = d3.svg.arc()              
				        .outerRadius(r)
						.innerRadius(ir);
				 
				    var signed = (rightData/2-data1)/(Math.abs(rightData/2-data1));
					
					
					
				    var pie = d3.layout.pie()           
				        .value(function(d) { return d.value; })
				        .startAngle(90 * signed * (pi/180))
				        .endAngle(-90 * signed * (pi/180));
				 
				    var arcs = vis.selectAll("g.slice")     
				        .data(pie)                          
				        .enter()                            
				            .append("svg:g")                
				                .attr("class", "slice");    
				 
				        arcs.append("svg:path")
				                .attr("fill", function(d, i) { return color[i]; } ) 
				                .attr("d", arc);  
									
								data1=data1.toFixed(2);
				vis.append('svg:g').attr('transform','translate('+(r/3)+',0)').append('text').text(data1).attr("style","font-size:"+$scope.config.middlefont+"px;font-family:'Segoe UI Light' !important");
				vis.append('svg:g').attr('transform','translate('+(-r-$scope.config.sidefont*2.5)+',0)').append('text').text('0.00').attr("style","font-size:"+$scope.config.sidefont+"px"+";font-family:'Segoe UI Light','Trebuchet MS','Times New Roman',Arial,Helvetica,sans-serif !important");	    
				vis.append('svg:g').attr('transform','translate('+(r+$scope.config.sidefont*1.1)+',0)').append('text').text(rightData).attr("style","font-size:"+$scope.config.sidefont+"px;font-family:'Segoe UI Light','Trebuchet MS','Times New Roman',Arial,Helvetica,sans-serif !important");	    
			var middleFont =$($('#'+$scope.config.id+' g>text')[0]).width();
			var leftFont =$($('#'+$scope.config.id+' g>text')[1]).width();
			var rightFont =$($('#'+$scope.config.id+' g>text')[2]).width();
			var pos=-middleFont/2;
			var leftPos=-r-leftFont-2;
			var rightPos=r+2;
			$($('#'+$scope.config.id+' g>text')[0]).remove();
			$($('#'+$scope.config.id+' g>text')[0]).remove();
			$($('#'+$scope.config.id+' g>text')[0]).remove();
			vis.append('svg:g').attr('transform','translate('+pos+',0)').append('text').text(data1).attr("style","font-size:"+$scope.config.middlefont+"px;font-family:'Segoe UI Light','Trebuchet MS','Times New Roman',Arial,Helvetica,sans-serif !important");
			vis.append('svg:g').attr('transform','translate('+leftPos+',0)').append('text').text('0.00').attr("style","font-size:"+$scope.config.sidefont+"px"+";font-family:'Segoe UI Light','Trebuchet MS','Times New Roman',Arial,Helvetica,sans-serif !important");	    
			vis.append('svg:g').attr('transform','translate('+rightPos+',0)').append('text').text(rightData.toFixed(2)).attr("style","font-size:"+$scope.config.sidefont+"px;font-family:'Segoe UI Light','Trebuchet MS','Times New Roman',Arial,Helvetica,sans-serif !important");	    
			
					}
					
					
					}		
			
			_init($scope.data);
			
			$(window).resize(function(){
				d3.select('svg#'+$scope.config.id).selectAll("*").remove();
				_init($scope.data);
			});
			
			/*$rootScope.$on('updateChartRadial',function(event,mess){
			d3.select('svg#'+$scope.id).selectAll("*").remove();
			this.min=mess[0];
			this.max=mess[1];
			_init($scope.middleData);

			});*/
			$rootScope.$on('updateChart',function(){
			d3.select('svg#'+$scope.config.id).selectAll("*").remove();
			_init($scope.data);
			});
			$scope.$watch("data",function(newVal,oldval){
				d3.select('svg#'+$scope.config.id).selectAll("*").remove();
				_init(newVal);
			});
		}
	}
})