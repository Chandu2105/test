angular.module('myApp').directive('pagination',function(){
	return{
		restrict: 'E',
		templateUrl: 'partials/pagination.html',
		scope: {
			data: '=',
			simplifiedData: '=pagedata'
		},
		link: function(scope,element,attrs){

		},
		controller: function($scope){

			if(!$scope.pageSize){
				$scope.pageSize = 10;
			}
			$scope.btns = [];
			$scope.simplifiedData = [];
			$scope.disableStart = true;
			$scope.numberOfTabs = 5;
			$scope.currentPage = 1;
			$scope.pages = 1;
			$scope.disableEnd = true;
			$scope.selectedPage = 1;
			$scope.check = 1;

			$scope.init = function(){
				$scope.pages = Math.ceil($scope.data.length/$scope.pageSize)<=0?1:Math.ceil($scope.data.length/$scope.pageSize);
				$scope.disableEnd = $scope.currentPage>=$scope.pages;
				$scope.disableStart = $scope.pages==1;
				/*$scope.btns = [];
				if($scope.pages<=$scope.numberOfTabs){
					for(var i=1;i<=$scope.pages;i++){
						$scope.btns.push(i);
					}
				}else{
					for(var i=1;i<=$scope.numberOfTabs;i++){
						$scope.btns.push(i);
					}
				}*/
			}
			
			$scope.$watch('pageSize',function(newVal,oldVal){
				if(/^\d+$/.test(newVal)){
					if(newVal > $scope.data.length){
						$scope.pageSize = oldVal;
					}
					$scope.init();
					$scope.updatePage($scope.currentPage);
				}
			})

			$scope.$watch('data',function(newVal,oldVal){
				
				//if(newVal!=undefined && newVal.length!=0){
					$scope.init();
					$scope.updatePage($scope.currentPage);
				/*}else{
					$scope.currentPage = 1;
					$scope.pages = 1;
					$scope.simplifiedData = [];
				}*/
			});

			$scope.updatePage = function(val){
				val = Math.ceil(val);
				if(/^\d+$/.test(val)){
					if(val>$scope.pages){
						$scope.updatePage($scope.pages);
					}else if(val<=0){
						$scope.updatePage(1);
					}else{
						$scope.currentPage = Math.ceil(val);
						Math.ceil(val)==1?$scope.disableStart = true:$scope.disableStart = false;
						$scope.currentPage==Math.ceil($scope.data.length/$scope.pageSize)?$scope.disableEnd = true:$scope.disableEnd = false;
						console.log($scope.data);
						$scope.simplifiedData = $scope.data.slice(($scope.currentPage-1)*$scope.pageSize,($scope.currentPage-1)*$scope.pageSize+$scope.pageSize);
						
						//var newval=Math.ceil(val);
						
						/*if($.inArray(newval,$scope.btns)==-1){
							$scope.btns=[];
							var lower = newval;
							var higher=lower+length;
							for(var i=lower;i<higher;i++){
								if(i<=Math.ceil($scope.data.length/$scope.pageSize))
									$scope.btns.push(i);
							}
						}*/
						//var higher=lower+length;
						//var lower=(newval==1)?1:(Math.floor(newval/length)*length)+1-(newval%$scope.pageSize==0?$scope.pageSize:0);
						//console.log(lower);
						
						//This is for the buttons
						/*$scope.btns = [];
						if($scope.pages<=$scope.numberOfTabs){
							for(var i=1;i<=$scope.pages;i++){
								$scope.btns.push(i);
							}
						}else{
							var lower = 0;
							var higher = 0;
							if($scope.currentPage-Math.floor($scope.numberOfTabs/2)<0){
								lower = 1;
								higher = $scope.numberOfTabs>$scope.pages?$scope.pages:$scope.numberOfTabs; //put the number of buttons needed variable here
							}
							else if($scope.currentPage+Math.floor($scope.numberOfTabs/2)>$scope.pages){
								higher = $scope.pages;
								lower = $scope.pages-($scope.numberOfTabs-1);//put the number of buttons needed variable here -1
							}
							else{
								lower = $scope.currentPage-Math.floor($scope.numberOfTabs/2);
								higher = $scope.currentPage+Math.floor($scope.numberOfTabs/2);
							}
							for(var i=lower;i<=higher;i++){
								$scope.btns.push(i);
							}
						}*/
					}
					$scope.selectedPage = Math.ceil(val);
				}
			}
		}
	}
})