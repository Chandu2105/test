angular.module('myApp').directive('addSensor',function(){
	return {
		restrict: 'E',
		templateUrl: "partials/sensorAdder.html",
		scope: {
			sensorlist: "=",
			sensoredit: "=",
			sensordropdownlist: "="
		},
		link: function(scope,element,attrs){

		},
		controller: function($scope){
			
			$scope.presentJob = 'add';

			$scope.saveSensor = function(){
				// var d = false;
				// $.each($scope.sensorlist,function(i,v){
				// 	if(v.sensorId == $scope.sensoredit.sensorId){
				// 		d = true;
				// 		return false;
				// 	}
				// });

				$scope.sensordropdownlist = $scope.sensordropdownlist.filter(function(v){
					return v.value != $scope.sensoredit.sensorId;
				});

				if($scope.presentJob == 'edit'){
					//if(!d || (d && $scope.sensoredit.sensorLocation != temp.sensorLocation)){
						var t = -1;
						$.each($scope.sensorlist,function(i,v){
							if(temp.sensorId != undefined){
								if(v.sensorId == temp.sensorId){
									t = i;
									return false;
								}
							}
						})

						if(t!=-1){
							$scope.sensorlist.splice(t,1,$scope.sensoredit);
						}
						$scope.clearFormAndShow();
						$scope.showModal = false;
					// }else{
					// 	$scope.$emit('popup','The sensor you are trying to add already exists in the list. Please edit that sensor or add another sensor.',"info");
					// }
				}else{
					//if(!d){
						$scope.sensorlist.push($scope.sensoredit);
						$scope.clearFormAndShow();
						$scope.showModal = false;
					// }else{
					// 	$scope.$emit('popup','The sensor you are trying to add already exists in the list. Please edit that sensor or add another sensor.',"info");
					// }					
				}
			}

			$scope.clearFormAndShow = function(){
				$scope.myForm.$setPristine();
				$scope.sensoredit = {};
				$scope.presentJob = 'add';
				$scope.$broadcast('clearAllFormFields');
				$scope.showModal = true;
			}

			$scope.extraValidation = function(arr){
				var x = false;
				$.each(arr,function(index,value){
					if(value == undefined || value == null || value == ""){
						x = true;
						return false;
					}
				});
				return x;
			}

			$scope.closeModal = function(){
				if(temp!=null && temp != undefined && !$.isEmptyObject(temp) && temp.sensorId != undefined){
					$scope.sensordropdownlist = $scope.sensordropdownlist.filter(function(v){
						return v.value != temp.sensorId;
					});
				}
				temp = {};
				$scope.showModal = false;
			}

			$scope.showModal = false;

			var temp = {};

			$scope.$on('forceEdit',function(event,valToEdit,index,masterArray){
				$scope.showModal = true;
				$scope.sensoredit = angular.copy(valToEdit);

				var editedSensor = masterArray.filter(function(v){
					return v.value == $scope.sensoredit.sensorId;
				});

				var boolEdit = false;

				$.each($scope.sensordropdownlist,function(i,v){
					if(v.value == editedSensor.value){
						boolEdit = true;
						return false;
					}
				})

				if(!boolEdit){
					$.merge($scope.sensordropdownlist,editedSensor);
				}

				$scope.presentJob = 'edit';
				temp = valToEdit;
			});

			// $scope.$watch('sensoredit',function(newVal,oldVal){
			// 	if(newVal!=undefined && newVal!=null && newVal!="" && Object.keys(newVal).length!=0)
			// 		$scope.showModal = true;
			// },true);
		}
	}
})