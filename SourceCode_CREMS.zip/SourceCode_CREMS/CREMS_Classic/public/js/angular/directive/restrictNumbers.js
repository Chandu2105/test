angular.module('myApp').directive('restrictInput',function(){
	return{
		restrict: 'A',
		require: 'ngModel',
		link: function(scope,elems,attrs,ngModel){
			var ele = elems[0];
			var regex = RegExp(attrs.restrictInput);
			
            var value = ele.value;
            ele.addEventListener('keyup',function(e){
				if(attrs.restrictInput!=undefined&&attrs.restrictInput!=null&&attrs.restrictInput!=""){
					if (regex.test(ele.value) || ele.value == ""){
						value = ele.value;
					}else {
						ele.value = value;
					}
					ngModel.$setViewValue(ele.value);
				}
            });
		}
	}
})