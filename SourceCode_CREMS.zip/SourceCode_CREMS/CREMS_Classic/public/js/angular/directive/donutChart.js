angular.module('myApp').directive('donutChart',function($rootScope){
	return {
		restrict:'E',
		link:function(scope,element,attrs){				
			$rootScope.$on('overview',function(){
				setTimeout(function(){
				_init();
			},500);
			});
			function _init(){
			

				var data=[{
				"Rig 1":8,
				"Rig 2":4,
				"Rig 3":5,
				"Rig 4":12
			},{
				"Rig 1":8,
				"Rig 2":4,
				"Rig 3":5,
				"Rig 4":12
			},{
				"Rig 1":8,
				"Rig 2":4,
				"Rig 3":5,
				"Rig 4":12
			}]
			
				//Donut chart example
			nv.addGraph(function() {
			  var chart = nv.models.pieChart()
			      .x(function(d) { return d.label })
			      .y(function(d) { return d.value })
			      .showLabels(true)     //Display pie labels
			      .labelThreshold(.05)  //Configure the minimum slice size for labels to show up
			      .labelType("value") //Configure what type of data to show in the label. Can be "key", "value" or "percent"
			      .donut(true)          //Turn on Donut mode. Makes pie chart look tasty!
			      .donutRatio(0.45)     //Configure how big you want the donut hole size to be.
			      .color(['rgb(254, 150, 102)', 'rgb(1, 184, 170)', 'rgb(31, 119, 180)']);
			      //rgb(255, 164, 0)
			      //rgb(31, 119, 180)
			    d3.select('#'+attrs.id+' svg')
			        .datum(exampleData())
			        .transition().duration(350)
			        .call(chart);

			        chart.tooltip.contentGenerator(function (d) {
			        

			          var html = "<h3>"+d.data.label+"</h3>";
			          
			          data.forEach(function(elem,i){
			        
			          	html+="<p>"+Object.keys(elem)[i]+" : "+elem[Object.keys(elem)[i]]+" <br>"
			          })	
			          html+="</p>";		        
			          return html;
			        })

			  return chart;
			});

			

			function exampleData() {
			  return  [
			      { 
			        "label": "Genset",
			        "value" : 29
			      } , 
			      { 
			        "label": "Compressor",
			        "value" : 12
			      } , 
			      { 
			        "label": "Mudpump",
			        "value" : 32
			      }
			    ];
			}
					}
				}
			}
			
});