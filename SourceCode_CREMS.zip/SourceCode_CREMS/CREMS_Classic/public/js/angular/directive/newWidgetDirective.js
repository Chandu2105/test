angular.module('myApp').directive('newWidgetCustom',function($rootScope){
	return {
		restrict: 'E',
		templateUrl: 'partials/newCustomWidgetDirective.html',
		transclude: true,
		link: function(scope,element,attrs){
			scope.extraClass = attrs.extraclass;
		}
	}
})