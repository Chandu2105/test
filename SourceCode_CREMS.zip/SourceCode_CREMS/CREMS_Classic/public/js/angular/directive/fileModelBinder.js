angular.module('myApp').directive('fileModelBinder',function(){
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function(scope,elems,attrs,ngModel){
            elems.bind('change',function(event){
                if(event.target.files.length>0){
                    var fileName = event.target.files[0];
                    ngModel.$setViewValue(fileName);
                }
            })
        }
    }
})