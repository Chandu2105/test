angular.module('myApp').directive('holderWidget',function(){
    return {
        restrict: 'E',
        templateUrl: 'partials/holderWidget.html',
        transclude: true,
        scope: {
            chartParams: '=config',
            showHistory: '&?'
        },
        link: function(scope,element,attrs){
            
        }
    }
})