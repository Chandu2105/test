angular.module('myApp').directive('multiBarChart',function($rootScope){
	return{
		restrict:'E',
		link:function(scope,element,attrs){
			function _init(){
			
				var margin = { top: 10, right: 10, bottom: 30, left: 40 }
				nv.addGraph(function() {
				   var chart = nv.models.multiBarChart()
				   .margin(margin)
				   .showControls(true)
				   .stacked(true)
				   .reduceXTicks(false);

				      //.transitionDuration(350)
				    // .reduceXTicks(false)   //If 'false', every single x-axis tick label will be rendered.
				     // .rotateLabels(0)      //Angle to rotate x-axis labels.
				     // .showControls(true)   //Allow user to switch between 'Grouped' and 'Stacked' mode.
				     // .groupSpacing(0.1)    //Distance between each group of bars.
				   // ;

				    /*chart.xAxis
				        .tickFormat(d3.format(',f'));*/

				    /*chart.yAxis
				        .tickFormat(d3.format(',.1f'));*/


				    d3.select('#'+attrs.id+' svg')
				        .datum(exampleData())
				        .call(chart);


				    nv.utils.windowResize(chart.update);

				    return chart;
				});

				//Generate some nice data.
				function exampleData() {
				  
				    return [
							  {
							    key: "Genset",
							    color: "rgb(252,80,76)",
							    values:
							    [      
							      { x : "Rig 1", y : 40 },
							      { x : "Rig 2", y : 30 },
							      { x : "Rig 3",   y : 20 }  
							    ]
							  },
							  {
							    key: "Compressor",
							    color: "rgb(253,129,126)",
							    values:
							    [      
							      { x : "Rig 1", y : 60 },
							      { x : "Rig 2", y : 50 },
							      { x : "Rig 3",   y : 70 } 
							    ]
							  },{
							    key: "Mudpump",
							    color: "rgb(254,178,176)",
							    values:
							    [      
							      { x : "Rig 1", y : 50 },
							      { x : "Rig 2", y : 10 },
							      { x : "Rig 3",   y : 100 } 
							    ]
							  }
							];	
				}
			}
			//_init();
			$rootScope.$on('overview',function(){
				setTimeout(function(){
				_init();
			},500);
			});

		}
	}
})