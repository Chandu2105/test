angular.module('myApp').directive('modalDirective',function(){
	return{
		restrict:'E',
		transclude: true,
		templateUrl:'partials/modalDirective.html',
		link:function($scope,element,attrs){
			
		}
	}
});