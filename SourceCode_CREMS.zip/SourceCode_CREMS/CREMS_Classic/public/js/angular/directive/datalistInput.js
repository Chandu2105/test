angular.module('myApp').directive('datalistInput',function($filter,$timeout){
	return{
		restrict: 'E',
		scope: {
			data: "=",
			model: "=",
			header:"=?",
			disabled: "=?",
			enablepopulation: '=?',
			multiple: '=?',
			masterData: '=?'
		},
		templateUrl: 'partials/datalistInput.html',
		link: function(scope,elems,attrs){
			if(attrs.placeholder)
				scope.header = attrs.placeholder;

			scope.$watch('model',function(newVal,oldVal){
				if(!scope.multiple){
					if(newVal!=null && newVal !=undefined && scope.data!=null && scope.data!=undefined){
						var x = scope.data.filter(function(val){return val.value == newVal});
						scope.temp = x.length==0?"":x[0]['item'];
						scope.currPref = scope.temp;
						scope.displaySearch = false;
					}
					var inputElem = $(elems.find('input'))[0];

					if(newVal == null && !$(inputElem).is(':focus')){
						scope.currPref = "";
					}
				}else{
					if(newVal!=null && newVal!=undefined && scope.data!=null && scope.data!=undefined){
						if(newVal.constructor === Array && newVal.length > 0){
							var k = [];

							if(scope.masterData != null && scope.masterData != undefined && scope.masterData.constructor === Array && scope.masterData.length > 0){
								k = scope.masterData.filter(function(x){
									return x.value == newVal[newVal.length - 1];
								});
							}

							if(k.length > 0){
								if($.inArray(k[k.length - 1]['item'],scope.names) == -1){
									scope.names.push(k[k.length - 1]['item']);
								}
							}
						}else{
							scope.names = [];
						}
					}

					var inputElem = $(elems.find('input'))[0];
					
					if(newVal == null && !$(inputElem).is(':focus')){
						scope.names = [];
					}
				}
			},true);

			scope.datalistFocus = function(e){
				if(!scope.multiple){
					scope.currPref = "";
					scope.model = null;
				}else{

				}
			}

			scope.removeItem = function(index){
				scope.data.push(scope.masterData.filter(function(t){
					return t.value == scope.model[index];
				})[0]);

				scope.names.splice(index,1);
				scope.model.splice(index,1);
			}

			scope.datalistFillNext = function(e){
				var ev = e || window.event;
				if(!scope.multiple){
					if(ev.keyCode == 40){
						if(scope.currPref == "" || scope.currPref == null || scope.currPref == undefined){
							scope.fillOptions(scope.lessdata[0],0,0);
						}else{
							var i = (scope.currIndex + 1)%scope.lessdata.length;
							scope.fillOptions(scope.lessdata[i],i,0);
						}
					}else if(ev.keyCode == 38){
						if(scope.currPref == "" || scope.currPref == null || scope.currPref == undefined){
							scope.fillOptions(scope.lessdata[0],0,0);
						}else{
							var i = (scope.currIndex - 1)%scope.lessdata.length;
							i = i<0?scope.lessdata.length-1:i;
							scope.fillOptions(scope.lessdata[i],i,0);
						}
					}else if(ev.keyCode == 13){
						if(scope.enablepopulation){
							if(scope.currPref != undefined && scope.currPref != null && scope.currPref!="" 
									&& scope.model != undefined && scope.model != null && scope.model!=""){
								scope.$emit('enteredVal',scope.model);
								scope.currPref = "";
								scope.model = null;
							}
						}
					}
				}else{

				}
			}

			$(document).click(function(event){
				if(!$(event.target).parent().hasClass('datalistContainer')){
					$timeout(function(){
						scope.$apply(function(){
							scope.displaySearch = false;
						});
					},0)
				}
			})
		},
		controller: function($scope){
			$scope.$on('clearAllFormFields',function(event,mess){
				$scope.displaySearch = false;
				$scope.currPref = "";
			})

			$scope.names = [];

			$scope.displaySearch = false;
			$scope.lessdata = $scope.data;
			$scope.currPref = "";
			$scope.currIndex = 0;
			$scope.model = ($scope.model == undefined || $scope.model == null || $scope.model == '') ? [] : $scope.model;

			$scope.$watch('data',function(newVal,oldVal){

				if(newVal!=undefined && newVal!=null){
					if(!$scope.multiple){
						$scope.lessdata = newVal;
						if($scope.model != undefined && $scope.model != null && $scope.model != ""){
							var x = [];
							x = $scope.lessdata.filter(function(val){return val.value == $scope.model});
							$scope.temp = x.length==0?"":x[0]['item'];
							$scope.currPref = $scope.temp;
						}
					}else{
						$scope.lessdata = newVal;

						if($scope.model != null && $scope.model != undefined && $scope.model != '' && $scope.model.constructor === Array && $scope.model.length > 0){
							$scope.names = $scope.model.map(function(v){
								return $scope.masterData.filter(function(b){return b['value'] == v})[0].item;
							})
						}
					}
				}
			},true)

			$scope.displaySuggestions = function(){
				if($scope.lessdata!=undefined && $scope.lessdata.length == 0)
					$scope.lessdata = $scope.data;
				$scope.displaySearch = !$scope.displaySearch;
			}

			$scope.fillOptions = function(option,ind,type){
				if(!$scope.multiple){
					$scope.model = option.value;
					$scope.currPref = option.item;
					$scope.temp = option.item;
					$scope.displaySearch = false;
					$scope.currIndex = ind;
					
					if($scope.enablepopulation){
						if($scope.currPref != undefined && $scope.currPref != null && $scope.currPref!="" 
									&& $scope.model != undefined && $scope.model != null && $scope.model!=""){
							$scope.$emit('enteredVal',$scope.model);
							$scope.currPref = "";
							$scope.model = null;
						}
					}
				}else{
					$scope.model = ($scope.model == undefined || $scope.model == null || $scope.model == '') ? [] : $scope.model;

					if($.inArray(option.value,$scope.model) == -1){
						$scope.model.push(option.value);
						$scope.displaySearch = false;
					}
				}
			}

			$scope.$watch('currPref',function(newVal,oldVal){
				if(!$scope.multiple){
					if($scope.data!=undefined && $scope.data!=null){					
						var x = $scope.data.filter(function(val){return val.item == newVal?true:false;});					
						$scope.model = (function(){return x.length==0?undefined:x[0]['value']})();					
					}

					if(newVal!="" && $scope.temp != $scope.currPref){
						$scope.displaySearch = true;
						$scope.lessdata = $filter('areaFilter')($scope.data,$scope.currPref);
						if($scope.lessdata!=null && $scope.lessdata != undefined && $scope.lessdata.length==0){
							$scope.err = 'redBorder';
						}
					}
					else{
						$scope.displaySearch = false;
						$scope.lessdata = $scope.data;
						$scope.err = '';
					}
				}else{
					if($scope.data!=undefined && $scope.data!=null){
						if(newVal != undefined && newVal != null && newVal != ''){
							$scope.lessdata = $filter('areaFilter')($scope.data,$scope.currPref);
							if($scope.lessdata!=null && $scope.lessdata != undefined && $scope.lessdata.length==0){
								$scope.err = 'redBorder';
							}
							$scope.displaySearch = true;
						}
					}
				}
			});

		}
	}
})