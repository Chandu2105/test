angular.module('myApp').service('AreaService',function($http,$q){
	this.getRigEquipmentsDeploymentList = function(areaId){
		var q = $q.defer();
		$http.get("/getRigEquipmentsDeploymentList",{params: {areaId: areaId}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch Data!"})
		});
		return q.promise;
	}
	
});