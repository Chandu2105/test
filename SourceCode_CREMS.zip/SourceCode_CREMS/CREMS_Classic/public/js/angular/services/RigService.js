angular.module('myApp').service('RigService',function(MainService,$http,$q){
	this.getAllRigEquipments = function(rigId){
		var q = $q.defer();
		$http.get("/getAllRigEquipments",{params: {rigId: rigId}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch Data!"})
		});
		return q.promise;
	};

	this.getRigWellInfo = function(rigId){
		var q = $q.defer();
		$http.get("/getRigWellInfo",{params: {id: rigId}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch Data!"})
		});
		return q.promise;
	}

	this.getRigInfo = function(id){
		var q = $q.defer();
		$http.get("/getRigInfo",{params: {id: id}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch Data!"})
		});
		return q.promise;
	}
	
	this.getRigWellAttributes = function(id){
		var q = $q.defer();
		$http.get("/getRigWellAttributes",{params: {id: id}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch Data!"})
		});
		return q.promise;
	}
});