angular.module('myApp').service("DropDownService",function($http,$q){
	
	this.getDropDownMenu = function(){
		var q = $q.defer();
		$http.get("/getDropDownMenu").then(function(data){
			q.resolve(data.data);
		},function(data){
			
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	};
});