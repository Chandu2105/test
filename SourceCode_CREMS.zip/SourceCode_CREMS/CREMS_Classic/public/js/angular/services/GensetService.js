angular.module('myApp').service('GensetService',function($q,$http){
	this.baseUrl = "http://blrkec334211d:7410";
	
	// to  get genset specification	
	this.getGensetSpecifications = function(type){
		var q=$q.defer();		
		$http.get('/gensetSpecifications?type='+type).then(function(data){
			q.resolve(data.data)
		}, function(data){
			q.reject({"error_message":"sry cannot fetch data"});
		});
	
		return q.promise;
	};
	
	this.updatePredictiveMaintenance = function(rigEquipmentId,comment,lastUser){
		var q=$q.defer();		
		$http.get('/updatePredictiveMaintenance',{params: {rigEquipmentId: rigEquipmentId,comment: comment,lastUser: lastUser}}).then(function(data){
			if(data.data.indexOf("Success") > -1){
				q.resolve(data.data);
			}else{
				q.reject(data.data);
			}
		}, function(data){
			q.reject("Sorry, could not fetch the data. Please try again in a while.");
		});
	
		return q.promise;
	}
	//to get threshold values of parameters
	// this.getGensetParametersThreshold=function(){		
	// var q=$q.defer();

	// $http.get('/gensetParametersThreshold').then(function(data){
		// // console.log("gensetParametersThreshold ");
		// // console.log(data.data);
		// q.resolve(data.data);		
	// },function(err){
		// console.log("error ");
		// console.log(err);
		// q.reject({"error_message":"sry cannot fetch data"});
	// });	
	
	// return q.promise;
	// };
	
	//to get all the parameters data from DB 
	this.getGensetParameters=function(type){
	var q=$q.defer();
	$http.get('/gensetParameters?type='+type).then(function(data){
		q.resolve(data.data);		
	},function(err){
		q.reject({"error_message":"sry cannot fetch data"});
	});	
	
	return q.promise;
	};
	
	//to get all the maintenance data 
	this.getMaintenanceScheduleData=function(type){
		var q=$q.defer();
		$http.get('/getMaintenanceScheduleData?type='+type).then(function(data){
			q.resolve(data.data);
		},function(err){
			q.reject({"error_message":"sry cannot fetch data"});			
		});
		return q.promise;
		
	}
	
	// to get Activity checklist
	this.getActivityChecklist=function(type, equipType){
		var q=$q.defer();
		$http.get('/getActivityChecklist?type='+type+'&equipType='+equipType).then(function(data){
			q.resolve(data.data);
		},function(err){
			q.reject({"error_message":"sry cannot fetch data"});
		});
		return q.promise;
	}

	// to get last six instance maintenance data
	this.getSixInstanceData=function(equip_id, equipType){
		var q=$q.defer();
		$http.get('/getSixInstanceData?equip_id='+equip_id+'&equipType='+equipType).then(function(data){
			q.resolve(data.data);
		},function(err){
			q.reject({"error_message":"sry cannot fetch data"});
		});
		return q.promise;
	}
	// get drawworks summary data
	this.getDrawworksSummaryData=function(type, equipType){
		var q=$q.defer();
		$http.get('/getDrawworksSummaryData?type='+type+'&equipType='+equipType).then(function(data){
			q.resolve(data.data);
		},function(err){
			q.reject({"error_message":"sry cannot fetch data"});
		});
		return q.promise;
	}
	
	// to get maintenance history
	this.getMaintenanceHistory=function(type,startDate,endDate){
		var q=$q.defer();
		$http.get('/getMaintenanceHistory',{params:{"type": type,"startDate":startDate,"endDate":endDate}}).then(function(data){
			q.resolve(data.data);
		},function(err){
			q.reject({"error_message":"sry cannot fetch data"});
		});
		return q.promise;
	};
	
	// to get MaintenanceBreakdownSummary
	this.getMaintenanceBreakdownSummary=function(type){
		var q=$q.defer();
		$http.get('/getMaintenanceBreakdownSummary?type='+type).then(function(data){
			q.resolve(data.data);
		},function(err){
			q.reject({"error_message":"sry cannot fetch data"});
		});
		return q.promise;
	};
	
	// to update activity status
	this.updateActivityStatus=function(activityId,userId){
		var q=$q.defer();
		$http.get('/updateActivityStatus',{params:{"activityId": activityId,"userId":userId}}).then(function(data){
			q.resolve(data.data);
		},function(err){
			q.reject({"error_message":"sry cannot update data"});
		});
		return q.promise;
	};
	
	// to update event log
	this.updateEventLog=function(activityId,equipId,activity){
		var q=$q.defer();
		$http.get('/updateEventLog',{params:{"activityId": activityId,"equipId":equipId,"activity":activity}}).then(function(data){
			q.resolve(data.data);
		},function(err){
			q.reject({"error_message":"sry cannot update data"});
		});
		return q.promise;
	};

	// to update checkList Status
	this.updateCheckListComment=function(activityId,comment){
		var q=$q.defer();
		$http.get('/updateCheckListComment',{params:{"activityId": activityId,"comment":comment}}).then(function(data){
			q.resolve(data.data);
		},function(err){
			q.reject({"error_message":"sry cannot update data"});
		});
		return q.promise;
	};

	// to update checkList Status
	this.updateEquipMaintClosingDate=function(activityId){
		var q=$q.defer();
		$http.get('/updateEquipMaintClosingDate',{params:{"activityId": activityId}}).then(function(data){
			q.resolve(data.data);
		},function(err){
			q.reject({"error_message":"sry cannot update data"});
		});
		return q.promise;
	};
	
});