angular.module('myApp').service('MainService',function($http,$q,$location,$state){

	this.baseUrl = "http://blrkec156347l:7410";
	this.generatorPath = "images/Generator.jpg";
	this.mudpumpPath = "images/MudPump.jpg";
	this.agitatorPath = "images/Agitator.jpg";
	this.shakerPath = "images/Shaker.jpg";
	this.drawworksPath = "images/Drawbox.jpg";
	
	var self = this;
	var map;
	
	this.getAllMachinesList = function(){
		var q = $q.defer();
		$http.get('/getAllMachines').then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage: "Sorry, could not fetch data!"});
		})
		return q.promise;
	}
	
	this.getDescription = function(){
		var options = [];
		var obj1 = {"value":"Generator","item":"Generator"};
		options.push(obj1);
		// obj1 = {"value":"Compressor","item":"Compressor"};
		// options.push(obj1);
		obj1 = {"value":"Mud Pump","item":"Mud Pump"};
		options.push(obj1);
		obj1 = {"value":"Agitator","item":"Agitator"};
		options.push(obj1);
		obj1 = {"value":"Shaker","item":"Shaker"};
		options.push(obj1);
		obj1 = {"value":"Drawworks","item":"Drawworks"};
		options.push(obj1);
		return options;
	}
	
	this.getVibrationThresholds = function(type){
		// var temp = {
		// 	"Generator": 11.77514964,
		// 	"Mud Pump": 1.038395517,
		// 	"Agitator": 10,
		// 	"Shaker": 6.632567366,
		// 	"Drawworks": 10
		// }

		// return temp[type];

		var q = $q.defer();
		$http.get('/getVibrationThresholds',{params: {type: type}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage: "Sorry, could not fetch data!"});
		})
		return q.promise;
	}

	this.getAllSensorsList = function(){
		var q = $q.defer();
		$http.get('/getAllSensors').then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage: "Sorry, could not fetch data!"});
		})
		return q.promise;
	}
	
	this.getCollectorsListForMachine = function(machineName){
		var q = $q.defer();
		$http.get('/getMachineCollectors',{params:{"query": machineName}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage: "Sorry, could not fetch data!"});
		})
		return q.promise;
	}
	
	this.getRawSensorData = function(startTimestamp,endTimestamp,sensorMac,filterList){
		var paramArray = [sensorMac,startTimestamp,endTimestamp,filterList];
		var q = $q.defer();
		$http.get('/getRawSensorData',{params:{sensorMac: sensorMac,startTimestamp: startTimestamp,endTimestamp: endTimestamp,filterList: filterList}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage: "Sorry, could not fetch data!"});
		})
		return q.promise;
	}
	
	this.callChart = function(containerId,data){
		nv.addGraph(function() {
            var chart = nv.models.sparklinePlus();
            chart.margin({left:70})
                .x(function(d,i) { return moment(d.datetime,"YYYY-MM-DDTHH:mm:ss.SSSZ").unix()*1000 })
                .y(function(d){ return d['ac']['x'] })
                .showLastValue(false)
                .xTickFormat(function(d) {
                    return d3.time.format('%H:%M:%S')(new Date(d))
                }).yTickFormat(function(d){
                	return d3.format('0.04f')(d);
                });
            d3.select(containerId)
                    .datum(data)
                    .call(chart);
            
            d3.select(containerId+" .nvd3.nv-wrap.nv-sparkline path").style('stroke','red');
            
            d3.selectAll('.nv-hoverArea')
            return chart;
        });
	}
	
	this.activateHeaderTab = function(val){
		var elems = $('.header-tab');
		$.each(elems,function(elem){
			elems[elem].innerText==val?$(elems[elem]).addClass("active"):$(elems[elem]).removeClass('active');
		})
	}
	
	this.activateSidebarButton = function(){
		// $(window).resize(function(){
			// if($(window).width()>=768){
				// $('#sidebarShow').css('left',"15%");
				// $('.sidebar-inner').css({'display': 'block','width': '15%'});
				// $('.mainPage').css({'width':'85%','left': '15%'});
			// }else{
				// $('#sidebarShow').css('left',"0%");
				// $('.sidebar-inner').css({'display': 'none','width': '0%'});
				// $('.mainPage').css({'width':'100%','left': '0'});
			// }
		// });
		// $('#sidebarShow').click(function(){
			// if($(this).css('left')=="0px"){
				// $(this).css('left',"15%");
				// $('.sidebar-inner').css({'display': 'block','width': '15%'});
				// //$('.mainPage').css({'width':'85%','left': '15%'});
			// }else{
				// $(this).css('left',"0px");
				// $('.sidebar-inner').css({'display': 'none','width': '0%'});
				// //$('.mainPage').css({'width':'100%','left': '0'});
			// }
		// });
	}

	this.initialiseMap = function(id){
		map = L.map(id, {
			center : [ 16.505, 81.8784 ],
			zoom : 1
		});

		L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}',
			{
				attribution : 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery � <a href="http://mapbox.com">Mapbox</a>',
				maxZoom : 16,
				id : 'ravishankar028.cifs2slpw18p4s6m6gcqsnu4j',
				accessToken : 'pk.eyJ1IjoicmF2aXNoYW5rYXIwMjgiLCJhIjoiY2lmczJzbmJrMTd3bnNobTZvcmN6c2xybCJ9.PiI4Ui8ZqfxzFcdFoGsQhw'
			}).addTo(map);
	};

	this.setMapMarkers=function(coordinates){
		
		var icon1 = "<svg xmlns='http://www.w3.org/2000/svg' version='1.1' width='100' height='100'>"+
			'<defs> <filter id="f1" x="-40%" y="-40%" height="200%" width="200%">'+
		      '<feOffset result="offOut" in="SourceAlpha" dx="4" dy="4" />'+
		      '<feGaussianBlur result="blurOut" in="offOut" stdDeviation="8" />'+
		      '<feBlend in="SourceGraphic" in2="blurOut" mode="normal" />'+
		    '</filter>'+
		  '</defs>'+
		 '<circle class="shadow" cx="50" cy="50" r="40" fill="green" filter="url(#f1)" /></svg>';

	        // here's the trick, base64 encode the URL
	    var svgURL = "data:image/svg+xml;base64," + btoa(icon1);
	        
		var SafeIcon = L.Icon.extend({
		    options: {
		    	iconUrl: svgURL,
			    iconSize: new L.Point(25, 25),
			    shadowSize: new L.Point(10, 16),
			    iconAnchor: new L.Point(10, 16),
			    popupAnchor: new L.point(1, -30)
		    }
		});
		
		if(coordinates.length==1){
			map.setView(new L.LatLng(coordinates[0].lat,coordinates[0].lon),7);
		}else{
			var latSort = coordinates.sort(function(a,b){return a.lat-b.lat});
			var longSort = coordinates.sort(function(a,b){return a.lon-b.lon});
			map.fitBounds(new L.LatLngBounds(new L.LatLng(latSort[0].lat,longSort[0].lon),
						  new L.LatLng(latSort[coordinates.length-1].lat,longSort[coordinates.length-1].lon)),{padding: [50,50]});
		}

		for(var i=0;i<coordinates.length;i++){
			var marker = L.marker(new L.LatLng(coordinates[i].lat,coordinates[i].lon), { title: coordinates[i].place });
			var icon = new SafeIcon();
			marker.setIcon(icon);
			marker.rig_id = coordinates[i].rig_id;
			marker.on('click',function(event){
				self.clearArrayIntervals();
				$state.go('app.dashboard.rig',{id: this.rig_id,name: event.target.options.title},{location: false});
			});
			map.addLayer(marker);
		}

		//map.fitBounds(map.getBounds());
	}
	
	this.cleanExistingMarkers = function(map,markers){
		for(var i=0;i<markers.length;i++){
			map.removeLayer(markers[i]);
		}
		markers = [];
		return markers;
	}
	
	this.hideBreadcrumb = function(val){
		if(val){
			$('.breadcrumb').hide();
			$('.AggregatesNew').css('height','91.9vh');
		}
		else{
			$('.breadcrumb').show();
			$('.AggregatesNew').css('height','85.5vh');
		}
	}
	
	this.initialiseSettingsPanel = function(){
		$('.settings').click(function(){
			$('.settingsPanel').fadeToggle('fast',"linear");
		})
	}
	
	this.initialiseOuterClickHide = function(){
		$(document).click(function(event) { 
			// to hide the left menu
			if(!$(event.target).closest('#menuButton').length && !$(event.target).closest('#assetHierarchy').length) {
				if($('#assetHierarchy').is(":visible")) {
					$('#assetHierarchy').fadeToggle(300);
				}	
			}					

			// to hide the right menu	
			 if(!$(event.target).closest('.settings').length && !$(event.target).closest('.settingsPanel').length) {
				if($('.settingsPanel').is(":visible")) {
					$('.settingsPanel').fadeToggle(300);
				}
			}       
		});
	};
	
	this.initialiseDropdownHover = function(){
		$('ul.nav li.dropdown').hover(function() {
		  $(this).find('.dropdown-menu').stop(true, true).delay(100).fadeIn(200);
		}, function() {
		  $(this).find('.dropdown-menu').stop(true, true).delay(100).fadeOut(200);
		});
	}

	this.getRigCoordinates = function(val,type){
		var q = $q.defer();
		$http.get("/getRigCoordinates",{params: {rigId: val,type: type}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	};
	
	this.getIncidentDetails = function(type,id){
		var q = $q.defer();
		$http.get("/getIncidentDetails",{params: {type: type,id: id}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	}
	
	this.getFilteredIncidents = function(obj){
		var q = $q.defer();
		$http.get("/getFilteredIncidents",{params: {obj: obj}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	} 

	this.checkOpenIncidents = function(dataArray){
		if(dataArray.length!=0){
			$.each(dataArray,function(index,value){
				if(value.INCIDENT_STATUS==0)
					return true;
				else if(index==dataArray.length)
					return false;
			})
		}else
			return false;
	}
	
	this.getEventDetails = function(type,id){
		var q = $q.defer();
		$http.get("/getEventDetails",{params: {type: type,id: id}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	}
	
	this.updateIncident = function(id,comment,status){
		var q = $q.defer();
		$http.get("/updateIncident",{params: {id: id,comment: comment,status: status}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	}

	this.clearArrayIntervals = function(){
		if(intervalsList!=null && intervalsList!=undefined){
			$.each(intervalsList,function(index,value){
				clearInterval(value);
				if(value)
					delete value;
			});
			intervalsList = [];
		}
	}

	this.downloadEquipmentConfig = function(id){
		var q = $q.defer();
		$http.get("/downloadEquipmentConfig",{params: {id: id}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	}
	
	this.downloadFile = function(id){
		var q = $q.defer();

		$http.get("/downloadFile",{params: {id: id}}).then(function(data){
			var w = window.open("/downloadFile?id="+id,'_blank');
			q.resolve(data.data);
		},function(data){
			if(data.data == "Error"){
				q.reject({ErrorMessage : "There has been no manual uploaded for this equipment!"});
			}else if(data.data == 'Not found'){
				q.reject({ErrorMessage : 'No file found at the server location.'});
			}else{
				q.reject({ErrorMessage : "Error contacting the server. Please try again later."});
			}
		});

		return q.promise;
	}
	
	this.getWeeklyMaintenanceDetails = function(type,id){
		var q = $q.defer();
		$http.get("/getWeeklyMaintenanceDetails",{params: {type: type,id: id}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	}

	this.getLatestCriticalParams = function(id){
		var q = $q.defer();
		$http.get("/getLatestCriticalParams",{params: {id: id}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	}

	//return the image paths
	this.getEquipmentImagePaths = function(equipType){
		switch(equipType.toLowerCase()){
			case 'generator':
				return this.generatorPath;
			case 'mud pump':
				return this.mudpumpPath;
			case 'agitator':
				return this.agitatorPath;
			case 'shaker':
				return this.shakerPath;
			case 'drawworks':
				return this.drawworksPath;
		}
	}
	//Maintenance Data for area page

	this.getAreaMaintData=function(areaId, equipType){
		//console.log(areaId+" "+equipType);
		var q=$q.defer();
		$http.get('/getAreaMaintData?areaId='+areaId+'&equipType='+equipType).then(function(data){
			q.resolve(data.data);
		},function(err){
			q.reject({"error_message":"sry cannot fetch data"});
		});
		return q.promise;
	}

	//Maintenance Data for rig page

	this.getRigMaintenanceData=function(rigId, equipType){
		//console.log(rigId+" "+equipType)
		var q=$q.defer();
		$http.get('/getRigMaintenanceData?rigId='+rigId+'&equipType='+equipType).then(function(data){
			q.resolve(data.data);
		},function(err){
			q.reject({"error_message":"sry cannot fetch data"});
		});
		return q.promise;
	}

	this.closeAllIncidents = function(array){
		if(array.length==0)
			return true;
		else if(array.filter(function(value){return value.INCIDENT_STATUS==0}).length==0)
			return true;
		else
			return false;
	}

	this.updateEventLogForIncidents = function(equipmentId,incidentDesc){
		var q = $q.defer();
		$http.get("/updateEventLogForIncidents",{params: {desc: incidentDesc,id: equipmentId}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	}

	var datePickerId = 0;
	var mapId = 0;
	
	this.dropDownList = {};

	this.getConfiguratorDropDown = function(type){
		var q = $q.defer();
		$http.get("/getConfiguratorDropDownMenu",{params: {type: type}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	}

	this.getRefinedDropDown = function(data){
		var options = [];
		var attrs = ["value","item"];
		$.each(data,function(index,value){
			var obj = {};
			var keyList = Object.keys(value);
			var upperValue = value;
			$.each(keyList,function(index,value){
				obj[attrs[index]] = upperValue[value];
			});
			options.push(obj);
		});
		return options;
	}

	this.getObjectForType = function(header,type,uomType){
		var obj;

		if(type == 1){
			obj = {
				header: header,
				type: "inputBox",
				data: null,
				inputType : "text",
				pattern : "^[A-Za-z0-9\\s]+$"
			}
			if(header.indexOf("Password") > -1){
				obj.inputType = "password";
			}
			else if(header.indexOf("Sensor MAC ID") > -1){
				obj.pattern = "^[A-Za-z0-9]+$";
			}
		}
		else if(type == 2){
			datePickerId++;
			obj = {
				header : header,
				type : "dateTimePicker",
				data : null,
				id : 'dateTimePicker' + datePickerId
			}	
		}

		else if(type == 3){
			obj = {
				header : header,
				type : "dropBox",
				data : null,			

			}
			if(header.indexOf("UOM") > -1){
				obj.options = this.getRefinedDropDown(this.dropDownList["UOM"]);
			}
			if(header.indexOf("Description") > -1){
				obj.header = "Equipment Type";
			}
			else if(header=="Operator" || header == "Owner"){
				obj.options = this.getRefinedDropDown(this.dropDownList["User Name"]);	
			}else if(header=="Active"){
				obj.options = [{value:"Active",item:"Active"},{value:"Inactive",item:"Inactive"}];
			}
			else{
				obj.options = this.getRefinedDropDown(this.dropDownList[header]);			
			}
		}
		else if(type == 4){
			mapId++;
			obj = {
				header : "Location Picker",
				type : "map",
				data : ["",""],
				mapid : "mapId" + mapId
			}
		}
		else if(type == 5){
			obj = {
				header: header,
				type: "inputBox",
				data: null,
				inputType : "text",
				pattern : "^\\d*$"
			}			
		}

		if(uomType != undefined){
			obj.uomType = uomType;
		}

		return obj;
	}

	this.getConfiguratorTables = function(type){
		var q = $q.defer();
		$http.get("/getConfiguratorTables",{params: {type: type}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	}

	this.editConfiguratorTables = function(type,id){
		var q = $q.defer();
		$http.get("/editConfiguratorTables",{params: {type: type,id: id}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	}

	this.storeAddData = function(data,type){
		var obj = {};
		if(type=="asset"){
			obj = {
				"assetName" :"",
				"modifiedUserId": JSON.parse(sessionStorage.getItem('user')).Id
			}
		}
		else if(type == "area"){
			obj = {
				"areaName" : "",
				// "latitude" : 0,
				// "longitude" : 0,
				"assetId" : 0
			}
		}
		else if(type == "rig"){
			obj = {
				"rigName": "",
				"commisionDate": "",
				"decommisiondate": "",
				"effectiveDate": "",
				"expiryDate": "",
				"hookLoadCapacity": 0,
				"hookLoadCapacityUOM": 0,
				"kbGroundDistance": 0,
				"kbGroundDistanceUOM": 0,
				"mastHeight": 0,
				"mastHeightUOM": 0,
				"mastType": 0,
				"maxDepth": 0,
				"maxDepthUOM": 0,
				"operatorID": 0,
				"ownerID": 0,
				"remark": "",
				"rigCategory": 0,
				"rigClass": 0,
				"rigCode": 0,
				"rigType": 0,
				"waterDepth": 0,
				"waterDepthDatum": 0,
				"waterDepthUOM": 0
			}
		}
		//$scope.listOfHeaders = ["UWI","Well Name","Well Status","Spud Date","Completion Date",
		//"Abandonment Date","Country","Asset","Area","Rig","County","Current Status Date","Depth Datum Type",
		//"Depth Datum Elevation","Depth Datum Elevation UOM","Operator","Region","Total Depth","Well Type","Production Method",
		//"Reservoir Name","Artificial Lift Type","Artificial Start Date","Current Status","Production Start Date",
		//"Surface Lat/Long"];

		else if (type == "well"){
			obj = {
				"UWI": "",
				"wellName" : "",
				"wellStatusid" : 0,
				"spudDate" : "",
				"completionDate" : "",
				"abandonmentDate" : "",
				"country" : 0,
				"assetId" : 0,
				"areaId" : 0,
				"rigId":0,			
				"county" : 0,
				"currentStatusDate" : "",
				"depthDatumTypeId" : 0,
				"depthDatumElev" : 0,
				"depthDatumElevUOM" : 0,
				"operatorID" : 0,
				"region":"",
				"totalDepth":0,
				"wellType":"",
				"prodMethod":"",
				"reservoirName":"",
				"artificialLiftType":"",
				"artificialStartDate":"",
				"currentStatus":"",
				"productionStartDate":"",
				"targetMeasuredDepth":0,
				"trueVerticalDepth:":0,
				"currentMeasuredDepth":0,
				"currentTrueVerticalDepth":0,
				"latitude" : 0,
				"longitude" : 0
			}
		}
		else if(type == "equipment"){
			obj = {
				"equipmentName" : "",
				"description" : "",
				"equipmentOEMNumber" : "",
				"purchaseDate" : "",
				"effectiveDate" : "",
				"expiryDate" : "",
				"manufacturer" : 0,
				"latitude" : 0,
				"longitude" : 0
			}
		}

		var keyList = Object.keys(obj);

		keyList = keyList.filter(function(data){
			return ((data.indexOf("latitude") == -1) && (data.indexOf("modifiedUserId") == -1));
		});

		$.each(keyList,function(index,value){
			if(data[index].type == "map"){
				obj["latitude"] = parseFloat(data[index].data[0]);
				obj["longitude"] = parseFloat(data[index].data[1]);
			}
			else if(data[index].type == "dateTimePicker"){
				obj[value] = moment($("#"+data[index].id+" > input").val(),"DD/MM/YYYY").utc().format("YYYY-MM-DD HH:mm:ss.SSS");
			}
			else{
				obj[value] = parseFloat(data[index].data) && value != "UWI"?parseFloat(data[index].data):data[index].data;
			}
		});

		var q = $q.defer();
		this.getTheJson(type,obj).then(function(data){
			console.log(data);
			q.resolve(data);
		},function(err){
			console.log(err);
			q.reject(data);
		});
		return q.promise;
	}

	this.storeEditData = function(data,type,id){
		var obj = {};
		if(type=="asset"){
			obj = {
				"assetId" : 0,
				"assetName" :"",
				"modifiedUserId": 0
			}
			obj["assetId"] = id;
			obj["modifiedUserId"] = JSON.parse(sessionStorage.getItem('user')).Id;
		}
		else if(type == "area"){
			obj = {
				"areaId" : 0,
				"areaName" : "",
				//"latitude" : 0.0,
				//"longitude" : 0.0,
				"assetId" : 0
			}
			obj["areaId"] = id;
		}else if(type == "rig"){
			obj = {
				"rigId": 0,
				"rigName": "",
				"commisionDate": "",
				"decommisiondate": "",
				"effectiveDate": "",
				"expiryDate": "",
				"hookLoadCapacity": 0,
				"hookLoadCapacityUOM": 0,
				"kbGroundDistance": 0,
				"kbGroundDistanceUOM": 0,
				"mastHeight": 0,
				"mastHeightUOM": 0,
				"mastType": 0,
				"maxDepth": 0,
				"maxDepthUOM": 0,
				"operatorID": 0,
				"ownerID": 0,
				"remark": "",
				"rigCategory": 0,
				"rigClass": 0,
				"rigCode": 0,
				"rigType": 0,
				"waterDepth": 0,
				"waterDepthDatum": 0,
				"waterDepthUOM": 0
			}
			obj["rigId"] = id;
		}
		else if (type == "well"){
			obj = {
				"UWI": id+"",
				"wellName" : "",
				"wellStatusid" : 0,
				"spudDate" : "",
				"completionDate" : "",
				"abandonmentDate" : "",
				"country" : 0,
				"assetId" : 0,
				"areaId" : 0,
				"rigId":0,			
				"county" : 0,
				"currentStatusDate" : "",
				"depthDatumTypeId" : 0,
				"depthDatumElev" : 0,
				"depthDatumElevUOM" : 0,
				"operatorID" : 0,
				"region":"",
				"totalDepth":0,
				"wellType":"",
				"prodMethod":"",
				"reservoirName":"",
				"artificialLiftType":"",
				"artificialStartDate":"",
				"currentStatus":"",
				"productionStartDate":"",	
				"targetMeasuredDepth":0,
				"trueVerticalDepth":0,
				"currentMeasuredDepth":0,
				"currentTrueVerticalDepth":0,
				"latitude" : 0,
				"longitude" : 0
			}
		}
		else if(type == "equipment"){
			obj = {
				"equipmentId" : 0,
				"description" : "",
				"equipmentName" : "",
				"equipmentOEMNumber" : "",
				"purchaseDate" : "",
				"effectiveDate" : "",
				"expiryDate" : "",
				"manufacturer" : 0
			}
			obj["equipmentId"] = id;
		}

		var keyList = Object.keys(obj);
		
		keyList = keyList.filter(function(data){
			return ((data.indexOf("latitude") == -1) && (data.indexOf("modifiedUserId") == -1) && keyList[0] != data);
		});
		
		$.each(keyList,function(index,value){
			if(type =='well'){
				index+=1;
				if(data[index].type == "map"){
					obj["latitude"] = parseFloat(data[index].data[0]);
					obj["longitude"] = parseFloat(data[index].data[1]);
				}
				else if(data[index].type == "dateTimePicker"){
					obj[value] = moment($("#"+data[index].id+' > input').val(),"DD/MM/YYYY").utc().format("YYYY-MM-DD HH:mm:ss.SSS");
				}
				else{
					obj[value] = parseFloat(data[index].data) && (value != "UWI" || value !="wellId")?parseFloat(data[index].data):data[index].data;
				}
			}else{
				if(data[index].type == "map"){
					obj["latitude"] = parseFloat(data[index].data[0]);
					obj["longitude"] = parseFloat(data[index].data[1]);
				}
				else if(data[index].type == "dateTimePicker"){
					obj[value] = moment($("#"+data[index].id+' > input').val(),"DD/MM/YYYY").format("YYYY-MM-DD HH:mm:ss.SSS");
				}
				else{
					obj[value] = parseFloat(data[index].data) && (value != "UWI" || value !="wellId")?parseFloat(data[index].data):data[index].data;
				}
			}
			
		});

		var q = $q.defer();
		console.log(obj);
		
		this.editTheJson(type,obj).then(function(data){
			console.log(data);
			q.resolve(data);
		},function(err){
			console.log(err);
			q.reject(data);
		});
		return q.promise;
	}

	this.addCollapsibleTemplatedData = function(data,type){
		if(type=="equipment"){
			var x = {};
			var equip_values = ["equipmentName","description","equipmentOEMNumber","purchaseDate","effectiveDate","expiryDate","manufacturer"];
			x.equip = {};
			$.each(data[0].map(function(val){return val.data}),function(ind,val){
				if(data[0][ind]['type'] == 'dateTimePicker'){
					x.equip[equip_values[ind]] = moment($('#'+data[0][ind]['id']+' > input').val(),'DD/MM/YYYY').utc().format('YYYY-MM-DD HH:mm:ss.SSS');
				}else if(data[0][ind]['type'] == 'map'){
					//if(data[index].type == "map"){
						x.equip["latitude"] = parseFloat(val[0]);
						x.equip["longitude"] = parseFloat(val[1]);
					//}
				}else{
					x.equip[equip_values[ind]] = val;
				}
			});
			//x.equipParam = data[1];
			x.sensorEquipment = data[1];//.map(function(val){return val.value});

			console.log(x);

			var q = $q.defer();

			this.getTheJson(type,x).then(function(data){
				q.resolve(data);
			},function(err){
				q.reject({ErrorMessage: 'Sorry!'});
			});

			return q.promise;

		}else if(type == "sensor"){
			var x = {};
			var sensor_values = ["sensorMac","sensorName","sensorDesc","manufacturerId"];
			x.sensor = {};
			console.log(data);
			$.each(data[0].map(function(val){return val.data}),function(ind,val){
				if(data[0][ind]['type'] == 'dateTimePicker'){
					x.sensor[sensor_values[ind]] = moment($('#'+data[0][ind]['id']+' > input').val(),'DD/MM/YYYY').utc().format('YYYY-MM-DD HH:mm:ss.SSS');
				}else{
					x.sensor[sensor_values[ind]] = val;
				}
			});
			
			//x.attrId = data[1];
			x.specs = [];

			var keyList = Object.keys(data[1][0]);
			
			$.each(data[1],function(index,value){
				var obj = {};
				$.each(keyList,function(ind,val){
					if(val == "name"){
						obj["attrId"] = value[val];	
					}else{
						obj[val] = value[val];
					}
				});
				x.specs.push(obj);
			});
			
			var q = $q.defer();

			this.getTheJson(type,x).then(function(data){
				q.resolve(data);
			},function(err){
				q.reject({ErrorMessage: 'Sorry!'});
			});

			return q.promise;
		}
	}

	this.editCollapsibleTemplatedData = function(data,type){
		if(type=="equipment"){
			var x = {};
			var equip_values = ["equipmentName","description","equipmentOEMNumber","purchaseDate","effectiveDate","expiryDate","manufacturer"];
			x.equip = {};
			$.each(data[0].map(function(val){return val.data}),function(ind,val){
				if(data[0][ind]['type'] == 'dateTimePicker'){
					x.equip[equip_values[ind]] = moment($('#'+data[0][ind]['id']+' > input').val(),'DD/MM/YYYY').utc().format('YYYY-MM-DD HH:mm:ss.SSS');
				}else if(data[0][ind]['type'] == 'map'){
					//if(data[index].type == "map"){
						x.equip["latitude"] = parseFloat(val[0]);
						x.equip["longitude"] = parseFloat(val[1]);
					//}
				}else{
					x.equip[equip_values[ind]] = val;
				}
			});
			//x.equipParam = data[1];
			x.sensorEquipment = data[1];//.map(function(val){return val.value});
			x.equip.equipmentId = data[2];
			
			console.log(x);

			var q = $q.defer();

			this.editTheJson(type,x).then(function(data){
				q.resolve(data);
			},function(err){
				q.reject({ErrorMessage: 'Sorry, request could not be processed!'});
			});

			return q.promise;

		}else if(type == "sensor"){
			var x = {};
			var sensor_values = ["sensorMac","sensorName","sensorDesc","manufacturerId"];
			x.sensor = {};
			
			$.each(data[0].map(function(val){return val.data}),function(ind,val){
				if(data[0][ind]['type'] == 'dateTimePicker'){
					x.sensor[sensor_values[ind]] = moment($('#'+data[0][ind]['id']+' > input').val(),'DD/MM/YYYY').utc().format('YYYY-MM-DD HH:mm:ss.SSS');
				}else{
					x.sensor[sensor_values[ind]] = val;
				}
			});
			
			//x.attrId = data[1];
			x.specs = [];

			var keyList = Object.keys(data[1][0]);

			$.each(data[1],function(index,value){
				var obj = {};
				$.each(keyList,function(ind,val){
					
						obj[val] = value[val];
					
				});
				x.specs.push(obj);
			});
			
			var q = $q.defer();

			this.editTheJson(type,x).then(function(data){
				q.resolve(data);
			},function(err){
				q.reject({ErrorMessage: 'Sorry, could not complete the request!'});
			});

			return q.promise;
		}
	}

	this.initiateCollapsibles = function(val){
		$('.'+val+' > .dropDownHeader').click(function(event){
			$('.'+val+' > .dropDownHeader').removeClass('active');
			var x = $(this).next('.dropDownList');
			$('.'+val).find('.dropDownList').slideUp('slow');
			if(!x.is(':visible')){
				$(this).addClass('active');
				x.slideToggle('slow');
			}
		});
	}

	this.getEquipmentManualName = function(id){
		var q = $q.defer();
		$http.get("/getEquipmentManualName",{params: {id: id}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	}

	this.getAllRoles = function(){
		var q = $q.defer();
		$http.get("/getAllRoles").then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	}

	this.authenticateUser = function(username,password,role){
		var q = $q.defer();
		$http.get("/authenticateUser",{params: {username: username,password: password,role: role}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch data!"})
		});
		return q.promise;
	}

	this.getTheJson = function(type,obj){
		var q = $q.defer();
		$http.get("/getTheJsonData?type="+type+"&value="+JSON.stringify(obj)).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
		});

		return q.promise;
	}

	this.editTheJson = function(type,obj){
		var q = $q.defer();
		$http.get("/editTheJsonData?type="+type+"&value="+JSON.stringify(obj)).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
		});
		return q.promise;
	}

	this.deleteTheJson = function(type,obj){
		var q = $q.defer();
		$http.get("/deleteTheJsonData?type="+type+"&value="+JSON.stringify(obj)).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
		});
		return q.promise;
	}

	this.getUserMasterData=function(type,assetId,areaId,rigId,equipType){
		var q=$q.defer();
		$http.get("/getUserMasterData",{params:{'type':type,'assetId':assetId,'areaId':areaId,'rigId':rigId,'equipType':equipType}}).then(function(data){
			q.resolve(data.data);
			//console.log(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
		});
		return q.promise;
	}
	this.getUserRoles=function(){
		var q=$q.defer();
		$http.get("/getConfiguratorDropDownMenu",{params: {type: 'userMasterData'}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
		});
		return q.promise;
	}

	this.getAvailableParameters=function(type){
		var q=$q.defer();
		$http.get("/getAvailableParameters",{params: {type: type}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
		});
		return q.promise;
	}

	// to get sensor list

	this.getSensorList=function(type){
		var q=$q.defer();
		$http.get("/getSensorList",{params: {type: type}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
		});
		return q.promise;
	}
	this.showError = function(val){
		$('.'+val+'Box').slideDown(200,function(){
			setTimeout(function(){
				$('.'+val+'Box').slideUp(200);
			},1000)
		});
	}

	this.updateStatus = function(data){
		var q=$q.defer();
		$http.get("/updateEquipmentStatus",{params: {data: data}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
		});
		return q.promise;
	}

	this.getEquipmentState = function(id){
		var q=$q.defer();
		$http.get("/getEquipmentState",{params: {id: id}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry, could not fetch the json!"});
		});
		return q.promise;
	}

	this.capitalizeFirstLetter = function(string) {
		if(string!=null && string !=undefined && string!="")
			return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
		return string;
	}

	this.getEquipmentProvisionData = function(id){
		var q=$q.defer();
		$http.get("/getEquipmentProvisionData",{params: {id: id}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
		});
		return q.promise;
	}
	
	this.getWellAttributes = function(id){
		var q=$q.defer();
		$http.get("/getWellAttributes",{params: {id: id}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
		});
		return q.promise;
	}

	this.getBirdEyeViewData = function(type,id){
		var q=$q.defer();
		$http.get("/getBirdEyeViewData",{params: {type: type,id: id}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
		});
		return q.promise;
	}

	this.getAllRigsForArea = function(id){
		var q=$q.defer();
		$http.get("/getAllRigsForArea",{params: {id: id}}).then(function(data){
			q.resolve(data.data);
		},function(data){
			q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
		});
		return q.promise;
	}

	this.getEventLogsAdmin = function(id){
        var q=$q.defer();
        $http.get("/getEventLogsAdmin",{params: {id: id}}).then(function(data){
			q.resolve(data.data);
        },function(data){
            q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
        });
        return q.promise;
	}

	this.getEquipmentSensorStats = function(equipmentId,description){
        var q=$q.defer();

        $http.get("/getEquipmentSensorStats",{params: {id: equipmentId,description: description}}).then(function(data){
			q.resolve(data.data);
        },function(data){
            q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
        });
        return q.promise;
	}

	this.getEquipmentSensorData = function(equipmentId){
        var q=$q.defer();
		console.log("In service");
        $http.get("/getEquipmentSensorData",{params: {id: equipmentId}}).then(function(data){
			q.resolve(data.data);
        },function(data){
            q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
        });
        return q.promise;
	}

	this.getSensorHistoricalData = function(sensorId,startDate,endDate){
        var q=$q.defer();
        $http.get("/getSensorHistoricalData",{params: {id: sensorId,startDate: startDate,endDate: endDate}}).then(function(data){
			q.resolve(data.data);
        },function(data){
            q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
        });
        return q.promise;
	}

	this.getTemperatureHistoricalData = function(sensorId,startDate,endDate){
        var q=$q.defer();
        $http.get("/getTemperatureHistoricalData",{params: {id: sensorId,startDate: startDate,endDate: endDate}}).then(function(data){
			q.resolve(data.data);
        },function(data){
            q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
        });
        return q.promise;
	}

	this.getAvailableSensors = function(){
        var q=$q.defer();
        $http.get("/getAvailableSensors").then(function(data){
			q.resolve(data.data);
        },function(data){
            q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
        });
        return q.promise;
	}

	this.disassociateRig = function(equipmentId){
		var q=$q.defer();
        $http.get("/disassociateRig",{params: {id: equipmentId}}).then(function(data){
			q.resolve(data.data);
        },function(data){
            q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
        });
        return q.promise;
	}

	this.getExistingMaintenancesForEquipment = function(equipmentId){
		var q=$q.defer();
        $http.get("/getExistingMaintenancesForEquipment",{params: {id: equipmentId}}).then(function(data){
			q.resolve(data.data);
        },function(data){
            q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
        });
        return q.promise;
	}

	this.getTempAlertState = function(rigEquipmentId,type){
		var q=$q.defer();
        $http.get("/getTempAlertState",{params: {id: rigEquipmentId,type: type}}).then(function(data){
			q.resolve(data.data);
        },function(data){
            q.reject({ErrorMessage : "Sorry,Could not fetch the json!"});
        });
        return q.promise;
	}
});