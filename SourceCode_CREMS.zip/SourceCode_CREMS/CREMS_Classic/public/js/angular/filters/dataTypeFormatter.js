angular.module('myApp').filter('dataTypeFormat',function($filter){
	return function(value,header){
		
		if(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)){
			return $filter('dateFormat')(value);
		}
		else if(header!=undefined && header.toLowerCase()=='status'){
			if(value!=undefined && value!=null && value!=""){
				if(parseInt(value)){
					return parseInt(value)==0?"Inactive":"Active";
				}else
					return value.toString().charAt(0).toUpperCase() + value.toString().slice(1).toLowerCase();
			}
			else
				return value;
		}else if(header!=undefined && header.toLowerCase()=='owner'){
			if(value!=undefined && value!=null && value!=""){
				return $filter('stringEllipse')(value,30);
			}else{
				return value;
			}
		}else
			return value;
	}
})