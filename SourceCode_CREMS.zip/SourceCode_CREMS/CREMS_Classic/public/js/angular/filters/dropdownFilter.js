angular.module("myApp").filter("dropdownFilter",function(){
	return function(input,filterable,inputBasis,filterBasis){
		var arrayList=[];
		try{
            console.log(input);
            console.log(filterable);
            console.log(inputBasis);
            console.log(filterBasis);
		}catch(err){
			console.log(err);
		}
		return arrayList;
	}
});