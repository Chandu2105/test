angular.module('myApp').filter('typeFormat',function(){
	return function(eqtype){
		if(eqtype=="DM"){
			return "D";			
		}else if(eqtype=="WM"){
			return "W";			
		}else if(eqtype=="MM"){
			return "M";
		}else if(eqtype=="QM"){
			return "Q";
		}else if(eqtype=="HFM"){
			return "HY";
		}else if(eqtype=="YM"){
			return "Y";
		}	
	}
});