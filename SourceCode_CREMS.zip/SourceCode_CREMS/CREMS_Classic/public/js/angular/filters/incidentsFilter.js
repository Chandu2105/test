angular.module("myApp").filter("incidentsFilter",function(){
	return function(totalData,iArea,iAsset,iRig,iModel,iAssign,iStatus){
		  var data = [];
		  if(iArea==""&&iRig==""&&iAsset==""&&iModel==""&&iAssign==""&&iStatus==""){
			 data=totalData;
		  }
		 else{

			 var r=totalData;
			 var s=[];

			 if(iArea!=""){	
				 s=[];
				 $.each(r,function(index,value){									 
					 if(value.PREFERRED_NAME.toLowerCase()==iArea.toLowerCase()){
						 s.push(value);
					 }
				 });
				 r=s;
			 }
			 console.log(r);
			 if(iRig!=""){
				 s=[];
				 $.each(r,function(index,value){
					 if(value.RIG_NAME.toLowerCase()==iRig.toLowerCase()){
						 s.push(value);
					 }
				 });
				 r=s;
			 }
			 //console.log(r);
			 //Asset means equipment type: genset, mud pump, etc.
			 if(iAsset!=""){
				 s=[];
				 $.each(r,function(index,value){
					 if(value.DESCRIPTION.toLowerCase()==iAsset.toLowerCase()){
						 s.push(value);
					 }
				 });
				 r=s;
			 }
			 //console.log(r);
			 if(iModel!=""){
				 s=[];
				 $.each(r,function(index,value){
					 if(value.EQUIPMENT_NAME==iModel){
						 s.push(value);
					 }
				 });
				 r=s;
			 }
			 //console.log(r);
			  if(iAssign!="" && iAssign != " "){
				 s=[];
				 var user = iAssign.split(" ");
				 $.each(r,function(index,value){
					 if(value.USER_FIRST_NAME==user[0] && value.USER_LAST_NAME==user[1]){
						 s.push(value);
					 }
				 });
				 r=s;
			 }
			//console.log(r);
			  if(iStatus!=""){
				  s=[];
				 $.each(r,function(index,value){
					 if(value.INCIDENT_STATUS==parseInt(iStatus)){
						 s.push(value);
					 }
				 });
			 }
			 
			 data = s;
		 }
		 return data;
	}
});