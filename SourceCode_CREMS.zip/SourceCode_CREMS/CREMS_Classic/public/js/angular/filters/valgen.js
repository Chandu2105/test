angular.module('myApp').filter('valgen',function(){
	return function(val,arr,paramToCheck,paramToGet){
		var s = "";
		if(arr!=undefined && arr!=null && arr.length!=0){
			var t = [];
			t = arr.filter(function(v){
				return v[paramToCheck] == (/^\d+$/g.test(val)?parseInt(val):val);
			});

			if(t.length > 0){
				s = t[0][paramToGet];
			}else{
				s = "";
			}
		}else{
			return val;
		}
		return s!=""?s:"No Unit";
	}
})