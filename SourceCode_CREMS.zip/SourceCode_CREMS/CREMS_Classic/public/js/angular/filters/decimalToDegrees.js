angular.module('myApp').filter('decimalToDegrees',function(){
    return function(input,checker){
        if(isNaN(input)){
            return input;
        }else if(checker.toLowerCase().indexOf('latitude') > -1 || checker.toLowerCase().indexOf('longitude') > -1){
            var x = input;
            var degrees = Math.floor(x);
            var minutes = (x - Math.floor(x)) * 60;
            var seconds = Math.floor((minutes - Math.floor(minutes)) * 60);
            minutes = Math.floor(minutes);

            return degrees+"° "+minutes+"' "+seconds+"\"";
        }else{
            return input;
        }
    }
})