angular.module("myApp").filter("areaFilter",function(){
	return function(totalData,input){
		var arrayList=[];
		try{
			var str = new RegExp('^'+input,"i");
			if(input!=null && input!=undefined && input!=""){
				$.each(totalData,function(index,value){
					if(str.test(value.item)){
						arrayList.push(value);
					}
				});
			}
		}catch(err){
			console.log(err);
		}
		return arrayList;
	}
});