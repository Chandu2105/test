angular.module('myApp').filter('dateFormat',function(){
	return function(value,option){
		if(value!='' && value!=null && value!=undefined && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)){
			if(option == 'date')
				return moment(value).format('DD/MM/YYYY');
			return moment(value).format('DD/MM/YYYY HH:mm');
		}
		else
			return '-';
	}
});