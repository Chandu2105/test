angular.module('myApp').filter('stringEllipse',function(){
	return function(value,length){
		var ellipsesValue="";
		if(value!=null && value!=undefined && value.length>length){
			ellipsesValue=value.substring(0,length)+"...";
			return ellipsesValue;
		}
		return value;
	}
});