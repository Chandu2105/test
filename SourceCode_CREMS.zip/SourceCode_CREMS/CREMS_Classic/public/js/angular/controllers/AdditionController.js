angular.module('myApp').controller('AdditionController',function($scope,$rootScope,MainService,$state){
	$scope.chartParams = {
		title: ''
	}


	$scope.currentConfig = "";
	$scope.pageTitle = "";
	$scope.headers = [];
	$scope.tableData = [];
	$scope.pageTable = [];

	var type = "area";

	$scope.setEquipmentState = function(state){
		$scope.equipmentState = state;
	}
	
	$scope.getEquipmentState = function(state){
		return $scope.equipmentState;
	}

	$scope.getData = function(type){
		if($scope.equipmentState == undefined || $scope.equipmentState == null){
			$scope.equipmentState = 'add';
		}
		$scope.chartParams.title = type+" List";
		$scope.pageTitle = type+" Master";
		$scope.tableData = [];
		MainService.getConfiguratorTables(type,'').then(function(data){
			
			if(type == 'user'){
				$scope.tableData = [];
				var ids = []

				$.each(data,function(index,value){
					if($.inArray( value.Id, ids ) == -1){
						ids.push(value.Id);
					}
				})

				var dataBots = [];
				if(data.constructor === Array && data.length > 0){
					$.each(ids,function(index,value){
						dataBots.push(data.filter(function(v){
							return v.Id == value;
						}).reduce(function(p,n){
							var c = p;
							c.Owner = p.Owner+','+n.Owner; 
							return c;
						}))
					})
					
					$scope.tableData = dataBots;
				}
			}else{
				$scope.tableData = data;
			}
			
			$scope.headers=[];
			if($scope.tableData.length!=0 && $scope.tableData.constructor===Array){

				$scope.headers = Object.keys($scope.tableData[0]);
				$scope.headers = $scope.headers.filter(function(data){return !(/Id/i).test(data)});
				$scope.headers.push('Actions');
				switch(type){
					case 'equipment':
						$.each($scope.tableData,function(index,val){
							var x = [];
							x.push({
								value: "add",
								title: 'Install',
								disabled: val['Equip Status Id']<100 || val['Equip Status Id'] == 104
							});
							x.push({
								value: "edit",
								title: 'Edit',
								disabled: val['Equip Status Id']==104
							});
							x.push({
								value: "delete",
								title: 'Delete',
								disabled : val['Equip Status Id'] == 104
							});
							x.push({
								value: "deactivate",
								title: val['Equip Status Id'] != 104?'Activate':'Deactivate',
								disabled: val['Equip Status Id']<101
							});
							x.push({
								value: "download",
								title: 'download',
								disabled: val['Equip Status Id']<101
							});

							val['actions'] = x;
						})
						break;
					case 'user':
						$.each($scope.tableData,function(index,val){
							var x = [];
							x.push({
								value: "edit",
								title: 'Edit'
							});
							x.push({
								value: "delete",
								title: 'Delete'
							});
							val['actions'] = x;

							if(val.Role == 'Administrator'){
								val['actions'][0]['disabled'] = true;
								val['actions'][1]['disabled'] = true;
							}

						})
						break;
					case 'rig':
					case 'area':
					case 'asset':
					case 'well':
					
					case 'sensor':
					default:
						var x = [];
						x.push({
							value: "edit",
							title: 'Edit'
						});
						x.push({
							value: "delete",
							title: 'Delete'
						});
						$.each($scope.tableData,function(index,val){
							val['actions'] = x;
						})
						break;
				}
			}
		},function(data){
			
		})
	}

	$scope.performAction = function(action,rowVal){
		$state.equipID = rowVal;
		$scope.currentRow = rowVal;
		$scope.tempRigId = undefined;

		//If one is in equipment master
		if($scope.currentConfig == 'equipment'){
			//If one tries to install an equipment
			if(action.value=='add' && !action.disabled){
				$scope.equipmentState = 'add';
				$scope.equipmentModalHeader = 'Install Equipment';
				$scope.listOfDropdowns = [{
					data: null,
					options: [],
					header: 'Choose a Rig',
					disabled: false
				}];

				MainService.getConfiguratorTables('rig').then(function(data){
					$scope.listOfDropdowns[0].options = MainService.getRefinedDropDown(data);
				},function(data){
					
				});


				MainService.getEquipmentProvisionData(rowVal.Id).then(function(data){
					if(data!=undefined && data!=null && data.constructor == Array && data.length!=0){
						$scope.listOfDropdowns[0].data = data[0].RIG_ID; 
						$scope.tempRigId =  data[0].RIG_ID;
					}else{
						$scope.listOfDropdowns[0].data = "";
						$scope.tempRigId = "";
					}
				},function(data){
					$scope.listOfDropdowns[0].data = "";
					$scope.tempRigId = "";
				})

				$scope.saveAdd = true;

				$scope.$watch('listOfDropdowns[0].data',function(newVal,oldVal){
					if(action.value=='add' && !action.disabled){
						if(newVal!=null && newVal != undefined && newVal!=""){
							$scope.saveAdd = false;
						}else{
							$scope.saveAdd = true;
						}
					}
				})				

				$('#equipmentModal').modal('show');
			}//If one wants to deactivate an equipment
			else if(action.value=='deactivate' && !action.disabled){
				var m = "";
                var x = {};
                x["equipmentId"] = $scope.currentRow.Id;
                x["equipmentName"] = $scope.currentRow.Name;

                if(rowVal['Equip Status Id'] == 104){
                    x["status"] = 103;
                    m = "deactivated";
                    action.disabled = true;
                }else if(rowVal['Equip Status Id'] == 103 || rowVal['Equip Status Id'] == 102 || rowVal['Equip Status Id'] == 101){
                    x["status"] = 104;
                    m = "activated";
                }
				
                MainService.updateStatus(x).then(function(data){
                    if(data !== Object(data) && data.indexOf("Done") > -1){
                        $scope.$emit('popup','Equipment '+$scope.currentRow.Name+" has been "+m,'info');
						$scope.equipmentState = 'add';
                        $scope.getData($scope.currentConfig);
                    }else{
						$scope.$emit('popup',data,'error');
					}
				},function(data){
					$scope.$emit('popup',data.ErrorMessage,'error');
				})
			}
		}

		//If one wants to edit any of the configurators
		if(action.value=='edit' && !action.disabled){
			$scope.equipmentState = 'edit';
			console.log("Editing main...");
			console.log($scope.equipmentState);
			$scope.$broadcast('editValue',rowVal,$scope.currentConfig);
		}

		//If one wants to download the configurators
		if(action.value=='download' && !action.disabled){
			$scope.equipmentState = 'download';
			var equipmentID = $state.equipID.Id;
			MainService.downloadEquipmentConfig(equipmentID).then(function(data){
				console.log("data ---- ",data);

					if(!data) {
						console.error('Console.save: No data')
						return;
					}			
					var filename = 'equipmentConfig.json';
					var blob = new Blob([JSON.stringify(data)], {type: 'text/plain'}),
						e    = document.createEvent('MouseEvents'),
						a    = document.createElement('a')
			
			  if (window.navigator && window.navigator.msSaveOrOpenBlob) {
				  window.navigator.msSaveOrOpenBlob(blob, filename);
			  }
			  else{
				  var e = document.createEvent('MouseEvents'),
					  a = document.createElement('a');
			
				  a.download = filename;
				  a.href = window.URL.createObjectURL(blob);
				  a.dataset.downloadurl = ['text/plain', a.download, a.href].join(':');
				  e.initEvent('click', true, false, window,
					  0, 0, 0, 0, 0, false, false, false, false, 0, null);
				  a.dispatchEvent(e);
			  }

			},function(data){
					$scope.$emit('popup',data.ErrorMessage,'error');
				})
		}
		

		//If one wants to delete any of the configurators
		if(action.value=='delete' && !action.disabled){
			
			$scope.equipmentState = 'delete';
			$scope.equipmentModalHeader = 'Delete Confirmation';

			$('#equipmentModal').modal('show');

			$scope.confirmDelete = function(bool){
				if(bool){
					var id1 = "";
					switch($scope.currentConfig){
						case "well":
							id1 = "UWI";
							break;
						case "sensor":
							id1 = "sensorMac";
							break;
						default:
							if($scope.currentConfig=='Maintenance'){
								id1 = "equipAct"+"Id";
								$scope.currentConfig='activity';
							}
							else{
								id1 = $scope.currentConfig+"Id";
							}
							break;
					}

					var id2 = $scope.currentConfig+"Name";
					var orb = {};
					
					if($scope.currentConfig == 'sensor'){
						orb["sensor"] = {};
						orb["sensor"][id1] = rowVal.Id;
						orb["sensor"][id2] = rowVal.Name;
					}
					else if($scope.currentConfig == 'well'){
						orb[id1] = rowVal.UWI;
						orb[id2] = rowVal.Name;
					}
					else{
						orb[id1] = rowVal.Id;
						orb[id2] = rowVal.Name;
					}

					MainService.deleteTheJson($scope.currentConfig,orb).then(function(data){
						
						if(data !== Object(data) && data.indexOf('Done') > -1){
							if($scope.currentConfig=='activity'){
								$scope.currentConfig="Maintenance";
								rowVal.Name="";
							}
							$scope.$emit('popup',MainService.capitalizeFirstLetter($scope.currentConfig)+" "+rowVal.Name+' has been successfully deleted!','info');

							$scope.getData($scope.currentConfig);

							if($scope.currentConfig.toLowerCase() == 'well' || $scope.currentConfig.toLowerCase() == 'sensor'){
								$scope.$broadcast('removePrimaryKey',$scope.currentConfig.toLowerCase());
							}else if($scope.currentConfig.toLowerCase() == 'equipment'){
								$scope.$broadcast('repopulateSensors','');
							}
						}else{
							$scope.$emit('popup',data,'error');
						}
					},function(data){
			
						$scope.$emit('popup',data.ErrorMessage,'error');
					})
				}
				$('#equipmentModal').modal('hide');
			}
		}
	}

	$scope.saveInstallDetails = function(){
		if($scope.equipmentState=='add'){
			if($scope.listOfDropdowns.filter(function(v){
				return v.data == null || v.data == "" || v.data == undefined;
			}).length == 0){
				if($scope.tempRigId == $scope.listOfDropdowns[0].data){
					$scope.$emit('popup','Equipment is already installed in this rig!','info');
					console.log('Equipment already installed in the same rig, not installing again...');
				}else{
					var x = {};
					x["equipmentId"] = $scope.currentRow.Id;
					x["equipmentName"] = $scope.currentRow.Name;
					x["status"] = 101;
					x["rigId"]= $scope.listOfDropdowns[0].data
					
					MainService.updateStatus(x).then(function(data){
						if(data !== Object(data) && data.indexOf("Done") > -1){
							$scope.$emit('popup','Equipment '+$scope.currentRow.Name+" has been installed.",'info');
							$scope.getData($scope.currentConfig);
						}else{
							$scope.$emit('popup',data,'error');
						}
					},function(data){
						$scope.$emit('popup',data,'error');
					})
				}
				$('#equipmentModal').modal('hide');
			}
		}
	}

	$scope.disassociateRig = function(){
		if($scope.currentRow["Equip Status Id"] != 100){
			MainService.disassociateRig($scope.currentRow.Id).then(function(data){
				if(data.indexOf('Done') > -1){
					$scope.listOfDropdowns[0].data = "";
					$scope.tempRigId = "";

					$scope.getData($scope.currentConfig);
					$scope.$emit('popup',"Rig deassociation was successful.","error");
				}else{
					$scope.$emit('popup',data,"error");
				}
			},function(err){
				$scope.$emit('popup',err,"error");
			})
		}else{
			$scope.$emit('popup',"Equipment is not associated with any rig.","error");
		}
	}
	
	$scope.getHeaders = function(){
		return $scope.headers;
	}

	$scope.$on('setCurrentConfig',function(event,type){
		$scope.currentConfig = type;
		
		$scope.getData(type);
	})

	refreshMasterInterval = setInterval(function(){
		$scope.getData($scope.currentConfig);
	},30 * 1000)

	intervalsList.push(refreshMasterInterval);

	MainService.activateHeaderTab("Configurator");

}).controller('AreaMasterController',function($scope,MainService){
	$scope.chartParams = {
		title: 'Add/Edit Area'
	}

	$scope.$emit('setCurrentConfig','area');
	$scope.$emit('setConfigView','areamaster');
	
	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.addition.areamaster',
		params: null
	}))

	$scope.resetData = function(){
		$.each($scope.listOfValues,function(index,value){
			value.data = null;
			if(value.type == 'dateTimePicker'){
				$('#'+value.id+' > input').val(undefined);
			}

			if(value.type == 'map'){
				value.data = ["",""];
			}
		});

		//$scope.equipmentState = "add";
		$scope.setEquipmentState('add');
	}
	$scope.mapid = "Bangalore";
	$scope.latitude = '';
	$scope.longitude = '';

	$scope.listOfValues = [];
	$scope.types = [1,3];
	$scope.listOfHeaders = ["Area Name","Asset"];
	$scope.editId = 	null;

	$.each($scope.listOfHeaders,function(index,value){
		$scope.listOfValues.push(MainService.getObjectForType(value,$scope.types[index]));
	});

	MainService.getConfiguratorDropDown('Asset').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Asset") > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
		
	});

	$scope.$on('editValue',function(event,id,type){
		if(type=='area'){
			$scope.editId = id.Id;
			MainService.editConfiguratorTables(type,id.Id).then(function(data){
				$.each($scope.listOfHeaders,function(index,value){
					if($scope.types[index] == 2){
						$scope.listOfValues[index].data = moment(data[0][value]).format("DD/MM/YYYY");
						$("#"+$scope.listOfValues[index].id+" > input").val(moment(data[0][value]).format("DD/MM/YYYY"));
					}
					else if($scope.types[index]==4){
						$scope.listOfValues[index].data = [null,null];
						$scope.listOfValues[index].data[0] = data[0]["Latitude"];
						$scope.listOfValues[index].data[1] = data[0]["Longitude"];
					}
					else{
						$scope.listOfValues[index].data = data[0][value];
					}
				})
			},function(err){
		
			})
		}
	
	});

	

	$scope.editId = null;
	$scope.addNewValue = function(){
		$.each($scope.listOfHeaders,function(index,value){
			if($scope.types[index] == 2){
				var c = $("#"+$scope.listOfValues[index].id+" > input").val();
				$scope.listOfValues[index].data = moment($("#"+$scope.listOfValues[index].id+" > input").val()).format("DD/MM/YYYY");
				if($scope.listOfValues[index].data.toLowerCase().indexOf("invalid") > -1)
					$scope.listOfValues[index].data = c;
			}
			
		});
		var fg = $scope.listOfValues.filter(function(v){
			if(v.data == null || v.data == "" || v.data == undefined){
				return true;
			}else if(v.type == 'map'){
	
				return v.data.length != 2 || v.data.filter(function(f){return f == null || f == "" || f == undefined}).length != 0
			}
		});
		
		if(fg.length == 0){
			if($scope.getEquipmentState() == 'edit' && $scope.editId!=null){
				MainService.storeEditData($scope.listOfValues,"area",$scope.editId).then(function(data){	
					$scope.editId = null;		
					if(data!=null && data!=undefined && data !== Object(data) &&  data.indexOf('Done') > -1){
						$scope.$emit('popup','Area '+$scope.listOfValues[0].data+' has been edited.',"info");
						$.each($scope.listOfValues,function(i,v){
							if(v.type == 'map'){
								v.data = [null,null];
							}
							else{							
								v.data = null;
							}
						})
						$scope.$emit('setCurrentConfig','area');
					}else{
						$scope.$emit('popup',data,"error");
					}
				},function(data){
	
					$scope.$emit('popup',data,"error");
				});
			}else{
				MainService.storeAddData($scope.listOfValues,"area").then(function(data){			
					if(data!=null && data!=undefined && data !== Object(data) && data.indexOf('Done') > -1){
						$scope.$emit('popup','Area '+$scope.listOfValues[0].data+' has been added.',"info");
						$.each($scope.listOfValues,function(i,v){
							if(v.type == 'map'){
								v.data = [null,null];
							}
							else{							
								v.data = null;
							}
						})
						$scope.$emit('setCurrentConfig','area');
					}else{
						$scope.$emit('popup',data,"error");
					}
				},function(data){
					$scope.$emit('popup',data,"error");
				});
			}
		}else{
			$scope.$emit('popup','All fields are mandatory!',"error");
		}
	}
}).controller('RigMasterController',function($scope,$timeout,MainService){
	$scope.chartParams = {
		title: 'Add/Edit Rig'
	}
	$scope.$emit('setCurrentConfig','rig');
	$scope.$emit('setConfigView','rigmaster');
	
	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.addition.rigmaster',
		params: null
	}))

	$scope.resetData = function(){
		$.each($scope.listOfValues,function(index,value){
			value.data = null;
			if(value.type == 'dateTimePicker'){
				$('#'+value.id+' > input').val(undefined);
			}

			if(value.type == 'map'){
				value.data = ["",""];
			}
		});

		//$scope.equipmentState = "add";
		$scope.setEquipmentState('add');
	}

	$scope.listOfValues = [];

	//1-input box,2-date picker,3-drop box,4-lat/long.,5-combobox
	$scope.types = [1,2,2,2,2,5,3,5,3,5,3,3,5,3,3,3,1,3,3,3,3,5,1,3];
	$scope.listOfHeaders = ["Rig Name","Commission Date","Decommission Date","Effective Date",
	"Expiry Date","Hook Load Capacity","Hook Load Capacity UOM","KB Ground Distance",
	"KB Ground Distance UOM","Mast Height","Mast Height UOM","Mast Type","Max Depth",
	"Max Depth UOM","Operator","Owner","Remark","Rig Category","Rig Class","Rig Code",
	"Rig Type","Water Depth","Water Depth Datum","Water Depth UOM"];

	$scope.uomType = {
		'6': 'mass',
		'8': 'length',
		'10': 'length',
		'13': 'length',
		'23': 'length'
	}

	$.each($scope.listOfHeaders,function(index,value){
		$scope.listOfValues.push(MainService.getObjectForType(value,$scope.types[index],$scope.uomType[index]));
	});

	MainService.getConfiguratorDropDown('Operator').then(function(data){
		var changeRequired = ["Operator","Owner"];
		$.each(changeRequired,function(index,value){
			$scope.listOfValues[$scope.listOfHeaders.indexOf(value)].options = MainService.getRefinedDropDown(data);
		});
	},function(err){
	
	});

	// MainService.getConfiguratorDropDown('UOM').then(function(data){
	// 	$.each($scope.listOfHeaders,function(index,value){
	// 		if(value.indexOf("UOM") > -1){
	// 			$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
	// 		}
	// 	});
	// },function(err){
	
	// });

	MainService.getConfiguratorDropDown('UOM').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("UOM") > -1){
				var selectiveUoms = data.filter(function(v,i){
					return $scope.listOfValues[index].uomType != undefined && v.UOM_TYPE == $scope.listOfValues[index].uomType;
				})
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(selectiveUoms);
			}
		});
	},function(err){
	
	});

	MainService.getConfiguratorDropDown('Rig Category').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Rig Category") > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});

	MainService.getConfiguratorDropDown('Mast Type').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Mast Type")  > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});

	MainService.getConfiguratorDropDown('Rig Class').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Rig Class") > -1) {
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});

	MainService.getConfiguratorDropDown('Rig Code').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Rig Code") > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});

	MainService.getConfiguratorDropDown('Rig Type').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Rig Type") > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});

	$scope.editId = null;

	$scope.addNewValue = function(){
		$.each($scope.listOfHeaders,function(index,value){
			if($scope.types[index] == 2){
				var c = $("#"+$scope.listOfValues[index].id+" > input").val();
				$scope.listOfValues[index].data = moment($("#"+$scope.listOfValues[index].id+" > input").val()).format("DD/MM/YYYY");
				if($scope.listOfValues[index].data.toLowerCase().indexOf("invalid") > -1)
					$scope.listOfValues[index].data = c;
			}
		});
		if($scope.listOfValues.filter(function(v){
			if(v.data == null || v.data == "" || v.data == undefined){
				return true;
			}else if(v.type == 'map'){
				return v.data.length != 2 || v.data.filter(function(f){return f == null || f == "" || f == undefined}).length != 0
			}
		}).length == 0){
			if($scope.getEquipmentState() == 'edit' && $scope.editId!=null){
				MainService.storeEditData($scope.listOfValues,"rig",$scope.editId).then(function(data){	
					$scope.editId = null;		
					if(data!=null && data!=undefined && data !== Object(data) && data.indexOf('Done') > -1){
						$scope.$emit('popup','Rig '+$scope.listOfValues[0].data+' has been edited.',"info");
						$.each($scope.listOfValues,function(i,v){
							if(v.type == 'map'){
								v.data = [null,null];
							}
							else{							
								v.data = null;
							}
						});
						$scope.$emit('setCurrentConfig','rig');
					}else{
						$scope.$emit('popup',data,"error");
					}
				},function(data){
	
					$scope.$emit('popup',data,"error");
				});
			}else{
				MainService.storeAddData($scope.listOfValues,"rig").then(function(data){			
					if(data!=null && data!=undefined && data !== Object(data) && data.indexOf('Done') > -1){
						$scope.$emit('popup','Rig '+$scope.listOfValues[0].data+' has been added.',"info");
						$.each($scope.listOfValues,function(i,v){
							if(v.type == 'map'){
								v.data = [null,null];
							}
							else{							
								v.data = null;
							}
						});
						$scope.$emit('setCurrentConfig','rig');
					}else{
						$scope.$emit('popup',data,"error");
					}
				},function(data){
					$scope.$emit('popup',data,"error");
				});
			}
		}else{
			$scope.$emit('popup','All fields are mandatory!',"error");
		}
	}
	
	$scope.initializeDateTimePicker = function(id){
		$timeout(function() {
			$("#"+id).datetimepicker({format:'DD/MM/YYYY'});
		}, 1);
	}

	$scope.$on('editValue',function(event,id,type){
		if(type=='rig'){
			$scope.editId = id.Id;
	
			MainService.editConfiguratorTables(type,id.Id).then(function(data){
				$.each($scope.listOfHeaders,function(index,value){
					if($scope.types[index] == 2){
						$scope.listOfValues[index].data = moment(data[0][value]).format("DD/MM/YYYY");
						$("#"+$scope.listOfValues[index].id+" > input").val(moment(data[0][value]).format("DD/MM/YYYY"));
					}
					else if($scope.types[index]==4){
						$scope.listOfValues[index].data = [null,null];
						$scope.listOfValues[index].data[0] = data[0]["Latitude"];
						$scope.listOfValues[index].data[1] = data[0]["Longitude"];
					}
					else{
						if($scope.listOfValues[index].header == "Area"){
	
							setTimeout(function(){$scope.listOfValues[index].data = data[0][value];},1500);
						}
						else{
							$scope.listOfValues[index].data = data[0][value];
						}
						
					}
				})
	
			},function(err){
	
			})
		}
	
	});
	
}).controller('AssetMasterController',function($scope,MainService){
	$scope.chartParams = {
		title: 'Add/Edit Asset'
	}

	$scope.$emit('setCurrentConfig','asset');
	$scope.$emit('setConfigView','assetmaster');
	
	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.addition.assetmaster',
		params: null
	}))

	$scope.resetData = function(){
		$.each($scope.listOfValues,function(index,value){
			value.data = null;
			if(value.type == 'dateTimePicker'){
				$('#'+value.id+' > input').val(undefined);
			}

			if(value.type == 'map'){
				value.data = ["",""];
			}
		});
		//$scope.equipmentState = 'add';
		$scope.setEquipmentState('add');
	}
	$scope.listOfValues = [];
	$scope.types = [1];

	$scope.listOfHeaders = ["Asset Name"];

	$.each($scope.listOfHeaders,function(index,value){
		$scope.listOfValues.push(MainService.getObjectForType(value,$scope.types[index]));
	});

	/*MainService.getConfiguratorDropDown('User Name').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("User Name")){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});*/
	$scope.editId = null;

	$scope.addNewValue = function(){
		$.each($scope.listOfHeaders,function(index,value){
			if($scope.types[index] == 2){
				var c = $("#"+$scope.listOfValues[index].id+" > input").val();
				$scope.listOfValues[index].data = moment($("#"+$scope.listOfValues[index].id+" > input").val()).format("DD/MM/YYYY");
				if($scope.listOfValues[index].data.toLowerCase().indexOf("invalid") > -1)
					$scope.listOfValues[index].data = c;
				//$scope.listOfValues[index].data = moment($("#"+$scope.listOfValues[index].id+" > input").val()).format("DD/MM/YYYY");
			}
		});

		if($scope.listOfValues.filter(function(v){
			if(v.data == null || v.data == "" || v.data == undefined){
				return true;
			}else if(v.type == 'map'){
				return v.data.length != 2 || v.data.filter(function(f){return f == null || f == "" || f == undefined}).length != 0
			}
		}).length == 0){
			if($scope.getEquipmentState() == 'edit' && $scope.editId!=null){
				MainService.storeEditData($scope.listOfValues,"asset",$scope.editId).then(function(data){	
					$scope.editId = null;		
					if(data!=undefined && data!=null && data !== Object(data) && data.indexOf('Done') > -1){
						$scope.$emit('popup','Asset '+$scope.listOfValues[0].data+' has been edited.',"info");
						$.each($scope.listOfValues,function(i,v){
							if(v.type == 'map'){
								v.data = [null,null];
							}
							else{							
								v.data = null;
							}
						});
						$scope.$emit('setCurrentConfig','asset');
					}else{
						$scope.$emit('popup',data,"error");
					}
				},function(data){
	
					$scope.$emit('popup',data,"error");
				});
			}else{
				MainService.storeAddData($scope.listOfValues,"asset").then(function(data){			
					if(data !== Object(data) && data.indexOf('Done') > -1){
						$scope.$emit('popup','Asset '+$scope.listOfValues[0].data+' has been added.',"info");
						$.each($scope.listOfValues,function(i,v){
							if(v.type == 'map'){
								v.data = [null,null];
							}
							else{							
								v.data = null;
							}
						});
						$scope.$emit('setCurrentConfig','asset');
					}else{
						$scope.$emit('popup',data,"error");
					}
				},function(data){
					$scope.$emit('popup',data,"error");
				});
			}
		}else{
			$scope.$emit('popup','All fields are mandatory!',"error");
		}
	}
	
	$scope.$on('editValue',function(event,id,type){
		if(type=='asset'){
			$scope.editId = id.Id;
			MainService.editConfiguratorTables(type,id.Id).then(function(data){
				$.each($scope.listOfHeaders,function(index,value){
					if($scope.types[index] == 2){
						$scope.listOfValues[index].data = data[0][value];
						$("#"+$scope.listOfValues[index].id+" > input").val(moment(data[0][value]).format("DD/MM/YYYY"));
					}
					else{
						$scope.listOfValues[index].data = data[0][value];
					}
				});
			},function(err){
	
			})
		}
	});

	

}).controller("WellMasterController",function($scope,MainService,$timeout){
	$scope.chartParams = {
		title: 'Add/Edit Well'
	}
	$scope.$emit('setConfigView','wellmaster');
	
	$scope.$on('removePrimaryKey',function(event,message){
		if(message == "well"){
			$.each($scope.listOfValues,function(index,value){
				if(/\buwi\b/.test(value.header.toLowerCase()) == true){
					value.data = null;
					return false;
				}
			});
		}
	});
	$scope.resetData = function(){
		$.each($scope.listOfValues,function(index,value){
			// if($scope.equipmentState == 'edit'){
			// 	if(/\buwi\b/.test(value.header.toLowerCase()) == false)
			// 		value.data = null;		
			// }else{
			// 	value.data = null;
			// }
			value.data = null;
			$scope.disableWell = false;

			if(value.type == 'dateTimePicker'){
				$('#'+value.id+' > input').val(undefined);
			}

			if(value.type == 'map'){
				value.data = ["",""];
			}
		});
		//$scope.equipmentState = 'add';
		$scope.setEquipmentState('add');
	}
	$scope.$emit('setCurrentConfig','well');
	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.addition.wellmaster',
		params: null
	}))

	$scope.listOfValues = [];
	//1-input box,2-date picker,3-drop box,4-lat/long.
	$scope.types = [5,1,3,2,2,2,3,3,3,3,3,2,3,5,3,3,1,5,1,1,1,1,2,1,2,5,5,5,5,4];
	$scope.listOfHeaders = ["UWI","Well Name","Well Status","Spud Date","Completion Date","Abandonment Date","Country","Asset","Area","Rig","County","Current Status Date","Depth Datum Type","Depth Datum Elevation","Depth Datum Elevation UOM","Operator","Region","Total Depth","Well Type","Production Method","Reservoir Name","Artificial Lift Type","Artificial Start Date","Current Status","Production Start Date","Target Measured Depth","Target True Vertical Depth","Current Measured Depth","Current True Vertical Depth","Surface Lat/Long"];
	
	$scope.uomType = {
		'14': 'length'
	}

	$.each($scope.listOfHeaders,function(index,value){
		
		$scope.listOfValues.push(MainService.getObjectForType(value,$scope.types[index],$scope.uomType[index]));
	});

	MainService.getConfiguratorDropDown('Well Status').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Well Status") > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});

	MainService.getConfiguratorDropDown('Country').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Country") > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});

	MainService.getConfiguratorDropDown('Area').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Area") > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});

	$scope.$watch('listOfValues[7].data',function(newVal,oldVal){
		var val = $scope.listOfValues[8].data;
		if(newVal != null && newVal !=undefined && newVal != ""){
			MainService.getUserMasterData('area',newVal,'','','').then(function(data){
				if(data!=undefined && data != null && data.constructor == Array && data.length!=0){
					$scope.listOfValues[8].options = MainService.getRefinedDropDown(data);
					$scope.listOfValues[8].options.filter(function(v){return v.value == val}).length == 0?($scope.listOfValues[8].data=null):($scope.listOfValues[8].data = val);
				}
				else{
					$scope.listOfValues[8].options = [];
				}
			},function(err){
	
			});
		}
		else{
			$scope.listOfValues[8].options = [];
			$scope.listOfValues[8].data = null;
		}
	});

	MainService.getConfiguratorDropDown('Rig').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Rig") > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});

	MainService.getConfiguratorDropDown('Asset').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Asset") > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});

	MainService.getConfiguratorDropDown('County').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("County") > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});

	MainService.getConfiguratorDropDown('UOM').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("UOM") > -1){
				var selectiveUoms = data.filter(function(v,i){
					return $scope.listOfValues[index].uomType != undefined && v.UOM_TYPE == $scope.listOfValues[index].uomType;
				})
				
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(selectiveUoms);
			}
		});
	},function(err){
	
	});

	MainService.getConfiguratorDropDown('Depth Datum Type').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Depth Datum Type") > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});

	MainService.getConfiguratorDropDown('Operator').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Operator") > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});

	$scope.initializeDateTimePicker = function(id){
		$timeout(function() {
			$("#"+id).datetimepicker({format:'DD/MM/YYYY'});
		}, 1);
	}
	$scope.addNewValue = function(){
		
		$.each($scope.listOfHeaders,function(index,value){
			if($scope.types[index] == 2){
				var c = $("#"+$scope.listOfValues[index].id+" > input").val();
				$scope.listOfValues[index].data = moment($("#"+$scope.listOfValues[index].id+" > input").val()).format("DD/MM/YYYY");
				if($scope.listOfValues[index].data.toLowerCase().indexOf("invalid") > -1)
					$scope.listOfValues[index].data = c;
				//$scope.listOfValues[index].data = moment($("#"+$scope.listOfValues[index].id+" > input").val()).format("DD/MM/YYYY");
			}
		});
		
		if($scope.listOfValues.filter(function(v){
			if(v.data == null || v.data == "" || v.data == undefined){
				return true;
			}else if(v.type == 'map'){
				return v.data.length != 2 || v.data.filter(function(f){return f == null || f == "" || f == undefined}).length != 0
			}
		}).length == 0){
			if($scope.getEquipmentState() == 'edit' && $scope.editId!=null){
	
				MainService.storeEditData($scope.listOfValues,"well",$scope.editId).then(function(data){	
					$scope.editId = null;		
					if(data !== Object(data) && data.indexOf('Done') > -1){
						$scope.$emit('popup','Well '+$scope.listOfValues[0].data+' has been edited.',"info");
						$.each($scope.listOfValues,function(i,v){
							if(v.type == 'map'){
								v.data = [null,null];
							}
							else{							
								v.data = null;
							}
						});
						$scope.$emit('setCurrentConfig','well');
					}else{
						$scope.$emit('popup',data,"error");
					}
				},function(data){
	
					$scope.$emit('popup',data,"error");
				});
			}else{
				MainService.storeAddData($scope.listOfValues,"well").then(function(data){		
					if(data !== Object(data) && data.indexOf('Done') > -1){
						$scope.$emit('popup','Well '+$scope.listOfValues[0].data+' has been added.',"info");
						$.each($scope.listOfValues,function(i,v){
							if(v.type == 'map'){
								v.data = [null,null];
							}
							else{							
								v.data = null;
							}
						});
						$scope.$emit('setCurrentConfig','well');
					}else{
						$scope.$emit('popup',data,"error");
					}
				},function(data){
					$scope.$emit('popup',data,"error");
				});
			}
		}else{
			$scope.$emit('popup','All fields are mandatory!',"error");
		}
	}

	$scope.$on('editValue',function(event,id,type){
		if(type=='well'){
			$scope.editId = id.UWI;
			$scope.disableWell = true;
			MainService.editConfiguratorTables(type,id.UWI).then(function(data){
				if(data != undefined && data != null && data.constructor === Array && data.length > 0){
					$.each($scope.listOfHeaders,function(index,value){
						if($scope.types[index] == 2){
							$scope.listOfValues[index].data = moment(data[0][value]).format("DD/MM/YYYY");
							$("#"+$scope.listOfValues[index].id+" > input").val(moment(data[0][value]).format("DD/MM/YYYY"));
						}
						else if($scope.types[index]==4){
							$scope.listOfValues[index].data = [null,null];
							$scope.listOfValues[index].data[0] = data[0]["Latitude"];
							$scope.listOfValues[index].data[1] = data[0]["Longitude"];
						}
						else{
							$scope.listOfValues[index].data = data[0][value];
						}
					});

					MainService.getWellAttributes(id.UWI).then(function(data){
						if(data!=undefined && data!=null && data.length!=0){
							$.each($scope.listOfValues,function(i,v){
								$.each(data,function(ind,va){
									if(v.header == va['ATTR_DESC']){
										v.data = va['ATTR_VALUE'];
										return false;
									}
								})
							})
						}
					},function(data){
			
					})
				}
			},function(err){
	
			});
		}
	});
	

}).controller("EquipmentMasterController",function($scope,MainService,$timeout){
	
	$scope.chartParams = {
		title: 'Add/Edit Equipment'
	}
	
	$scope.uploadedFileName = '';
	$scope.sensorList = [];
	$scope.sensorDropDownList = [];
	$scope.sensorToEdit = {};
	$scope.sensorMasterList = [];

	var formData;
	$scope.$emit('setCurrentConfig','equipment');
	$scope.$emit('setConfigView','equipmentmaster');
	
	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.addition.equipmentmaster',
		params: null
	}));
	
	$scope.$on('repopulateSensors',function(event,message){
		MainService.getAvailableSensors().then(function(data){
			$scope.sensorDropDownList = MainService.getRefinedDropDown(data);
		},function(err){
			
		});
	});
	
	$scope.resetData = function(){
		$.each($scope.listOfValues,function(index,value){
			value.data = null;
			if(value.type == 'dateTimePicker'){
				$('#'+value.id+' > input').val(undefined);
			}

			if(value.type == 'map'){
				value.data = ["",""];
			}
		});

		$scope.sensorList = [];
		$scope.uploadedFileName = "No file chosen";
		formData = undefined;
		$scope.manualUploaded = undefined;
		$('#manualUpload').val(null);

		//$scope.equipmentState = "add";
		$scope.setEquipmentState('add');
	}

	MainService.initiateCollapsibles('collapsible');

	$scope.listOfValues = [];
	//1-input box,2-date picker,3-drop box,4-lat/long.
	
	$scope.types = [1,3,1,2,2,2,3,4];
	$scope.listOfHeaders = ["Equipment Name","Description","Equipment OEM Number","Purchase Date","Effective Date","Expiry Date","Manufacturer","Surface Lat/long"];
	$scope.paramList = [];
	$scope.dropdownList = [];
	$scope.sensorList = [];

	$scope.editParam = function(index,array){
		$scope.$broadcast('forceEdit',array[index],index,$scope.sensorMasterList);
	}

	$scope.removeParam = function(index,arrayToRemoveFrom,arrayToAddTo){
		if(arrayToAddTo!=undefined && arrayToAddTo != null){
			arrayToAddTo.push($scope.sensorMasterList.filter(function(d){
				return d.value == arrayToRemoveFrom[index].sensorId;
			})[0]);
		}
		arrayToRemoveFrom.splice(index,1);
	}

	$scope.initializeDateTimePicker = function(id){
		$timeout(function() {
			$("#"+id).datetimepicker({format:'DD/MM/YYYY'});
		}, 1);
	}

	$.each($scope.listOfHeaders,function(index,value){
		$scope.listOfValues.push(MainService.getObjectForType(value,$scope.types[index]));
	});

	//Get list of manufacturers
	MainService.getConfiguratorDropDown('Manufacturer').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Manufacturer") > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
	
	});

	MainService.getConfiguratorTables('sensor','').then(function(data){
		if(data!=undefined && data != null && data.constructor == Array && data.length!=0){
			$scope.sensorMasterList = data.map(function(v){
				return {
					item: v["Sensor Name"],
					value: v.Id
				}
			});
			
		}
	},function(err){
	
	});

	//Get list of equipmentTypes
	$.each($scope.listOfHeaders,function(index,value){
		if(value.indexOf("Description") > -1){
			$scope.listOfValues[index].options = MainService.getDescription();
			return false;
		}
	});

	//Get list of unassociated sensors
	MainService.getAvailableSensors().then(function(data){
		$scope.sensorDropDownList = MainService.getRefinedDropDown(data);
	},function(data){

	});
	
	// $scope.$watch('sensorDropDownList',function(newVal,oldVal){
	// 	console.log(newVal);
	// },true);

	//To get the list of units
	// MainService.getConfiguratorDropDown('UOM').then(function(data){
	// 	$scope.dropdownList[1] = MainService.getRefinedDropDown(data);
	// },function(data){
	
	// });

	//Simulate upload button click
	$scope.uploadFile = function(){
		$('#manualUpload').click();
	}
	
	//To store the uploaded file in a FormData object
	$('#manualUpload').on('change',function(){
		var files = $(this).get(0).files;
		if(files.length>0){
			formData = new FormData();
			for (var i = 0; i < files.length; i++) {
				var file = files[i];
				formData.append('manualUpload', file, file.name);
				console.log(file.name);
			}
		}
	})

	//Set the filename of the uploaded file for display
	$scope.$watch('manualUploaded',function(newVal,oldVal){
		//console.log("Changed file name");
		
		if(newVal!=undefined && newVal != null){
			$scope.uploadedFileName = newVal.name;
		}else{
			$scope.uploadedFileName = 'No file chosen';
		}
		//console.log("New file name is: "+$scope.uploadedFileName);
	})

	//Get and populate the values for editing any value from the master tables
	$scope.$on('editValue',function(event,id,type){
		
		//$scope.equipmentState = 'edit';

		if(type=='equipment'){
			$scope.editId = id.Id;
			MainService.editConfiguratorTables(type,id.Id).then(function(data){
				if(data != undefined && data!=null && data.constructor == Array && data.length!=0){
					$.each($scope.listOfHeaders,function(index,value){
						if($scope.types[index] == 2){
							$scope.listOfValues[index].data = moment(data[0][value]).format("DD/MM/YYYY");
							$("#"+$scope.listOfValues[index].id+" > input").val(moment(data[0][value]).format("DD/MM/YYYY"));
						}
						else if($scope.types[index]==4){
							$scope.listOfValues[index].data = [null,null];
							$scope.listOfValues[index].data[0] = data[0]["Latitude"];
							$scope.listOfValues[index].data[1] = data[0]["Longitude"];
						}else if(index == $scope.listOfHeaders.length - 1){
							$scope.uploadedFileName = data[0]['File'];
						}
						else{
							$scope.listOfValues[index].data = data[0][value];
						}
					})
				}
			},function(err){
	
			})
			
			MainService.editConfiguratorTables('equipmentSensors',id.Id).then(function(data){
				
				if(data!=undefined & data!=null && data.constructor==Array && data.length!=0){
					
					// $scope.sensorList = data.filter(function(vfx){
					// 	return vfx.type == 1
					// });

					// if($scope.sensorList.length == 0){
					// 	$scope.sensorList = data.filter(function(vfx){
					// 		return vfx.type == 0
					// 	});
					// }

					$scope.sensorList = data;

					var s = [];
					$.each($scope.sensorList,function(ind,val){
						$.each($scope.sensorMasterList,function(i,v){
							if(v.value == val.sensorId){
								s.push(i);
								return false;
							}
						})
					})
					// $.each(s,function(i,v){
					// 	$scope.sensorDropDownList.push($scope.sensorMasterList[v]);
					// })
				}else{
					$scope.sensorList = [];
				}
			},function(data){
	
			})

			//To get the uploaded file name
			MainService.getEquipmentManualName(id.Id).then(function(data){
				if(data!=undefined && data!=null && data.constructor == Array && data.length!=0){
					var x = data[0].ARTIFACT_CONTENTS;
					var x = x.substring(x.lastIndexOf('\\')+1,x.length);
					var x = x.substring(0,x.lastIndexOf('_'))+x.substring(x.lastIndexOf('.'),x.length);
					$scope.uploadedFileName = x;
				}else{
					$scope.uploadedFileName = 'No file chosen'
				}
			},function(err){
				console.log(err);
			})

			// MainService.editConfiguratorTables('equip_params',id.Id).then(function(data){
			// 	$scope.paramList = data;
			// 	console.log(data);
			// },function(data){
			// 	console.log(data.ErrorMessage);
			// })
		}
	});

	//$scope.populate = true;

	//To add the sensor to the display list and remove from the global list of available sensors
	// $scope.$on('enteredVal',function(event,data){
	// 	var o = 0;
	// 	$.each($scope.sensorList,function(i,v){
	// 		if(v.value == data){
	// 			o = i;
	// 			return false;
	// 		}
	// 	});

	// 	$scope.addedSensors.push($scope.sensorList[o]);
	// 	$scope.sensorList.splice(o,1);
	// });

	$scope.editId = null;

	$scope.addNewValue = function(){
		//Get the date values directly from the input boxes
		$.each($scope.listOfHeaders,function(index,value){
			if($scope.types[index] == 2){
				var c = $("#"+$scope.listOfValues[index].id+" > input").val();
				$scope.listOfValues[index].data = moment($("#"+$scope.listOfValues[index].id+" > input").val()).format("DD/MM/YYYY");
				if($scope.listOfValues[index].data.toLowerCase().indexOf("invalid") > -1)
					$scope.listOfValues[index].data = c;
				//$scope.listOfValues[index].data = moment($("#"+$scope.listOfValues[index].id+" > input").val()).format("DD/MM/YYYY");
			}
		});

		if($scope.listOfValues.filter(function(v){
			//Checking for any null values in any of the form inputs
			if(v.data == null || v.data == "" || v.data == undefined){
				return true;
			}else if(v.type == 'map'){
				return v.data.length != 2 || v.data.filter(function(f){return f == null || f == "" || f == undefined}).length != 0
			}
		}).length == 0){
			//$scope.resetData();
			//Case when no sensors are added
			// if($scope.sensorList.length == 0){ //$scope.paramList.length == 0 && $scope.addedSensors.length ==0 -- Change if condition if parameters to be added again
			// 	$scope.$emit('popup','Please add at least one sensor!',"error");
			// }else{

				//Uncomment from here
				if($scope.getEquipmentState() == 'edit' && $scope.editId!=null){
					//Editing the equipment
					MainService.editCollapsibleTemplatedData([$scope.listOfValues,$scope.sensorList,$scope.editId],'equipment').then(function(data){
						if(data!=null && data!=undefined && data !== Object(data) && data.indexOf('Done') > -1){
							if(formData!=undefined){
								$.ajax({
									url: '/upload?id='+$scope.editId,
									type: 'POST',
									data: formData,
									processData: false,
									contentType: false,
									success: function(data){
										$scope.editId = null;
										if(data == 'success')
											console.log("File upload successful!");
										else if(data == 'error')
											console.log('File upload failed!');
									}
								});
							}

							$scope.$emit('popup','Equipment '+$scope.listOfValues[0].data+' has been edited.',"info");
							$scope.resetData();
							$scope.$emit('setCurrentConfig','equipment');
						}else{
							$scope.$emit('popup',data,"error");
						}
					},function(data){
						$scope.$emit('popup',data,"error");
					});
				}else{
					//Adding the equipment
					MainService.addCollapsibleTemplatedData([$scope.listOfValues,$scope.sensorList],'equipment').then(function(data){
						if(data!=null && data!=undefined && data !== Object(data) && data.indexOf('Done') > -1){
							$scope.$emit('popup','Equipment '+$scope.listOfValues[0].data+' has been added.',"info");
							if(formData!=undefined){
								$.ajax({
									url: '/upload?id='+(data.split(' : ')[1] || null),
									type: 'POST',
									data: formData,
									processData: false,
									contentType: false,
									success: function(data){
										if(data == 'success'){
											console.log('File upload successful!');
										}else if (data == 'error'){
											console.log('error');
										}
									}
								});
							}
							$scope.resetData();
							$scope.$emit('setCurrentConfig','equipment');
						}else{
							$scope.$emit('popup',data,"error");
						}
					},function(data){
						$scope.$emit('popup',data,"error");
					});
				}
				//Uncomment till here

			//}
		}else{
			$scope.$emit('popup','All fields are mandatory!',"error");
		}
	}

	
}).controller("ActivityMasterController",function($scope,MainService,$timeout){
	$scope.chartParams = {
		title: 'Add/Edit Maintenance'
	}
	$scope.$emit('setConfigView','activitymaster');
	
	$scope.resetData = function(){
		$.each($scope.listOfValues,function(index,value){
			value.data = null;
			if(value.type == 'dateTimePicker'){
				$('#'+value.id+' > input').val(undefined);
			}

			if(value.type == 'map'){
				value.data = ["",""];
			}
		});

		//$scope.equipmentState = "add";
		$scope.setEquipmentState('add');
	}

	$scope.$emit('setCurrentConfig','Maintenance');
	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.addition.activitymaster',
		params: null
	}))

	$scope.assetlist = [];
	$scope.assigneeList=[];

	function initialize(){
	$scope.activity="";
	$scope.activityList=[];
	$scope.listOfValues = [];
	editFlag=0;
	indexValue=-1;
	$scope.asset="";
	$scope.area="";
	$scope.rig="";
	$scope.equipType="";
	$scope.equipment="";
	$scope.type="";
	$scope.startDate="";
	$scope.endDate="";
	$scope.assignee="";
	
	$scope.arealist = [];
	$scope.riglist = [];
	$scope.equipTypelist = [];
	$scope.equipmentlist = [];
	

	assetID="";
	areaID = "";
	rigID = "";
	equipTypeID = "";
	recType="";
	editFlag=0;
	assigneeId="";
	deleteActivity=[];
	editActivity=[];
	editActivityId=-1;
	ActivityListFromDB=[];
	eqpId="";
	eqpActId="";
	flag=0;

	$scope.assetShow=false;
	$scope.areaShow=true;
	$scope.rigShow=true;
	$scope.equipmentTypeShow=true;
	$scope.equipShow=true;
	$scope.typeShow=false;


	$scope.roleWatched=false;
	$scope.assetWatched=false;
	$scope.areaWatched=false;
	$scope.rigWatched=false;
	$scope.eqypTypeWatched=false;

	$scope.showCommentBox=false;
	$scope.showCheckListBox=false;


	}
		
	initialize();


	$scope.typeList=[];
	$scope.startId="startId";
	$scope.endId="endId";
	
	$scope.saveActivity=function(){
		if($scope.activity!=undefined&&$scope.activity.trim().length>0){
			if(editActivityId!=-1){
			$.each(editActivity, function(index,value){
				if(value.id==editActivityId){
					value.desc=$scope.activity;
					editActivityId=-1;
				}
			})
		}
		if(indexValue!=-1){
			$scope.activityList.splice(indexValue,1,$scope.activity);
			indexValue=-1;

		}
		else{
			$scope.activityList.push($scope.activity);
		}
		
		$('#actArea').val("");

		}
	}

	$scope.removeParam=function(index){
		$scope.activityList.splice(index,1);		
	}

	$scope.editSelectedActivity=function(index){
	
		$scope.openActModal=true;
		indexValue=index;
	
	/*if(editFlag==1){
		var activtyNameToEdit=$scope.activityList[index];
		$.each(ActivityListFromDB, function(index,value){
			if(value.name==activtyNameToEdit){
				deleteActivity.push(value.id);
				return false;

			}
		})
	}*/
			$scope.activity=$scope.activityList[index];
	}
	$scope.reset=function(){
		unBindWatchers();
		initialize();
		$($('#'+$scope.startId).children()[0]).val('');
		$($('#'+$scope.endId).children()[0]).val('');
		initialzeWatches();
	}

	$scope.initializeAsset=function(){
		MainService.getUserMasterData('asset').then(function(data){
			$scope.assetlist=data;	
		},function(err){
	
		});

		MainService.getUserMasterData('type').then(function(data){
			$scope.typeList=data;
		},function(err){
	
		});
	}
	
	$scope.initializeAssignee=function(){
		MainService.getUserMasterData('assignee').then(function(data){
			$scope.assigneeList=data;
		},function(err){
			console.log(err.error_message);
		});
	}

	$scope.saveMaint=function(){
		var activityValue=[];
		
		var arr = [];
		var arr = $scope.typeList.filter(function(f){
			return f.id == recType;
		});
		
		if(arr != undefined && arr!= null && arr.length > 0 && arr[0].name.indexOf('Break Down') > -1){
			if($scope.activityComment==undefined||$scope.activityComment.trim().length==0)
			{
				//generate alert
				bootbox.alert('Please add comment');
			}
			else
			{
				var activtyObject={"description":$scope.activityComment};
				activityValue.push(activtyObject);
			}
		}
		else{
			if($scope.activityList.length==0){
			//generate alert
			bootbox.alert('Please add some activity');
			}
			else{
			for(var list in $scope.activityList){
				var activtyObject={"description":$scope.activityList[list]};
				activityValue.push(activtyObject);
			}
				
			}
		}
		
		if(activityValue!=''){
		
		//invoke the service
		if(editFlag==1){
			// invoke update query
			console.log($scope.startDate);
			console.log($scope.endDate);
			
			var obj={
				"equipmentId" :eqpId,
				"type" :recType,
				"equipActId":eqpActId,
				"startDate": moment($scope.startDate).utc().format('YYYY-MM-DD HH:mm:ss'),//$scope.startDate,//moment($scope.startDate).utc().format('YYYY-MM-DD HH:mm:ss') //$($('#'+$scope.startId).children()[0]).val(),
				"endDate": moment($scope.endDate).utc().format('YYYY-MM-DD HH:mm:ss'),//$scope.endDate,//$($('#'+$scope.endId).children()[0]).val(),
				"userId":assigneeId,
				//'deleteActivity':deleteActivity,
				"actList" :activityValue,
				}
	
			MainService.editTheJson("activity",obj).then(function(data){					
				if(data!=undefined && data !== Object(data) && data.indexOf("Done") > -1){
					initialize();
					unBindWatchers();
					initialzeWatches();
					$($('#'+$scope.startId).children()[0]).val('');
					$($('#'+$scope.endId).children()[0]).val('');
					$scope.$emit('setCurrentConfig','Maintenance');
					bootbox.alert("Maintenance details have been edited");
				}					
				else
					bootbox.alert("Sorry, unable to edit maintenance.");
				},function(err){
					console.log(err.error_message);
				});
		}
		else{
			// to add new maintenance, invoke insert query
			var startDate=moment($($('#'+$scope.startId).children()[0]).val()).utc().format("YYYY-MM-DD HH:mm:ss");
			var endDate=moment($($('#'+$scope.endId).children()[0]).val()).utc().format("YYYY-MM-DD HH:mm:ss");
			
			var obj={
				"equipmentId" :eqpId,
				"type" :recType,
				"startDate": moment($scope.startDate).utc().format('YYYY-MM-DD HH:mm:ss'),//$scope.startDate,
				"endDate": moment($scope.endDate).utc().format('YYYY-MM-DD HH:mm:ss'),//$scope.endDate,
				"actList" :activityValue,
				"userId"  :assigneeId
			}

			MainService.getTheJson("activity",obj).then(function(data){	
			if(data!=undefined && data!=null && data !== Object(data) && data.indexOf("Done") > -1){
				bootbox.alert("Maintenance has been scheduled");
				initialize();
				unBindWatchers();
				initialzeWatches();
				$($('#'+$scope.startId).children()[0]).val('');
				$($('#'+$scope.endId).children()[0]).val('');
				$scope.$emit('setCurrentConfig','Maintenance');
			}
			else
				bootbox.alert("Sorry, unable to schedule maintenance.");
			},function(err){
				console.log(err.error_message);
			});
		}		
		
	}
}
	
	function initialzeWatches(){
		//to get all area data
	unBindAssetWatch=$scope.$watch('asset',function(newValue, oldValue){
		var val="";
		$.each($scope.assetlist, function(index,value){
			if(value.ASSET_NAME==newValue){
				val= value.ASSET_ID;
				assetID=val;
				return false;
			}
		})
			$scope.area = "";
			$scope.rig = "";
			$scope.equipType = "";
			$scope.equipment = "";
			$scope.areaShow=true;
			$scope.rigShow=true;
			$scope.equipmentTypeShow=true;
			$scope.equipShow=true;
		if(val!=null && val.length!=0){
			MainService.getUserMasterData('area',val).then(function(data){
			$scope.arealist=data;			
			$scope.areaShow=false;
			$scope.rigShow=true;
			$scope.equipmentTypeShow=true;
			$scope.equipShow=true;
			$scope.assetWatched=true;
			},function(err){
				console.log(err.error_message);
			});
		}

	});

	//to get all rig data
	unBindAreaWatch=$scope.$watch('area',function(newValue, oldValue){
		var val="";
	
			$.each($scope.arealist, function(index,value){
				if(value.PREFERRED_NAME==newValue){
					val= value.AREA_ID;
					areaID=val;
					return false;
				}
			})

			$scope.rig = "";
			$scope.equipType = "";
			$scope.equipment = "";
			$scope.rigShow=true;
			$scope.equipmentTypeShow=true;
			$scope.equipShow=true;
		if(val!=null && val.length!=0){
			MainService.getUserMasterData('rig',assetID,val).then(function(data){
	
			$scope.riglist=data;
			
			$scope.rigShow=false;
			$scope.equipmentTypeShow=true;
			$scope.equipShow=true;

			//$scope.areaWatched=true;
			},function(err){
				console.log(err.error_message);
			});
		}

	});

	//to get all equipType data
	unBindRigWatch=$scope.$watch('rig',function(newValue, oldValue){
		var val="";
		$.each($scope.riglist, function(index,value){
			if(value.RIG_NAME==newValue){
				val= value.RIG_ID;
				rigID=val;
				return false;
			}
		})
			$scope.equipType = "";
			$scope.equipment = "";
			$scope.equipmentTypeShow=true;
			$scope.equipShow=true;
		if(val!=null && val.length!=0){
			MainService.getUserMasterData('equipType',assetID,areaID,val).then(function(data){
				$scope.equipTypelist=data;
			
				$scope.equipmentTypeShow=false;
				$scope.equipShow=true;
				$scope.rigWatched=true;
			},function(err){
				console.log(err.error_message);
			});
		}
	});

	//to get all equipment data
	unBindEqTypeWatch=$scope.$watch('equipType',function(newValue, oldValue){
		$scope.equipment = "";
		$scope.equipShow=true;
		if(newValue!=null && newValue.length!=0){
			MainService.getUserMasterData('equipment',assetID,areaID,rigID,newValue).then(function(data){
				$scope.equipmentlist=data;
				$scope.equipShow=false;
				$scope.eqypTypeWatched=true;
			},function(err){
				console.log(err.error_message);
			});
		}
	});

	//to get all equipment data
	unBindEqIdWatch=$scope.$watch('equipment',function(newValue, oldValue){
		if($scope.getEquipmentState() == 'add'){
			if(newValue != undefined && newValue != null && newValue != ''){
				if(recType != undefined && recType != null && recType != '' && !isNaN(recType)){
					var m = '';
					$.each($scope.equipmentlist, function(index,value){
						if(value.EQUIPMENT_NAME==newValue){
							m = value.EQUIPMENT_ID;
							return false;
						}
					})

					MainService.getExistingMaintenancesForEquipment(m).then(function(data){
						var dataArr = data.map(function(p){
							return p.MAINT_TYPE_ID;
						});

						if(!isNaN(m)){
							if($.inArray(recType,dataArr) > -1){
								$scope.reset();
								bootbox.alert('A maintenance of this type has already been added for this equipment. Please edit the existing maintenance or add a different maintenance type.');
							}
						}
					},function(err){
						console.log(err);
					})
				}
			}
		}

		$.each($scope.equipmentlist, function(index,value){
			if(value.EQUIPMENT_NAME==newValue){
				eqpId= value.EQUIPMENT_ID;
				return false;
			}
		})
	});

	}//end of initialzeWatches

	initialzeWatches();

	unBindTypeWatch=$scope.$watch('type',function(newValue,oldValue){
		
		if($scope.getEquipmentState() == 'add'){
			if(newValue != undefined && newValue != null && newValue != ''){
				if(eqpId != undefined && eqpId != null && eqpId != '' && !isNaN(eqpId)){
					var m = "";
					$.each($scope.typeList, function(index,value){
						if(newValue == value.name){
							m = value.id;
							return false;
						}
					});

					
					MainService.getExistingMaintenancesForEquipment(eqpId).then(function(data){
						//console.log(data);
						var dataArr = data.map(function(p){
							return p.MAINT_TYPE_ID;
						});

						if(!isNaN(m)){
							console.log($.inArray(m,dataArr) > -1);
							if($.inArray(m,dataArr) > -1){
								$scope.reset();
								bootbox.alert('A maintenance of this type has already been added for this equipment. Please edit the existing maintenance or add a different maintenance type.');
							}
						}
					},function(err){
						console.log(err);
					})
				}
			}
		}
		
		$.each($scope.typeList, function(index,value){
			if(value.name==newValue){
				recType= value.id;
			}
			
			//if(newValue.indexOf('Unplanned Maintenance')){
			if(newValue.indexOf('Break Down') > -1){	
				$scope.showCommentBox=true;
				$scope.showCheckListBox=false;
			}
			else{
				$scope.showCheckListBox=true;
				$scope.showCommentBox=false;
			}
		})
	});

	$scope.$watch('assignee',function(newValue,oldValue){
		$.each($scope.assigneeList,function(index,value){
			if(value.AssigneeName==newValue){
				assigneeId=value.USER_ID;
				return false;
			}
		})
	
	})

	$scope.checkDate=function(){
		console.log($($('#'+$scope.startId).children()[0]).val());
	}

	$scope.initializeDateTimePicker = function(id){
		$timeout(function() {
			$("#"+id).datetimepicker({format:'DD/MM/YYYY'});

			//var date = $("#"+id).datetimepicker("getDate");
			//console.log(date);
//console.log(date.toISOString());

			// to check entered date is greater than today's date
			
			// $("#"+id).on('dp.change', function(e){

			// 	//startDate = moment(e.timeStamp).format('YYYY-MM-DD HH:mm:ss');//$($('#'+$scope.startId).children()[0]).val();
			// 	//endDate = moment(e.timeStamp).format('YYYY-MM-DD HH:mm:ss');//$($('#'+$scope.endId).children()[0]).val();
			// 	console.log(e.date._d);
			// 	console.log(e.currentTarget.getAttribute('id'));
			// 	console.log($scope.startId);
			// 	console.log($scope.endId);
			// 	console.log("End: "+ ($scope.endId==e.currentTarget.getAttribute('id')));
			// 	console.log("Start: "+ ($scope.startId==e.currentTarget.getAttribute('id')));

			// 	if($scope.endId==e.currentTarget.getAttribute('id')){
			// 		flag = 1;
			// 		endDate = moment(e.date._d).format('YYYY-MM-DD HH:mm:ss');
			// 		$scope.endDate = endDate;
			// 	}

			// 	if($scope.startId==e.currentTarget.getAttribute('id')){
			// 		flag = 0;
			// 		startDate = moment(e.date._d).format('YYYY-MM-DD HH:mm:ss');
			// 		$scope.startDate = startDate;
			// 	}

			// 	if($scope.type != 'Break Down'){
			// 		if(moment(moment($.now()).format('DD/MM/YYYY'),'DD/MM/YYYY').valueOf() > moment(moment(e.date._d).format('DD/MM/YYYY')).valueOf()+1000*60){
			// 			var cu = $($('#'+id).children()[0]).val();
			// 			if($scope.endId==e.currentTarget.getAttribute('id')){
			// 				$scope.endDate = "";
			// 			}else if($scope.startId==e.currentTarget.getAttribute('id')){
			// 				$scope.startDate = "";
			// 			}
			// 			bootbox.alert('You have selected '+cu+'. Please select future date and time.');						
			// 		}
			// 	}

			// 	$timeout(function(){
			// 		$scope.$apply();
			// 	},1)
			// })

			$('#'+id).on('dp.hide',function(e){

				if($scope.endId==e.currentTarget.getAttribute('id')){
					flag = 1;
					endDate = moment(e.date._d).format('YYYY-MM-DD HH:mm:ss');
					$scope.endDate = "";
					$scope.endDate = endDate;
					$($('#'+id).children()[0]).val($scope.endDate);
				}

				if($scope.startId==e.currentTarget.getAttribute('id')){
					flag = 0;
					startDate = moment(e.date._d).format('YYYY-MM-DD HH:mm:ss');
					$scope.startDate = "";
					$scope.startDate = startDate;
					$($('#'+id).children()[0]).val($scope.startDate);
				}

				console.log($scope.endDate);
				console.log($scope.startDate);

				// to check start date is greater than end date
				 if($($('#'+$scope.endId).children()[0]).val() != "" && $($('#'+$scope.startId).children()[0]).val() != "" && moment($scope.endDate).startOf('day').valueOf() < moment($scope.startDate).startOf('day').valueOf()){
					var str = '';
					if($scope.endId==e.currentTarget.getAttribute('id')){
						str = 'Scheduled end date "'+$scope.endDate+'" cannot be less than scheduled start date "'+$scope.startDate+'"';
						$scope.endDate = "";
					}else if($scope.startId==e.currentTarget.getAttribute('id')){
						str = 'Scheduled start date "'+$scope.startDate+'" cannot be greater than scheduled end date "'+$scope.endDate+'"';
						$scope.startDate = "";
					}
					$($('#'+id).children()[0]).val("");
					bootbox.alert(str);
				 }
				// }else if($($('#'+$scope.startId).children()[0]).val() !="" && moment($scope.endDate,'YYYY-MM-DD HH:mm:ss').valueOf() < moment($scope.startDate,'YYYY-MM-DD HH:mm:ss').valueOf()){
				// 	var str = 'Scheduled start date "'+$scope.startDate+'" cannot be greater than scheduled end date "'+$scope.endDate+'"';
				// 	if($scope.endId==e.currentTarget.getAttribute('id')){
				// 		$scope.endDate = "";
				// 	}else if($scope.startId==e.currentTarget.getAttribute('id')){
				// 		$scope.startDate = "";
				// 	}
				// 	$($('#'+id).children()[0]).val("");
				// 	bootbox.alert(str);
				// }
				else if($scope.type != 'Break Down'){

					if(moment().startOf('day').valueOf() > moment(e.date._d).startOf('day').valueOf()){
						var str = 'You have selected '+ $($('#'+id).children()[0]).val() +'. Please select future date and time.';
						if($scope.endId==e.currentTarget.getAttribute('id')){
							$scope.endDate = "";
						}else if($scope.startId==e.currentTarget.getAttribute('id')){
							$scope.startDate = "";
						}
						$($('#'+id).children()[0]).val("");
						bootbox.alert(str);						
					}
				}

				$timeout(function(){
					$scope.$apply();
				},1)
			})

		}, 1);	
	} // end of date picker

	$scope.addNewValue = function(){
		MainService.storeAddData($scope.listOfValues,"user");
	}

	function unBindWatchers(){
		// unbind all the watches, so that individual query will not get fired
				if(unBindAssetWatch!=undefined)
					unBindAssetWatch();
				if(unBindAreaWatch!=undefined)
					unBindAreaWatch();
				if(unBindRigWatch!=undefined)
					unBindRigWatch();
				if(unBindEqTypeWatch!=undefined)
					unBindEqTypeWatch();
				/*if(unBindTypeWatch!=undefined)
					unBindTypeWatch();*/
	}

	$scope.$on('editValue',function(event,rowVal,type){

		editFlag=1;
		if(type=='Maintenance'){
			// to get asset, area, rig etc
			MainService.editConfiguratorTables(type,rowVal['Equipment Id']).then(function(data){
	

				unBindWatchers();

				// to disable required input fields
				$scope.assetShow=true;
				$scope.areaShow=true;
				$scope.rigShow=true;
				$scope.equipmentTypeShow=true;
				$scope.equipShow=true;
				$scope.typeShow=true;

				//to populate the data in input fields
				$scope.asset=data[0].ASSET_NAME;
				$scope.area=data[0].Area_name;
				$scope.rig=data[0].RIG_NAME;
				$scope.equipType=data[0].eqp_type;
				$scope.equipment=data[0].EQUIPMENT_NAME;
				eqpId=data[0].EQUIPMENT_ID;


				
			},function(err){
				console.log(err.ErrorMessage);

			})

			eqpActId=rowVal.Id;
	
			// to get list of activities
			MainService.editConfiguratorTables('activityChecklist',rowVal.Id).then(function(data){
	
				if(data.length>0){
					$scope.activityList=[];

				$.each($scope.typeList, function(index,value){
					if(value.id==data[0].MAINT_TYPE_ID){
						$scope.type=value.name;
						return false;
					}
				})

				$scope.startDate=moment(data[0].SCHEDULED_START_DATE).format("YYYY-MM-DD HH:mm:ss");
				$scope.endDate=moment(data[0].SCHEDULED_END_DATE).format("YYYY-MM-DD HH:mm:ss");
				$scope.assignee=data[0].Assignee;
				$.each(data,function(index,value){
					$scope.activityList.push(value.ACTIVITY_NAME);
					var obj={id:value.ACTIVITY_ID, name:value.ACTIVITY_NAME};
					ActivityListFromDB.push(obj);
					deleteActivity.push(value.ACTIVITY_ID);

	
				});
	
				}
				

			},function(err){
				console.log(err.ErrorMessage);
			})

		}
	
	});

	
}).controller("UserMasterController",function($scope,MainService){
	
	$scope.chartParams = {
		title: 'Add/Edit User'
	}

	$scope.$emit('setCurrentConfig','user');
	$scope.$emit('setConfigView','usermaster');
	
	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.addition.usermaster',
		params: null
	}))

	$scope.roleList = [];
	$scope.assetlist = [];
	$scope.arealist = [];
	$scope.riglist = [];
	//$scope.equipTypelist = [];
	$scope.equipmentlist = [];
	$scope.multiple = true;

	function initialize(){
		$scope.models={
		"firstName":'',
		"lastName":'',
		"emailID":'',
		"password":'',
		"confirmPassword":'',
		"contactNo":''
	};	
	
	$scope.role ="";
	$scope.asset = "";
	$scope.area = "";
	$scope.rig = "";
	//$scope.equipType = "";
	$scope.equipment = null;

	assetID="";
	areaID = "";
	rigID = "";
	equipTypeID = "";
	userData="";

	$scope.areaShow=true;
	$scope.rigShow=true;
	//$scope.equipmentTypeShow=true;
	$scope.equipShow=true;

	$scope.roleWatched=false;
	$scope.assetWatched=false;
	$scope.areaWatched=false;
	$scope.rigWatched=false;
	//$scope.eqypTypeWatched=false;
	editFlag=0;
	userId="";
	}

	initialize();

	MainService.getUserRoles().then(function(data){
		$scope.roleList=data;
	
		},function(err){
			console.log(err.error_message);
		});

	

	$scope.$watch('role',function(newValue,oldValue){
		$scope.asset = "";
		$scope.area = "";
		$scope.rig = "";
		//$scope.equipType = "";
		$scope.equipment = null;
		$scope.roleWatched=true;

		assetID = "";
		areaID = "";
		rigID = "";
		equipId = [];
	})


	//to get all asset data
	//var allData=[];
	MainService.getUserMasterData('asset').then(function(data){
		$scope.assetlist=data;
	
	},function(err){
		console.log(err.error_message);
	});

	
	//to get all area data
	$scope.$watch('asset',function(newValue, oldValue){
		var val="";
		$.each($scope.assetlist, function(index,value){
			if(value.ASSET_NAME==newValue){
				val= value.ASSET_ID;
				assetID=val;
			}
		})
			$scope.area = "";
			$scope.rig = "";

			areaID = "";
			rigID = "";
			equipId = [];
			//$scope.equipType = "";
			$scope.equipment = null;
			$scope.areaShow=true;
			$scope.rigShow=true;
			//$scope.equipmentTypeShow=true;
			$scope.equipShow=true;
		if(val!=null && val.length!=0){
			MainService.getUserMasterData('area',val).then(function(data){
			$scope.arealist=data;			
			$scope.areaShow=false;
			$scope.rigShow=true;
			//$scope.equipmentTypeShow=true;
			$scope.equipShow=true;
			$scope.assetWatched=true;
			},function(err){
				console.log(err.error_message);
			});
		}

	});

	//to get all rig data
	$scope.$watch('area',function(newValue, oldValue){
		var val="";
	
		$.each($scope.arealist, function(index,value){
			if(value.PREFERRED_NAME==newValue){
				val = value.AREA_ID;
				areaID=val;
			}
		})

		$scope.rig = "";
		rigID = "";
		equipId = [];
		//$scope.equipType = "";
		$scope.equipment = null;
		$scope.rigShow=true;
		//$scope.equipmentTypeShow=true;
		$scope.equipShow=true;

		if(val!=null && val.length!=0){
			MainService.getUserMasterData('rig',assetID,val).then(function(data){
	
			$scope.riglist=data;
			if($scope.role=="Area Manager"){
				$scope.rigShow=true;
				//$scope.equipmentTypeShow=true;
				$scope.equipShow=true;
			}
			else if($scope.role=="Rig Manager"||$scope.role=="Maintenance Engineer"){
				$scope.rigShow=false;
				//$scope.equipmentTypeShow=true;
				$scope.equipShow=true;
			}
			$scope.areaWatched=true;
			},function(err){
				console.log(err.error_message);
			});
		}

	});

	//to get all equipType data
	$scope.$watch('rig',function(newValue, oldValue){
		var val="";
		$.each($scope.riglist, function(index,value){
			if(value.RIG_NAME==newValue){
				val = value.RIG_ID;
				rigID=val;
			}
		})

		//console.log("Rig watching");
		//$scope.equipType = "";
		$scope.equipment = null;
		equipId = [];
		//$scope.equipmentTypeShow=true;
		$scope.equipShow=true;

		if(val!=null && val.length!=0){
/*			MainService.getUserMasterData('equipType',assetID,areaID,val).then(function(data){*/
			//$scope.equipTypelist=data;
			$scope.equipTypelist = [{
				"DESCRIPTION": 'Generator'
			},{
				"DESCRIPTION": 'Compressor'
			},{
				"DESCRIPTION": 'Mud Pump'
			},{
				"DESCRIPTION": 'Agitator'
			},{
				"DESCRIPTION": 'Shaker'
			},{
				"DESCRIPTION": 'Drawworks'
			}];
			
			if($scope.role=="Maintenance Engineer"){
				//$scope.equipmentTypeShow=false;
				$scope.equipShow=true;
				$scope.rigWatched=true;

				$scope.equipment = null;
				$scope.equipShow=true;
				if(newValue!=null && newValue.length!=0){
					MainService.getUserMasterData('equipment',assetID,areaID,rigID,'').then(function(data){
						$scope.equipmentMasterData = MainService.getRefinedDropDown(data);

						$scope.equipmentlist = $scope.equipmentMasterData.filter(function(d){
							return $.inArray(d.value,$scope.equipment) == -1;
						});

						$scope.equipShow=false;
						$scope.eqypTypeWatched=true;
					},function(err){
						console.log(err.error_message);
					});
				}
			}
/*			},function(err){
				console.log(err.error_message);
			});*/
		}

	});

	//to get all equipment data - no need for equip type
	// $scope.$watch('equipType',function(newValue, oldValue){
	// 	$scope.equipment = "";
	// 	$scope.equipShow=true;
	// 	if(newValue!=null && newValue.length!=0){
	// 		MainService.getUserMasterData('equipment',assetID,areaID,rigID,newValue).then(function(data){
	// 			$scope.equipmentlist=data;
	// 			$scope.equipShow=false;
	// 			$scope.eqypTypeWatched=true;
	// 		},function(err){
	// 			console.log(err.error_message);
	// 		});
	// 	}
	// });

	var equipId=[];

	//to get all equipment id
	$scope.$watch('equipment',function(newValue, oldValue){
		if(newValue!=null && newValue.length!=0){
			
			equipId = newValue;

			if($scope.equipmentMasterData != null && $scope.equipmentMasterData != undefined && $scope.equipmentMasterData.constructor === Array && $scope.equipmentMasterData.length >0){
				$scope.equipmentlist = $scope.equipmentMasterData.filter(function(d){
					return $.inArray(d.value,newValue) == -1;
				});
			}
		}
	},true);

	$scope.saveUser=function(){
		var roleId="";
		$.each($scope.roleList, function(index,value){
			if(value.ROLE_NAME==$scope.role){
				val= value.ROLE_ID;
				roleId=val;
			}
		});

		var asgnId;
		// depending upon the role, send ownership i.e. rigId, Areaid, Eqp Id
		if(roleId==1){// Area manager
			asgnId=[areaID];
	
		}
		else if(roleId==2){ // rig manager
			asgnId=[rigID];
		}
		else if(roleId==3){ // maint. er.
	
			/*if(equipId.length!=0)
			{
				asgnId=equipId;
			}
			else if(eqptype){

			}
			else if()*/
				asgnId=equipId;
		}

		var goFlag = true;
		if(asgnId.length > 0){
			$.each(asgnId,function(index,value){
				if(value == undefined || value == null || value == ""){
					goFlag = false;
					return false;
				}
			})

			if(goFlag){
				//invoke the service
				if(editFlag==1){
					// invoke update query

					var obj={
						"userId":userId ,
						"firstName" : $scope.models.firstName,
						"lastName" : $scope.models.lastName,
						"email" : $scope.models.emailID,
						"contactNumber" :$scope.models.contactNo ,
						"roleId" :roleId ,
						"assignId" :asgnId ,//for the thing hes assigned to
						}
			
						MainService.editTheJson("user",obj).then(function(data){	
							
						if(data!=undefined && data !== Object(data) && data.indexOf("Done") > -1){
							bootbox.alert("User details have been edited");
							$("[name='confpassword']").removeAttr('disabled');
							$("[name='password']").removeAttr('disabled');
							unBindWatchers();
							initialize();
							$scope.$emit('setCurrentConfig','user');
						}
						else
							bootbox.alert("There was a problem updating the edited details. Please try again later.");
						},function(err){
							console.log(err.error_message);
						});
					
				}
				else{
					// to add new user, invoke insert query
					if($scope.models.password!=$scope.models.confirmPassword){
						bootbox.alert("Password didn't match!");
					}
					else{
						var obj={
							"firstName" : $scope.models.firstName,
							"lastName" : $scope.models.lastName,
							"password" : $scope.models.password,
							"email" : $scope.models.emailID,
							"contactNumber" :$scope.models.contactNo ,
							"roleId" :roleId ,
							"assignId" :asgnId //for the thing he/she is assigned to
						}

						MainService.getTheJson("user",obj).then(function(data){	
							if(data!=undefined && data.length!=0 && data.errno!="ECONNREFUSED"){
								if(data !== Object(data) && data.indexOf("Done") > -1){
									bootbox.alert("User has been saved");
									$("[name='confpassword']").removeAttr('disabled');
									$("[name='password']").removeAttr('disabled');
									unBindWatchers();
									initialize();
									$scope.$emit('setCurrentConfig','user');
								}
								else
									bootbox.alert("There was a problem adding the user details. Please try again later.");
							}
							else{
								bootbox.alert("Some Error Occurred "+data.errno);
							}
						
						},function(err){
							console.log(err.error_message);
						});
					}	
				}
			}else{
				bootbox.alert("Please associate the user with at least one entity.");
			}
		}else{
			bootbox.alert("Please associate the user with at least one entity.");
		}

		//Uncomment From here
		

		//Uncomment till here
	}	

	var unbindRoleWatcher;
	var unbindAssetWatcher;
	var unbindAreaWatcher;
	var unbindRigWatcher;
	var unbindEqypWatcher;

	$scope.$on('editValue',function(event,rowVal,type){
	
		if(type=="user"){			
			unBindWatchers();
			initialize();
			userId=rowVal.Id;
			editFlag=1;
			MainService.editConfiguratorTables(type,rowVal.Id).then(function(data){

			if(data!=undefined && data != null && data.constructor === Array && data.length > 0){
				$scope.models.firstName=data[0].USER_FIRST_NAME;
				$scope.models.lastName=data[0].USER_LAST_NAME;
				$scope.models.emailID=data[0].USER_EMAIL;
				$scope.models.password="password";
				$scope.models.confirmPassword="password";
				$scope.models.contactNo=data[0].USER_CONTACT_NUMBER;
				$scope.role=data[0].ROLE_NAME;

				unbindRoleWatcher = $scope.$watch('roleWatched',function(newValue,oldValue){
					//console.log("Role watched");
					$scope.asset=data[0].ASSET_NAME;
				});
				unbindAssetWatcher = $scope.$watch('assetWatched',function(newValue,oldValue){
					//$scope.area="India";
					//console.log("Asset watched");
					$scope.area = data[0].Area_Name;
				});
				
				unbindAreaWatcher =$scope.$watch('areaWatched',function(newValue,oldValue){
					//console.log("Area watched");
					$scope.rig=data[0].RIG_NAME;
				});

				unbindRigWatcher=$scope.$watch('rigWatched',function(newValue,oldValue){
					//console.log('Rig watched');
					$scope.equipType=data[0].Equipment_Type;
					$scope.equipment = [];

					MainService.getUserMasterData('equipment',data[0].ASSET_ID,data[0].AREA_ID,data[0].RIG_ID,'').then(function(dataEquipMaster){
						$scope.equipmentMasterData = MainService.getRefinedDropDown(dataEquipMaster);

						$scope.equipment = data.map(function(v){
							return v.EQUIPMENT_ID;
						});

					},function(errorEquipMaster){
						console.log(errorEquipMaster.ErrorMessage);
					});
				});
				// unbindEqypWatcher=$scope.$watch('eqypTypeWatched',function(newValue,oldValue){
				// 	$scope.equipment=data[0].EQUIPMENT_NAME;
				// });
				$("[name='password']").attr('disabled','disabled');
				$("[name='confpassword']").attr('disabled','disabled');
			}		
			},function(err){
				console.log(err.ErrorMessage);
			});
		}
	});
	$scope.reset=function(){
		unBindWatchers();
		initialize();
		$("[name='confpassword']").removeAttr('disabled');
		$("[name='password']").removeAttr('disabled');
	}

	function unBindWatchers(){
	
	if(unbindRoleWatcher!=undefined)
		unbindRoleWatcher();
	if(unbindAssetWatcher!=undefined)
		unbindAssetWatcher();
	if(unbindAreaWatcher!=undefined)
		unbindAreaWatcher();
	if(unbindRigWatcher!=undefined)
		unbindRigWatcher();
	if(unbindEqypWatcher!=undefined)
		unbindEqypWatcher();
	}
}).controller("SensorMasterController",function($scope,MainService,$timeout){
	$scope.chartParams = {
		title: 'Add/Edit Sensor'
	}
	$scope.$emit('setCurrentConfig','sensor');
	$scope.$emit('setConfigView','sensormaster');
	
	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.addition.sensormaster',
		params: null
	}))
	
	$scope.$on('removePrimaryKey',function(event,message){
		if(message == "sensor"){
			$.each($scope.listOfValues,function(index,value){
				if(/\bmac\b/.test(value.header.toLowerCase()) == true){
					value.data = null;
					return false;
				}
			});
		}
	});

	$scope.resetData = function(){
		$.each($scope.listOfValues,function(index,value){
			// if($scope.equipmentState == 'edit'){
			// 	if(/\bmac\b/.test(value.header.toLowerCase()) == false)
			// 		value.data = null;
			// }else{
			// 	value.data = null;
			// }
			value.data = null;
			$scope.disableSensor = false;
			if(value.type == 'dateTimePicker'){
				$('#'+value.id+' > input').val(undefined);
			}

			if(value.type == 'map'){
				value.data = ["",""];
			}
		});

		//$scope.equipmentState = 'add';
		$scope.setEquipmentState('add');
		$scope.paramList = [];
	}

	MainService.initiateCollapsibles('collapsible');

	$scope.listOfValues = [];
	//1-input box,2-date picker,3-drop box,4-lat/long.
	$scope.types = [1,1,1,3];
	$scope.listOfHeaders = ["Sensor MAC ID","Sensor Name","Description","Manufacturer"];
	$scope.paramList = []; 
	$scope.dropdownList = [];
	$scope.paramToEdit = "";

	$scope.initializeDateTimePicker = function(id){
		$timeout(function() {
			$("#"+id).datetimepicker({format:'DD/MM/YYYY'});
		}, 1);
	}

	$scope.editParam = function(index,array){
		$scope.$broadcast('forceEdit',array[index]);
	}

	$scope.removeParam = function(index,arrayToRemoveFrom,arrayToAddTo){
	
		if(arrayToAddTo!=undefined && arrayToAddTo != null)
			arrayToAddTo.push(arrayToRemoveFrom[index]);
		arrayToRemoveFrom.splice(index,1);
	}

	$.each($scope.listOfHeaders,function(index,value){
		$scope.listOfValues.push(MainService.getObjectForType(value,$scope.types[index]));
	});

	MainService.getConfiguratorDropDown('Manufacturer').then(function(data){
		$.each($scope.listOfHeaders,function(index,value){
			if(value.indexOf("Manufacturer") > -1){
				$scope.listOfValues[index].options = MainService.getRefinedDropDown(data);
				return false;
			}
		});
	},function(err){
		console.log(err.ErrorMessage);
	});

	// list of parameters for the sensors
	MainService.getAvailableParameters("custom").then(function(data){
		if(data != null && data != undefined && data.constructor === Array && data.length > 0){
			var uniqueAttrIds = [];
			$.each(data,function(ind,val){
				if($.inArray(val.attrId,uniqueAttrIds) == -1){
					uniqueAttrIds.push(val.attrId);
				}
			});

			$scope.dropdownList[0] = [];
			var tempUoms = [];
			var tempParams = [];
			$scope.dropdownList[1] = [];

			$.each(data,function(i,v){
				var uoms = {};
				uoms.UOM_ID = v.UOM_ID;
				uoms.UOM_NAME = v.UOM_NAME;
				uoms.UOM_TYPE = v.type;
				tempUoms.push(uoms);

				if($.inArray(v.attrId,uniqueAttrIds) > -1){
					var params = {};
					params.Item = v.Item;
					params.Value = v.Value;
					params.attrId = v.attrId;
					params.UOM_TYPE = v.type;
					tempParams.push(params);

					var b = uniqueAttrIds.indexOf(v.attrId);
					if(b > -1){
						uniqueAttrIds.splice(uniqueAttrIds.indexOf(v.attrId),1);
					}
				}
			});

			$scope.dropdownList[1] = tempUoms;
			$scope.dropdownList[0] = tempParams;
		}else{
			$scope.dropdownList[0] = [];
			$scope.dropdownList[1] = [];
		}
	}).then(function(data){
		
	});
	
	// MainService.getConfiguratorDropDown('UOM').then(function(data){
	// 	$scope.dropdownList[1] = MainService.getRefinedDropDown(data);
	// },function(data){
	
	// });

	$scope.editId = null;
	$scope.addNewValue = function(){
		$.each($scope.listOfHeaders,function(index,value){
			if($scope.types[index] == 2){
				var c = $("#"+$scope.listOfValues[index].id+" > input").val();
				$scope.listOfValues[index].data = moment($("#"+$scope.listOfValues[index].id+" > input").val()).format("DD/MM/YYYY");
				if($scope.listOfValues[index].data.toLowerCase().indexOf("invalid") > -1)
					$scope.listOfValues[index].data = c;
				//$scope.listOfValues[index].data = moment($("#"+$scope.listOfValues[index].id+" > input").val()).format("DD/MM/YYYY");
			}
		});
		if($scope.listOfValues.filter(function(v){
				if(v.data == null || v.data == "" || v.data == undefined){
					return true;
				}else if(v.type == 'map'){
					return v.data.length != 2 || v.data.filter(function(f){return f == null || f == "" || f == undefined}).length != 0
				}
			}).length == 0 && $scope.paramList.length != 0){
			if($scope.getEquipmentState() == 'edit' && $scope.editId!=null){
				MainService.editCollapsibleTemplatedData([$scope.listOfValues,$scope.paramList],'sensor').then(function(data){	
					$scope.editId = null;
	
					if(data!=null && data!=undefined && data !== Object(data) && data.indexOf('Done') > -1){
						$scope.$emit('popup','Sensor '+$scope.listOfValues[0].data+' has been edited.',"info");
						// $.each($scope.listOfValues,function(i,v){
						// 	if(v.type == 'map'){
						// 		v.data = [null,null];
						// 	}
						// 	else{							
						// 		v.data = null;
						// 	}
						// });
						// $scope.paramList = [];
						$scope.resetData();
						$scope.$emit('setCurrentConfig','sensor');
					}else{
						$scope.$emit('popup',data,"error");
					}
				},function(data){
	
					$scope.$emit('popup',data,"error");
				});
			}else{
				MainService.addCollapsibleTemplatedData([$scope.listOfValues,$scope.paramList],'sensor').then(function(data){
					if(data != undefined && data !== Object(data) && data.indexOf('Done') > -1){
						$scope.$emit('popup','Sensor '+$scope.listOfValues[0].data+' has been added.',"info");
						// $.each($scope.listOfValues,function(i,v){
						// 	if(v.type == 'map'){
						// 		v.data = [null,null];
						// 	}
						// 	else{							
						// 		v.data = null;
						// 	}
						// });
						// $scope.paramList = [];
						$scope.resetData();
						$scope.$emit('setCurrentConfig','sensor');
					}else if(data==undefined){
						$scope.$emit('popup','Sensor '+$scope.listOfValues[0].data+' has been added.',"info");
					}else{
						$scope.$emit('popup',data,"error");
					}
				},function(data){
					$scope.$emit('popup',data,"error");
				});
			}
		}else{
			$scope.$emit('popup','All fields are mandatory!',"error");
		}
	}

	$scope.$on('editValue',function(event,id,type){
		if(type=='sensor'){
			$scope.disableSensor = true;
			$scope.editId = id.Id;
			MainService.editConfiguratorTables(type,id.Id).then(function(data){
				
				$.each($scope.listOfHeaders,function(index,value){
					if($scope.types[index] == 2){
						$scope.listOfValues[index].data = moment(data[0][value]).format("DD/MM/YYYY");
						$("#"+$scope.listOfValues[index].id+" > input").val(moment(data[0][value]).format("DD/MM/YYYY"));
					}
					else if($scope.types[index]==4){
						$scope.listOfValues[index].data = [null,null];
						$scope.listOfValues[index].data[0] = data[0]["Latitude"];
						$scope.listOfValues[index].data[1] = data[0]["Longitude"];
					}
					else{
						$scope.listOfValues[index].data = data[0][value];
					}
				})
			},function(err){
				console.log(err.ErrorMessage);
			})

			MainService.editConfiguratorTables('sensor_params',id.Id).then(function(data){
				$scope.paramList = data;
			},function(data){
				console.log(data.ErrorMessage);
			})
		}
	});
});