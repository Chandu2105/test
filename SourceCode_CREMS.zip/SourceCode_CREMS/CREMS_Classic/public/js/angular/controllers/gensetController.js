angular.module('myApp').controller('GensetController',function($scope,$state,$rootScope,MainService,$http,GensetService,$timeout){
	
	$scope.header = $state.params.id;
	
	$rootScope.$broadcast('updateRig',[{'name':$state.params.name,'url':'app.dashboard.genset','params': {id: $state.params.id,name: $state.params.name},'type': 'equipment'},'equipment']);
	MainService.hideBreadcrumb(false);
	MainService.initialiseSettingsPanel();
	$scope.paramsToShow={};
	GensetService.getMappedParameters($state.params.id).then(function(data){
		if(data!=undefined&&data.length!=0){
			var count=1;
			var stringData="";
			for(params in data){
				if(count<5){
					$scope.paramsToShow[data[params].ATTR_NAME]=true;
				}
				else{
					$scope.paramsToShow[data[params].ATTR_NAME]=false;
				}
				count++;				
			}		
		}
			
	},function(err){
		console.log(err.error_message);
	});

	/*$scope.paramsToShow = {
		"Engine RPM": true,
		"Engine Coolant Temperature": true,
		"Fuel Consumption Rate": true,
		"Filtered Engine Oil Pressure": true,
		"Crankcase Pressure": false,
		"Engine Exhaust Temperature": false,
		"Battery Voltage": false,
		"Engine Operating Hours": false,
		"Power Factor": false,
		"Active Power": false,
		"Operating Frequency": false,
		"Voltage": false
	};*/
	
	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.dashboard.genset',
		params: {
			id: $state.params.id,
			name: $state.params.name
		}
	}))
	
	$scope.paramClicked = function(key){
		$scope.paramsToShow[key] = !$scope.paramsToShow[key];	
		$timeout(function(){
			$scope.$broadcast('redrawGensetCharts','');
			$rootScope.$broadcast('updateChart','');
		},10);
	}	
	
	$scope.getData = function(){
		// GensetService.getGensetParameters($state.params.id).then(function(data){
		// 	$scope.currentTime=moment(new Date()).subtract(1, "minutes").format('DD/MM/YYYY HH:mm');		
		// 	$scope.$broadcast('gensetParametersData',data);
		// },function(err){
		// 	console.log(err.error_message);
		// });

		MainService.getEquipmentState($state.params.id).then(function(data){
			if(data!=undefined && data != null && data.constructor === Array && data.length > 0){
				switch(data[0].EQUIP_STATUS_ID){
					case 101:
					case 102:
					case 103:
						$scope.eqState = 'Deactivated';
						$scope.eqStatus = 'grey';
						break;
					case 104:
						$scope.eqState = 'Active';
						$scope.eqStatus = 'green';
						break;
					case 105:
						$scope.eqState = 'Active but not reachable';
						$scope.eqStatus = 'red';
						break;
					default:
						$scope.eqState = 'Deactivated';
						$scope.eqStatus = 'grey';
						break;
				}
			}
		},function(err){
			console.log(err.ErrorMessage);
		})
	}

	//to get all the parameters data from DB in every 1 min
	$scope.getData();

	gensetInterval = setInterval(function(){
		$scope.getData();
	}, 1000*60);
		
	intervalsList.push(gensetInterval);	
	
	
}).controller('gensetDetailsController',function($scope,GensetService,$state,MainService){
	$scope.chartParams = {
		title : "Equipment Specifications",
		subtitle:"Genset",
		downloadEnabled: true,
		downloadTitle: "Download Operation Manual"
	};	
	
	$scope.downloadFile = function(){
		MainService.downloadFile($state.params.id);
	}
		
	GensetService.getGensetSpecifications($state.params.id).then(function(data){
		$scope.gensetDetails=data;		
	},function(err){
		console.log(err.error_message);		
	});
	
}).controller('GensetComponentsController',function($scope,$state,GensetService){
	var threshold={};	
	var time="";
	$scope.chartParams = {
		title: "Critical Generator Parameters",
		subtitle:"Last Updated at"+time
	};
	$scope.$on('gensetParametersData',function(event,mess){
		threshold=mess;
		if(mess!=undefined&&mess.length!=0)
			time=moment(mess[0].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
		$scope.chartParams.subtitle="Last Updated at "+time;
	//	$scope.chartParams.title=mess.data[1].ATTR_NAME+" ("+mess.data[1].UOM_QUANTITY_TYPE+")";
	
		$scope.gensetImpParams = [{
			name: 'Engine Speed',
			value: parameterValue('Engine Speed'),
			posTop: "10em",
			posLeft: "1em",
			warning: checkWarning('Engine Speed',parameterValue('Engine Speed'))
		},{
			name: 'Crankcase Pressure',
			value: parameterValue('Crankcase Pressure'),
			posTop: "7em",
			posLeft: "26em",
			warning: checkWarning('Crankcase Pressure',parameterValue('Crankcase Pressure'))
		},{
			name: 'Fuel Consumption Rate',
			value: parameterValue('Fuel Consumption Rate'),
			posTop: "3em",
			posLeft: "15em",
			warning: checkWarning('Fuel Consumption Rate',parameterValue('Fuel Consumption Rate'))
		},{
			name: 'Exhaust Temperature',
			value: parameterValue('Exhaust Temperature'),
			posTop: "11em",
			posLeft: "21em",
			warning: checkWarning('Exhaust Temperature',parameterValue('Exhaust Temperature'))
		},{
			name: 'Voltage',
			value: parameterValue('Voltage'),
			posTop: "18em",
			posLeft: "26em",
			warning: checkWarning('Voltage',parameterValue('Voltage'))
		},{
			name: 'Frequency',
			value: parameterValue('Frequency'),
			posTop: "18em",
			posLeft: "10em",
			warning: checkWarning('Frequency',parameterValue('Frequency'))
		}];
	});

	$scope.gensetImpParams = [{
		name: 'Engine Speed', //1 - ATTR_ID
		value: '1500 RPM',
		posTop: "10em",
		posLeft: "1em",
		warning: false
	},{
		name: 'Crankcase Pressure', //4
		value: '800 PSI',
		posTop: "7em",
		posLeft: "26em",
		warning: false
	},{
		name: 'Fuel Consumption Rate', //3
		value: '476 L/hr',
		posTop: "3em",
		posLeft: "15em",
		warning: false
	},{
		name: 'Surface Temperature', //2
		value: '42 C',
		posTop: "11em",
		posLeft: "21em",
		warning: false
	}];

	time = moment($.now()).format("DD/MM/YYYY HH:mm");
	$scope.chartParams.subtitle="Last Updated at "+time;

	var checkWarning=function(name,value){
		for(var parameter=0;parameter<threshold.length;parameter++){
			var secondIndex=value.indexOf(' ');
			if(secondIndex==-1)
				secondIndex=value.length;
			value=value.substring(0,secondIndex);
			
			valueInNumber=parseFloat(value);
			if(name.toLowerCase()==threshold[parameter].SPEC_DESC.toLowerCase()){
				if(valueInNumber>parseFloat(threshold[parameter].MAX_VALUE)||parseFloat(valueInNumber<threshold[parameter].MIN_VALUE))
					return true;
				else
					return false;
			}
		}

	};
	
	var parameterValue=function(name){
		var flag=false;
		for(var parameter=0;parameter<threshold.length;parameter++){
			if(name.toLowerCase()==threshold[parameter].SPEC_DESC.toLowerCase()){
				flag=true;
				var unit;
				if(threshold[parameter].UOM_QUANTITY_TYPE=='C'){
					unit="°"+threshold[parameter].UOM_QUANTITY_TYPE;
				}
				else
					unit=threshold[parameter].UOM_QUANTITY_TYPE;
				return threshold[parameter].ATTR_VALUE.toFixed(2)+" "+unit;
			}
		}
		if(flag==false){
			return 'NA'
		}
	}	
}).controller('GensetActivityScheduleCtrl',function($scope,GensetService,$timeout,$state,$rootScope){
	$scope.chartParams = {
		title: "Maintenance Activity Checklist",
		subtitle:"Status"
	}
	$scope.type="D";
	setTimeout(function(){
		$('#filterGenset li').click(function(){			
			$("#filterGenset li.active").removeClass('active');
			$(this).addClass('active');
		});
	},10);
	var selectedType;
	 $scope.typeFun=function(type){
	 	selectedType=type;
		
				fetchActivityChecklistData();			
			$rootScope.$broadcast('highlightType',type);
			

	};	

	gensetCheckListInterval = setInterval(function(){
		fetchActivityChecklistData();		
		}, 1000*60);		
	intervalsList.push(gensetCheckListInterval);

	function fetchActivityChecklistData(){
		GensetService.getActivityChecklist($state.params.id,selectedType).then(function(data){
			
			$scope.tableData=data;	
			
			},function(err){
				console.log(err);
			});
	}
	$scope.tableData = [];
	
	// to get Activity checklist data from DB
	$scope.typeFun('DM');
	$scope.UpdateStatus=function(index){
		bootbox.confirm("Do you want to close the activity?", function(result) {
		
			if(result==true){

				var userId=$scope.user.Id;
				//update closing date and last_update_user_id
				GensetService.updateActivityStatus($scope.tableData[index].ACTIVITY_ID,userId).then(function(data){
					$scope.tableData[index].STATUS=1;
				},function(err){
					console.log(err);
				});

				//update closing date in eqip maint table   
			  	GensetService.updateEquipMaintClosingDate($scope.tableData[index].ACTIVITY_ID).then(function(data){
			  	},function(err){
			  		console.log(err);
			  	});
				
				//log event in event table
				GensetService.updateEventLog($scope.tableData[index].ACTIVITY_ID,$state.params.id,$scope.tableData[index].ACTIVITY_DESC).then(function(data){			
				},function(err){
					console.log(err)
				});
				//refresh maint and activity table on ui
				fetchActivityChecklistData();
				$rootScope.$broadcast('refreshMainSch','');
				//If all the status are closed, save a common comment
				GensetService.getActivityChecklist($state.params.id,selectedType).then(function(data){
					var dataLength=data.length;
					var statusAll=1;
					for(var check=0;check<dataLength;check++){
						if(data[check].STATUS==0){
							statusAll=0;
							break;
						}
					}
					// if all the checklists are closed, log a common comment
					if(statusAll==1){
						bootbox.prompt("Please enter comment", function(result) {    
		            
						  if (result !== undefined && result!=null &&result.length!=0) {  
						  //update comment in eqip maint table
						  	GensetService.updateCheckListComment($scope.tableData[index].ACTIVITY_ID,result).then(function(data){
						  	$rootScope.$broadcast('refreshMainSch','');
						  	},function(err){
						  		console.log(err);
						  	});
		                         
						  } 
						});
					}
			},function(err){
				console.log(err);
			});	


			}
			}); 
	}
})
.controller('gensetIncLogController',function($scope,$rootScope,$state,MainService){
	
	$scope.chartParams = {
		title : "Alarm Log"
	};
	$scope.gensetIncLog=[];
	$scope.allClosed = true;
	$scope.currInc = -1;
	
	$scope.getData = function(){
		MainService.getIncidentDetails('genset',$state.params.id).then(function(data){
			if(data!=undefined && data != null && data.constructor == Array && data.length != 0){
				$scope.gensetIncLog = data.filter(function(value){
					return value.INCIDENT_STATUS==0?true:false;
				});
				$scope.allClosed = MainService.closeAllIncidents($scope.gensetIncLog);
			}
		},function(data){
			console.log(data.ErrorMessage);		
		});
	}
	
	$scope.getData();
	gensetIncLogInterval = setInterval(function(){
		$scope.getData();
	},30000);
	
	intervalsList.push(gensetIncLogInterval);
	
	$scope.openModal = function(option,index){
		$scope.currInc = index;
		$rootScope.$broadcast('openGensetModal',[option,index]);
	}
	
	$rootScope.$on('saveGensetIncident',function(event,status,indexVal){
		$scope.gensetIncLog[indexVal].INCIDENT_STATUS = status;
		$scope.allClosed = MainService.closeAllIncidents($scope.gensetIncLog);
	});

	/*$scope.allClosedIncidents = function(){
		if($scope.gensetIncLog.length==0)
			return true;
		else if($scope.gensetIncLog.filter(function(value){return value.INCIDENT_STATUS==0}).length==0)
			return true;
		else
			return false;
	}*/
	
}).controller('gensetEventLogController',function($scope,$state,$rootScope,MainService){
	$scope.chartParams = {
		title: "Event Feed",
		subtitle:"Last 10",
		linkEnabled: true,
		linkTitle: "View Alarms",
		modalId: '#gensetModal',
		currentView: 'incidentLog'
	}
	$scope.openModal = function(currentView){
		$rootScope.$broadcast('openGensetModalView',currentView);
	}
	$scope.tableData = [];
	
	$scope.getData = function(){
		MainService.getEventDetails('genset',$state.params.id).then(function(data){
			$scope.tableData = data;
		},function(data){
			console.log(data.ErrorMessage);
		});
	}
	$scope.getData();
	gensetEventLogInterval = setInterval(function(){
		$scope.getData();
	},30000);
	
	intervalsList.push(gensetEventLogInterval);
	
})
.controller('EngineCoolantTempCtrl', function($scope, $timeout,$rootScope) {
	$scope.chartParams = {
	title:'Coolant Temperature',
	subtitle:"LAST UPDATED AT ",
	modalEnabled:false
	};	
	$scope.textToInsert = "";
		
	$scope.$on('gensetParametersData',function(event,data){				
		for(var spect=0;spect<data.length;spect++){
			if($scope.chartParams.title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				$scope.chartParams.title=data[spect].SPEC_DESC+" (°"+data[spect].UOM_QUANTITY_TYPE+")";
				$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
				$scope.textToInsert=(data[spect].ATTR_VALUE).toFixed(2);
				$scope.thresholdValue=" Min: "+data[spect].MIN_VALUE+", Max: "+data[spect].MAX_VALUE;
				break;
				}
		}

		$rootScope.$broadcast('updateChart','');
	});
	
	
		
}).controller('EngineExhaustTempCtrl', function($scope,  $timeout,$rootScope) {
	$scope.chartParams = {
		title : "Exhaust Temperature",
		subtitle:"LAST UPDATED AT ",
		modalEnabled:false
	}
	$scope.textToInsert = "";
	
	$scope.$on('gensetParametersData',function(event,data){			
			for(var spect=0;spect<data.length;spect++){
			if($scope.chartParams.title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				$scope.chartParams.title=data[spect].SPEC_DESC+" (°"+data[spect].UOM_QUANTITY_TYPE+")";
				$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
				$scope.textToInsert=(data[spect].ATTR_VALUE).toFixed(2);
				$scope.thresholdValue=" Min: "+data[spect].MIN_VALUE+", Max: "+data[spect].MAX_VALUE;
				break;
				}
		}
		$rootScope.$broadcast('updateChart','');
	});	
})
.controller('BattVoltageCtrl', function($scope,$timeout,$rootScope) {
	$scope.chartParams = {
		title : "Battery Voltage",
		subtitle:"LAST UPDATED AT ",
		modalEnabled:false
	}
		
	$scope.config = {
		width: "100%",
		height: "100",
		sidefont: "10",
		middlefont: "22",
		id: "svg2",
		min: 0,
		max: 0
	}

	//$scope.middleData="75";
	/*$scope.min=0;
	$scope.max=0;*/

	$scope.$on('gensetParametersData',function(event,data){			
			for(var spect=0;spect<data.length;spect++){
			if($scope.chartParams.title.toString().toLowerCase() == data[spect].SPEC_DESC.toLowerCase()){
				$scope.chartParams.title=data[spect].SPEC_DESC+" ("+data[spect].UOM_QUANTITY_TYPE+")";
				$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
				$scope.middleData=data[spect].ATTR_VALUE;
				$scope.thresholdValueMin="Min: "+data[spect].MIN_VALUE;
				$scope.config.min=data[spect].MIN_VALUE;
				$scope.thresholdValueMax="Max: "+data[spect].MAX_VALUE;
				$scope.config.max=data[spect].MAX_VALUE;
				break;
				}
		}
		//$rootScope.$broadcast('updateChartRadial',[min,max]);
	});
	
}).controller('GenFuelConsumptionCtrl',
function($scope,$timeout,$rootScope) {
	$scope.chartParams = {
			title: "Fuel Consumption Rate",
			subtitle:"LAST UPDATED AT ",
		modalEnabled:false
		};
	$scope.chartMargin = {
			left: 50,
			right: 30,
			bottom: 30,
			top: 0
	}
	$scope.yAxisLabelDistance = -15;
	$scope.xAxisLabelDistance = -15;
	
	$scope.yAxisLabel = "Litres";
	$scope.xAxisLabel = "Time";
	
	//$scope.tickValues = [0,1,2,3,4,5,6,7,8,9];
	
	$scope.storeValues = [];
	
	$scope.chartData = [{
		"values": [],
		"key": "Fuel Consumption Rate",
		"color": "rgb(184, 135, 173)"
	},{
		"values": [],
		"key": "Min",
		"color": "rgb(255,100,100)",
		 "classed": 'dashed'
	},{
		"values": [],
		"key": "Max",
		"color": "rgb(255,100,100)",
		 "classed": 'dashed'
	}];
	
	
	$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
	

	var title=$scope.chartParams.title;
	$scope.$on('gensetParametersData',function(event,data){	
			var noOfTimeStampsToshow=-1;
			var initialNoOfTimeStamps=9;
			var timeStamps=[];
			var values=[];
			var minValue=[];
			var maxValue=[];
			var flag=0;
			for(var spect=0;spect<data.length;spect++){
			if(title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				if(flag==0){
					$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
					flag++;
				}				
				$scope.chartData[0].key=data[spect].SPEC_DESC;
				var time=moment(data[spect].MEASURED_DATE).format("HH:mm:ss");
				timeStamps.push(time);
				min=data[spect].MIN_VALUE;
				max=data[spect].MAX_VALUE;
				minValue.push([initialNoOfTimeStamps,min]);
				maxValue.push([initialNoOfTimeStamps,max]);
				values.push([initialNoOfTimeStamps,parseFloat(data[spect].ATTR_VALUE)]);				
				initialNoOfTimeStamps--;
				if(initialNoOfTimeStamps==noOfTimeStampsToshow){
					$scope.chartParams.title=data[spect].SPEC_DESC+" ("+data[spect].UOM_QUANTITY_TYPE+")";	
					break;		
				}		
					
				}
		}
		$scope.storeValues=timeStamps.sort();
		$scope.chartData[0].values=values;
		$scope.chartData[1].values=minValue;	
		$scope.chartData[2].values=maxValue;	
		$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
		$rootScope.$broadcast('updateLineChart','gasLine');	
	});
	$scope.$on('redrawGensetCharts',function(event,mess){
		setTimeout(function(){
			$rootScope.$broadcast('updateLineChart','gasLine');	
		},10);
	});
	
	$scope.tooltipContentFunction = function(){		
		return function(key,y,e,graph){

			return '<p>'+key+'</p>'+
				   '<p>'+y+'</p>';
		}
	}
	
	$scope.xAxisTickFormatFunction = function(){
		return function(d){
			return $scope.storeValues[d];
		}
	}
	
	$scope.colorFunction = function(){
		return function(d,i){
			return "rgb(1, 184, 170)";
		}
	}
	
}).controller('GenEngineOilPressureCtrl', function($scope,$timeout,$rootScope) {
	
$scope.chartParams = {
			title: "Filtered Engine Oil Pressure",
			subtitle:"LAST UPDATED AT ",
		modalEnabled:false
		};
	$scope.chartMargin = {
			left: 50,
			right: 30,
			bottom: 30,
			top: 0
	}
	$scope.yAxisLabelDistance = -15;
	$scope.xAxisLabelDistance = -15;
	$scope.yAxisLabel = "Pressure";
	$scope.xAxisLabel = "Time";
	
	//$scope.tickValues = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59]
	
	//var timeRange = ['12:00 AM','12:01 AM','12:02 AM','12:03 AM','12:04 AM','12:05 AM','12:06 AM','12:07 AM','12:08 AM','12:09 AM','12:10 AM','12:01 AM','12:02 AM','12:03 AM','12:04 AM','12:05 AM','12:06 AM','12:07 AM','12:08 AM','12:09 AM','12:10 AM','12:01 AM','12:02 AM','12:03 AM','12:04 AM','12:05 AM','12:06 AM','12:07 AM','12:08 AM','12:09 AM','12:10 AM','12:01 AM','12:02 AM','12:03 AM','12:04 AM','12:05 AM','12:06 AM','12:07 AM','12:08 AM','12:09 AM','12:10 AM','12:01 AM','12:02 AM','12:03 AM','12:04 AM','12:05 AM','12:06 AM','12:07 AM','12:08 AM','12:09 AM','01:00 PM'];
	$scope.storeValues = [];
	
	$scope.chartData = [{
		"values": [ ],
		"key": "Fuel Consumption Rate",
		"color": "rgb(1, 184, 170)"
	},{
		"values": [ ],
		"key": "Min",
		"color": "rgb(255,100,100)",
		 "classed": 'dashed'
	},{
		"values": [ ],
		"key": "Max",
		"color": "rgb(255,100,100)",
		 "classed": 'dashed'
	}];
	
	
	$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];

	
	//to get threshold values
	var min=0;
	var max=0;
	var title=$scope.chartParams.title;
		$scope.$on('gensetParametersData',function(event,data){	
			var noOfTimeStampsToshow=-1;
			var initialNoOfTimeStamps=9;
			var timeStamps=[];
			var values=[];
			var maxValue=[];
			var minValue=[];
			var flag=0;
			for(var spect=0;spect<data.length;spect++){
			if(title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				if(flag==0){

					$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
					flag++;
				}				
				$scope.chartData[0].key=data[spect].SPEC_DESC;
				var time=moment(data[spect].MEASURED_DATE).format("HH:mm:ss");
				timeStamps.push(time);
				min=data[spect].MIN_VALUE;
				max=data[spect].MAX_VALUE;
				minValue.push([initialNoOfTimeStamps,min]);
				maxValue.push([initialNoOfTimeStamps,max]);
				values.push([initialNoOfTimeStamps,parseFloat(data[spect].ATTR_VALUE)]);				
				initialNoOfTimeStamps--;
				if(initialNoOfTimeStamps==noOfTimeStampsToshow){
					$scope.chartParams.title=data[spect].SPEC_DESC+" ("+data[spect].UOM_QUANTITY_TYPE+")";	
					break;		
				}		
					
				}
		}
		$scope.storeValues=timeStamps.sort();
		$scope.chartData[0].values=values;
		$scope.chartData[1].values=minValue;	
		$scope.chartData[2].values=maxValue;
		$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
		$rootScope.$broadcast('updateLineChart','oilFlowLine');	
	});
	
	$scope.$on('redrawGensetCharts',function(event,mess){
		setTimeout(function(){
			$rootScope.$broadcast('updateLineChart','oilFlowLine');	
		},10);
	});
	$scope.tooltipContentFunction = function(){		
		return function(key,y,e,graph){

			return '<p>'+key+'</p>'+
				   '<p>'+y+'</p>';
		}
	}
	
	$scope.xAxisTickFormatFunction = function(){
		return function(d){
			return $scope.storeValues[d];
		}
	}
	
	$scope.colorFunction = function(){
		return function(d,i){
			return "rgb(1, 184, 170)";
		}
	}
	
}).controller('EngineRPMCtrl', function($scope,$timeout,$rootScope) {
	$scope.chartParams = {
		title : "Engine Speed",
		subtitle:"LAST UPDATED AT ",
		modalEnabled:false
	}
	$scope.config = {
		width: "100%",
		height: "100",
		sidefont: "10",
		middlefont: "22",
		id: "svg1",
		min: 0,
		max: 0
	}

	//$scope.middleData="75";
	/*$scope.min=0;
	$scope.max=0;*/

	$scope.$on('gensetParametersData',function(event,data){	
		
			for(var spect=0;spect<data.length;spect++){
			if($scope.chartParams.title.toString().toLowerCase() == data[spect].SPEC_DESC.toLowerCase()){
				$scope.chartParams.title=data[spect].SPEC_DESC+" ("+data[spect].UOM_QUANTITY_TYPE+")";
				$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
				$scope.middleData=data[spect].ATTR_VALUE;
				$scope.thresholdValueMin="Min: "+data[spect].MIN_VALUE;
				$scope.config.min=data[spect].MIN_VALUE;
				$scope.thresholdValueMax="Max: "+data[spect].MAX_VALUE;
				$scope.config.max=data[spect].MAX_VALUE;
				break;
				}
		}
		//$rootScope.$broadcast('updateChartRadial',[min,max]);
	});
	
	  // $scope.value = 75;
        // $scope.upperLimit = 150;
        // $scope.lowerLimit = 0;
        // $scope.unit = "kW";
        // $scope.precision = 2;
        // $scope.ranges = [
            // {
                // min: 0,
                // max: 70,
                // color: 'rgb(253, 129, 126)'	
            // },
            // {
                // min: 70,
                // max: 120,
                // color: '#8DCA2F'
            // },
            // {
                // min: 120,
                // max: 150,
                // color: 'rgb(253, 129, 126)'
            // }
        // ];

        // function update() {
            // $timeout(function() {
                // $scope.value=$scope.value + 25;                
               // // update();
            // }, 1000);
        // }
        // update();
	
}).controller('GenOperatingHoursCtrl', function($scope,$timeout,$rootScope) {
	$scope.chartParams = {
		title : "Engine Operating Hours",
		subtitle:"LAST UPDATED AT ",
		modalEnabled:false
	}
	
	$scope.textToInsert = "";
	$scope.$on('gensetParametersData',function(event,data){			
			for(var spect=0;spect<data.length;spect++){
			if($scope.chartParams.title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				$scope.chartParams.title=data[spect].SPEC_DESC+" ("+data[spect].UOM_QUANTITY_TYPE+")";
				$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
				$scope.textToInsert=(data[spect].ATTR_VALUE).toFixed(2);
				//$scope.thresholdValue=" Min: "+data[spect].MIN_VALUE+", Max: "+data[spect].MAX_VALUE;
				break;
				}
		}
		$rootScope.$broadcast('updateChart','');
	});
	
	
}).controller('GenVoltCtrl', function($scope,$timeout,$rootScope) {
	$scope.chartParams = {
		title : "Voltage",
		subtitle:"LAST UPDATED AT ",
		modalEnabled:false
	}
	$scope.config = {
		width: "100%",
		height: "100",
		sidefont: "10",
		middlefont: "22",
		id: "volt",
		min: 0,
		max: 0
	}

	//$scope.middleData="75";
	/*$scope.min=0;
	$scope.max=0;*/

	$scope.$on('gensetParametersData',function(event,data){			
			for(var spect=0;spect<data.length;spect++){
			if($scope.chartParams.title.toString().toLowerCase() == data[spect].SPEC_DESC.toLowerCase()){
				$scope.chartParams.title=data[spect].SPEC_DESC+" ("+data[spect].UOM_QUANTITY_TYPE+")";
				$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
				$scope.middleData=data[spect].ATTR_VALUE;
				$scope.thresholdValueMin="Min: "+data[spect].MIN_VALUE;
				$scope.config.min=data[spect].MIN_VALUE;
				$scope.thresholdValueMax="Max: "+data[spect].MAX_VALUE;
				$scope.config.max=data[spect].MAX_VALUE;
				break;
				}
		}
		//$rootScope.$broadcast('updateChartRadial',[min,max]);
	});
	
	
}).controller('GenOperatingFrequencyCtrl', function($scope,$timeout,$rootScope) {
	$scope.chartParams = {
		title : "Frequency",
		subtitle:"LAST UPDATED AT ",
		modalEnabled:false
	}
	$scope.textToInsert = "";
	$scope.$on('gensetParametersData',function(event,data){			
			for(var spect=0;spect<data.length;spect++){
			if($scope.chartParams.title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				$scope.chartParams.title=data[spect].SPEC_DESC+" ("+data[spect].UOM_QUANTITY_TYPE+")";
				$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
				$scope.textToInsert=(data[spect].ATTR_VALUE).toFixed(2);
				$scope.thresholdValue=" Min: "+data[spect].MIN_VALUE+", Max: "+data[spect].MAX_VALUE;
				break;
				}
		}
		$rootScope.$broadcast('updateChart','');
	});
	
	
}).controller('GenCrankcasePressureCtrl',function($scope,$timeout,$rootScope){

	$scope.chartParams = {
		title: "Crankcase Pressure",
		subtitle:"LAST UPDATED AT ",
		modalEnabled:false
	};
	$scope.chartMargin = {
			left: 50,
			right: 30,
			bottom: 30,
			top: 0
	}
	$scope.yAxisLabelDistance = -15;
	$scope.xAxisLabelDistance = -15;
	$scope.yAxisLabel = "Pressure";
	$scope.xAxisLabel = "Time";

	$scope.storeValues = [];
	
	$scope.chartData = [{
		"values": [ ],
		"key": "Fuel Consumption Rate",
		"color": "rgb(184, 135, 173)"
	},{
		"values": [ ],
		"key": "Min",
		"color": "rgb(255,100,100)",
		 "classed": 'dashed'
	},{
		"values": [ ],
		"key": "Max",
		"color": "rgb(255,100,100)",
		 "classed": 'dashed'
	}];
	
	var title=$scope.chartParams.title;
	$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];

	$scope.$on('gensetParametersData',function(event,data){	
			var noOfTimeStampsToshow=-1;
			var initialNoOfTimeStamps=9;
			var timeStamps=[];
			var values=[];
			var minValue=[];
			var maxValue=[];
			var flag=0;
			for(var spect=0;spect<data.length;spect++){
			if(title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				if(flag==0){

					$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
					flag++;
				}				
				$scope.chartData[0].key=data[spect].SPEC_DESC;
				var time=moment(data[spect].MEASURED_DATE).format("HH:mm:ss");
				timeStamps.push(time);
				min=data[spect].MIN_VALUE;
				max=data[spect].MAX_VALUE;
				minValue.push([initialNoOfTimeStamps,min]);
				maxValue.push([initialNoOfTimeStamps,max]);
				values.push([initialNoOfTimeStamps,parseFloat(data[spect].ATTR_VALUE)]);				
				initialNoOfTimeStamps--;
				if(initialNoOfTimeStamps==noOfTimeStampsToshow){
					$scope.chartParams.title=data[spect].SPEC_DESC+" ("+data[spect].UOM_QUANTITY_TYPE+")";	
					break;		
				}		
					
				}
		}
		$scope.storeValues=timeStamps.sort();
		$scope.chartData[0].values=values;
		$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
		$scope.chartData[1].values=minValue;	
		$scope.chartData[2].values=maxValue;	

		setTimeout(function() {
			$rootScope.$broadcast('updateLineChart','engineoilPressureLine');
		}, 10);
			
	});
	
	$scope.$on('redrawGensetCharts',function(event,mess){
		$rootScope.$broadcast('updateLineChart','engineoilPressureLine');
	});
	
		$scope.tooltipContentFunction = function(){		
		return function(key,y,e,graph){

			return '<p>'+key+'</p>'+
				   '<p>'+y+'</p>';
		}
	}
	
	$scope.xAxisTickFormatFunction = function(){
		return function(d){
			return $scope.storeValues[d];
		}
	}
	
	$scope.colorFunction = function(){
		return function(d,i){
			return "rgb(1, 184, 170)";
		}
	}

}).controller('GenActivePowerCtrl',function($scope,$timeout,$rootScope){

	$scope.chartParams = {
		title: "Active Power",
		subtitle:"LAST UPDATED AT ",
		modalEnabled:false
	};
	$scope.chartMargin = {
			left: 50,
			right: 30,
			bottom: 30,
			top: 0
	}
	$scope.yAxisLabelDistance = -15;
	$scope.xAxisLabelDistance = -15;
	$scope.yAxisLabel = "kVA";
	$scope.xAxisLabel = "Time";
	// $scope.tickValues = [0,1,2,3,4];
	
	// $scope.tickValues = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29];
	
	$scope.storeValues = [];
	
	$scope.chartData = [{
		"values": [ ],
		"key": "Fuel Consumption Rate",
		"color": "rgb(184, 135, 173)"
	},{
		"values": [ ],
		"key": "Min",
		"color": "rgb(255,100,100)",
		 "classed": 'dashed'
	},{
		"values": [ ],
		"key": "Max",
		"color": "rgb(255,100,100)",
		 "classed": 'dashed'
	}];
	
	var title=$scope.chartParams.title;
	$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];

	$scope.$on('gensetParametersData',function(event,data){	
			var noOfTimeStampsToshow=-1;
			var initialNoOfTimeStamps=9;
			var timeStamps=[];
			var values=[];
			var minValue=[];
			var maxValue=[];
			var flag=0;
			for(var spect=0;spect<data.length;spect++){
			if(title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				if(flag==0){

					$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
					flag++;
				}				
				$scope.chartData[0].key=data[spect].SPEC_DESC;
				var time=moment(data[spect].MEASURED_DATE).format("HH:mm:ss");
				timeStamps.push(time);
				min=data[spect].MIN_VALUE;
				max=data[spect].MAX_VALUE;
				minValue.push([initialNoOfTimeStamps,min]);
				maxValue.push([initialNoOfTimeStamps,max]);
				values.push([initialNoOfTimeStamps,parseFloat(data[spect].ATTR_VALUE)]);				
				initialNoOfTimeStamps--;
				if(initialNoOfTimeStamps==noOfTimeStampsToshow){
					$scope.chartParams.title=data[spect].SPEC_DESC+" ("+data[spect].UOM_QUANTITY_TYPE+")";	
					break;		
				}		
					
				}
		}
		$scope.storeValues=timeStamps.sort();
		$scope.chartData[0].values=values.sort();
		$scope.chartData[1].values=minValue;	
		$scope.chartData[2].values=maxValue;	
		$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
		$rootScope.$broadcast('updateLineChart','engineActivePowerLine');	
	});
	
	$scope.$on('redrawGensetCharts',function(event,mess){
		setTimeout(function(){
			$rootScope.$broadcast('updateLineChart','engineActivePowerLine');	
		},10);
	});
		$scope.tooltipContentFunction = function(){		
		return function(key,y,e,graph){

			return '<p>'+key+'</p>'+
				   '<p>'+y+'</p>';
		}
	}
	
	$scope.xAxisTickFormatFunction = function(){
		return function(d){
			return $scope.storeValues[d];
		}
	}
	
	$scope.colorFunction = function(){
		return function(d,i){
			return "rgb(1, 184, 170)";
		}
	}

})
.controller('PowerFactorCtrl',function($scope,$timeout,$rootScope){
	$scope.chartParams = {
		title : "Power Factor",
		subtitle:"LAST UPDATED AT ",
		modalEnabled:false
	}
	$scope.config = {
		width: "100%",
		height: "100",
		sidefont: "10",
		middlefont: "22",
		id: "svgFilteredFuel",
		min: 0,
		max: 0
	}

	//$scope.middleData="75";
	/*$scope.min=0;
	$scope.max=0;*/

	$scope.$on('gensetParametersData',function(event,data){			
			for(var spect=0;spect<data.length;spect++){
			if($scope.chartParams.title.toString().toLowerCase() == data[spect].SPEC_DESC.toLowerCase()){
				$scope.chartParams.title=data[spect].SPEC_DESC+" ("+(data[spect].UOM_QUANTITY_TYPE==''?'-':data[spect].UOM_QUANTITY_TYPE)+")";
				$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
				$scope.middleData=data[spect].ATTR_VALUE;
				$scope.thresholdValueMin="Min: "+data[spect].MIN_VALUE;
				$scope.config.min=data[spect].MIN_VALUE;
				$scope.thresholdValueMax="Max: "+data[spect].MAX_VALUE;
				$scope.config.max=data[spect].MAX_VALUE;
				break;
				}
		}
		//$rootScope.$broadcast('updateChartRadial',[min,max]);
	});
	
}).controller('GensetMaintenanceCycleCtrl',function($scope,$rootScope,GensetService,$state){
		$scope.chartParams = {
			title : "Maintenance Schedule",
			subtitle : "Last & Upcoming"
		};
		
		$scope.tableHeadData=[{col1:'Maintenance Type','col2':'Last',col3:'Upcoming',col4:'Comment'}];
				
		$scope.tableData=[];
		$scope.rcvHigh="DM";
		
		$rootScope.$on('highlightType',function(event, value){
			
			$scope.rcvHigh=value;
		});
		
		$rootScope.$on('refreshMainSch',function(event,mess){
				fetchMaintenanceScheduleData();
		});

		//to get all the maintenance data 	
		fetchMaintenanceScheduleData();

		gensetMaintenanceInterval = setInterval(function(){
		fetchMaintenanceScheduleData();		
		}, 1000*60);		
		intervalsList.push(gensetMaintenanceInterval);

		function fetchMaintenanceScheduleData(){
			GensetService.getMaintenanceScheduleData($state.params.id).then(function(data){
			
			$scope.tableData=[];
			for(var maint=0;maint<data.length;maint++){
				var type;
				var order;
				if(data[maint].Type=="DM"){
					type="Daily (DM)";
					order=0;
				}else if(data[maint].Type=="WM"){
					type="Weekly (WM)";
					order=1;
				}else if(data[maint].Type=="MM"){
					type="Monthly (MM)";
					order=2;
				}else if(data[maint].Type=="QM"){
					type="Quarterly (QM)";
					order=3;
				}else if(data[maint].Type=="HYM"){
					type="Half Yearly (HYM)"
					order=4;
				}else if(data[maint].Type=="YM"){
					type="Yearly (YM)"
					order=5;
				}
				var last;
				var next;
				if(data[maint].last_1!=null){
					last=moment(data[maint].last_1).format("DD/MM/YYYY HH:mm");
				}
				else{
					last="-";
				}
				if(data[maint].next_1!=null){
					next=moment(data[maint].next_1).format("DD/MM/YYYY HH:mm");
				}
				else{
					next="-";
				}
				
				var REMARK="";
				if(data[maint].REMARK==null||data[maint].REMARK.length==0){
					REMARK="-";
				}
				else
					REMARK=data[maint].REMARK;
				jsonObject={"type":type, "last":last, "next":next, "order":order,'high':data[maint].Type,"Comment":REMARK};
				$scope.tableData.push(jsonObject);
				
			}
			
			$scope.tableData.sort(function(a,b){
				return a.order-b.order;
			})

			
		},function(err){
			console.log(err.error_message);
		});
		}	
				

}).controller('GensetMaintenanceBreakdownCtrl',function($scope,GensetService,$state,$rootScope){
	$scope.chartParams = {
			title : "Planned Vs Unplanned Summary",
			subtitle : "Last 6 Months",
			linkTitle:"Maintenance History",
			linkEnabled:true,						
			currentView: 'maintenanceHistory'
		}
		$scope.openModal = function(currentView){
			$rootScope.$broadcast('openGensetModalView',currentView);
		}
		var months=[{mon:"Jan",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Feb",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Mar",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Apr",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"May",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Jun",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Jul",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Aug",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Sep",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Oct",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Nov",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Dec",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''}];
	// to get MaintenanceBreakdownSummary
	$scope.monthlyData=[];
	GensetService.getMaintenanceBreakdownSummary($state.params.id).then(function(data){

			if(data!=undefined && data.length!=0){
				for(var month=0;month<data.length;month++){
			if(data[month].Type.toLowerCase()=="mm"){
			months[new Date(data[month].next_1).getMonth()].visible=true;
			months[new Date(data[month].next_1).getMonth()].backgroundcolor='rgba(1, 184, 170,0.6)';
			months[new Date(data[month].next_1).getMonth()].PM=data[month].REMARK;

			}
			if(data[month].Type.toLowerCase()=="ubd"){
			//months[new Date(data[month].last_1).getMonth()].visibleBD=true;
			//months[new Date(data[month].last_1).getMonth()].backgroundcolor='rgb(253, 129, 126)';
			months[new Date(data[month].last_1).getMonth()].backgroundcolorBD='rgb(254, 150, 102)';
			months[new Date(data[month].last_1).getMonth()].UPM=data[month].REMARK;

			}
			
		}
		var lastMonth=data[0].CurrentMonth-1;
		var last6thMonth=data[0].CurrentMonth-7;
		$scope.monthlyData=[];
		while(last6thMonth<lastMonth){
			$scope.monthlyData.push(months[last6thMonth]);
			last6thMonth++;
		}

			}
		
		
		
		
	},function(err){
		console.log(err);
	});

		
}).controller('GensetMaintenanceHistoryCtrl',function($scope,$timeout,GensetService,$state,$rootScope){
	$scope.chartParams = {
			title : "Maintenance History"
		}

		$scope.tableHeadData=['Planned Date','Activity Date','Type','Assignee','Closed By','Comment'];
		$scope.tableData=[];
		/*$timeout(function(){
		$(".openStatus:contains('Maintenance History')").click(function(){
			GensetService.getMaintenanceHistory($state.params.id).then(function(data){
				$scope.tableData=data;
			},function(err){
				console.log(err);
			})
	});
	},15);*/

		$rootScope.$on('getMaintHist',function(event,mess){
			fetchMaintenanceHistory(mess[0],mess[1]);

		})
		

		function fetchMaintenanceHistory(startDate,endDate){
		
			GensetService.getMaintenanceHistory($state.params.id,startDate,endDate).then(function(data){
				$scope.tableData=data;
		
				},function(err){
				console.log(err);
				});	
		}


	$scope.selectedType="DM";
	$scope.typeFun=function(type){
	
	 	$scope.selectedType=type;

	};
	
	$scope.typeFun($scope.selectedType);

}).controller('GensetModalController',function($scope,$rootScope,MainService,$timeout,GensetService,$state){
	$rootScope.$on('openGensetModal',function(event,mess){
		$scope.equipId = mess[0].RIG_EQUIPMENT_ID;
		$scope.desc = mess[0].INCIDENT_DESCRIPTION;
		$scope.id = mess[0].EQUIP_INCIDENT_ID;
		$scope.status = mess[0].INCIDENT_STATUS+'';
		$scope.currentIndex = mess[1];
		$('#closeIncidentForm').slideDown(300);
	});
	$scope.modalDate="GensetModalCal";
	
	$scope.saveIncident = function(){
		
		if(parseInt($scope.status)==1){
	
			MainService.closeIncident($scope.id).then(function(data){
	
			},function(data){
				console.log(data.ErrorMessage);
			});

			MainService.updateEventLogForIncidents($scope.equipId,$scope.desc).then(function(data){

			},function(err){
				console.log(err.ErrorMessage);
			});
		}
		$('#closeIncidentForm').slideUp(300);
		$rootScope.$broadcast('saveGensetIncident',parseInt($scope.status),$scope.currentIndex);		
	}
	
	$('#gensetModal').on('show.bs.modal',function(){
		$('#closeIncidentForm').hide();
	});
	
	$rootScope.$on('openGensetModalView',function(event,mess){
	
		$scope.currentView = mess;
		if($scope.currentView=="incidentLog"){
			$scope.title="Alarms View";
			$scope.subtitle="";
		}
		else if($scope.currentView=="maintenanceHistory"){
			$scope.title="Maintenance History";
			var startDate="";
			  var endDate="";
			  	var startDate1="";
			  var endDate1="";
			$scope.subtitle="From "+startDate+" to "+endDate;	
			dateRangePickerFnct($scope.modalDate,"down","left");
			
			$timeout(function(){	
				var dateObject=$('#'+$scope.modalDate).data('daterangepicker');
				startDate=moment(dateObject.startDate._d).format('DD/MM/YYYY');
				endDate=moment(dateObject.endDate._d).format('DD/MM/YYYY');
				startDate1=moment(dateObject.startDate._d).utc().format('YYYY/MM/DD');
				endDate1=moment(dateObject.endDate._d).utc().format('YYYY/MM/DD');
				var data=[startDate1,endDate1];
				$rootScope.$broadcast('getMaintHist',data);
				$scope.subtitle="From "+startDate+" to "+endDate;
			$('#'+$scope.modalDate).on('apply.daterangepicker', function(ev, picker) {	
			  startDate=moment(picker.startDate._d).format('DD/MM/YYYY');
			  endDate=moment(picker.endDate._d).format('DD/MM/YYYY');
			  startDate1=moment(dateObject.startDate._d).utc().format('YYYY/MM/DD');
				endDate1=moment(dateObject.endDate._d).utc().format('YYYY/MM/DD');
			   // call miantenance data form db for particulat date
			   var data=[startDate1,endDate1];
			   $rootScope.$broadcast('getMaintHist',data);			   
			   $scope.subtitle="From "+startDate+" to "+endDate;
			   $scope.$digest();

			});	
		
		},50);	

	
		}
		$('#gensetModal').modal('show');
	});
}).controller('gensetSensorGraphsController',function($scope,$state,MainService){
	$scope.chartConfig = [];
	var sensorCharts = [];
	var batchStartId = undefined;
	// $scope.chartConfig = [{
	// 	chartType: 'line',
	// 	margin : {
	// 		left: 50,
	// 		right: 30,
	// 		bottom: 50,
	// 		top: 0
	// 	},
	// 	yAxisLabelDistance : -25,
	// 	yAxisLabel : "Litres",
	// 	xAxisLabel : "Time",
	// 	chartId: 'chart1',
	// 	height: 143
	// },{
	// 	chartType: 'line',
	// 	margin : {
	// 		left: 50,
	// 		right: 30,
	// 		bottom: 50,
	// 		top: 0
	// 	},
	// 	yAxisLabelDistance : -25,
	// 	yAxisLabel : "Litres",
	// 	xAxisLabel : "Time",
	// 	chartId: 'chart2',
	// 	height: 143
	// },{
	// 	chartType: 'line',
	// 	margin : {
	// 		left: 50,
	// 		right: 30,
	// 		bottom: 50,
	// 		top: 0
	// 	},
	// 	yAxisLabelDistance : -25,
	// 	yAxisLabel : "Litres",
	// 	xAxisLabel : "Time",
	// 	chartId: 'chart3',
	// 	height: 143
	// }];

	$scope.widgetConfig = [];
	// $scope.widgetConfig = [{
	// 	title: 'Sensor 1 Status',
	// 	subtitle: 'No alarms'
	// },{
	// 	title: 'Sensor 1 Vibration Curve',
	// 	subtitle: 'No Unit'
	// },{
	// 	title: 'Sensor 2 Status',
	// 	subtitle: 'No alarms'
	// },{
	// 	title: 'Sensor 2 Vibration Curve',
	// 	subtitle: 'No Unit'
	// },{
	// 	title: 'Sensor 3 Status',
	// 	subtitle: 'No alarms'
	// },{
	// 	title: 'Sensor 3 Vibration Curve',
	// 	subtitle: 'No Unit'
	// }];

	$scope.chartData = [];
	// $scope.chartData = [[{
	// 	color: 'red',
	// 	key: 'Vibration Graph 1',
	// 	values: []
	// }],[{
	// 	color: 'blue',
	// 	key: 'Vibration Graph 2',
	// 	values: []
	// }],[{
	// 	color: 'green',
	// 	key: 'Vibration Graph 3',
	// 	values: []
	// }]];

	MainService.getEquipmentSensorStats($state.params.id).then(function(data){
		var uniqueSensors = [];
	
		$.each(data,function(index,value){
			if($.inArray(value.SENSOR_ID,uniqueSensors) == -1){
				uniqueSensors.push(value.SENSOR_ID);
			}
		});
		count = 0;
	
		for(j in uniqueSensors){
			var unit = undefined;
			var param = undefined;
			var sensorName = undefined;
			$scope.chartData.push([{
				color: 'green',
				key: '',
				values : []
			}]);
			for(var i=0;i<data.length;i++){
				if(data[i]['SENSOR_ID'] == uniqueSensors[j]){
					if(unit == undefined){
						console.log(data[i]['SENSOR_ID']);
						unit = data[i]['UOM_NAME'];
					}
					if(param == undefined){
						param = data[i]['ATTR_NAME'];
					}
					if(sensorName == undefined){
						sensorName = data[i]['SENSOR_NAME'];
					}
					$scope.chartData[count][0].values.push([data[i].MEASURED_DATE,data[i].ATTR_VALUE]);
				}
			}

			$scope.chartData[count][0].key = param;

			$scope.widgetConfig.push({
				title: sensorName+' Status',
				subtitle: 'No Alarms'
			});

			$scope.widgetConfig.push({
				title: sensorName+' Vibration Graph',
				subtitle: unit
			});

			$scope.chartConfig.push({
				chartType: 'line',
				margin : {
					left: 50,
					right: 30,
					bottom: 50,
					top: 0
				},
				yAxisLabelDistance : -25,
				yAxisLabel : param,
				xAxisLabel : "Time",
				chartId: 'chart'+count,
				height: 143
			});

			count++;
		}
		
	},function(err){
		console.log(err);
	});

	// $scope.getSensorGraphData = function(){
	// 	MainService.getEquipmentSensorStats($state.params.id,batchStartId).then(function(data){
	// 		var uniqueSensors = [];
	// 		if(data!=undefined && data != null && data.constructor == Array && data.length!=0){
	// 			//console.log(data.length);
	// 			if(data.length < 500){
	// 				clearGraphDataInterval();
	// 			}
	// 			var sortedSensorIds = data.map(function(p){
	// 				return p['MEAS_ATTR_ID'];
	// 			}).sort();

	// 			batchStartId = sortedSensorIds[0];
	// 		}else{
	// 			clearGraphDataInterval();
	// 		}

	// 		$.each(data,function(index,value){
	// 			if($.inArray(value.SENSOR_ID,uniqueSensors) == -1){
	// 				uniqueSensors.push(value.SENSOR_ID);
	// 			}
	// 		});

	// 		for(j in uniqueSensors){
	// 			var unit = undefined;
	// 			var param = undefined;
	// 			var sensorName = undefined;

	// 			if($.inArray(uniqueSensors[j],sensorCharts) != -1){
	// 				var x = sensorCharts.indexOf(uniqueSensors[j]);
	// 				var arr = [];
	// 				for(var i=0;i<data.length;i++){
	// 					if(data[i]['SENSOR_ID'] == uniqueSensors[j]){						
	// 						arr.push([data[i].MEASURED_DATE,data[i].ATTR_VALUE]);
	// 					}
	// 				}
	// 				$scope.chartData[x][0].values = $.merge($scope.chartData[x][0].values,arr); 
	// 			}else{
	// 				$scope.chartData.push([{
	// 					color: 'green',
	// 					key: '',
	// 					values : []
	// 				}]);
	// 				var arr = [];
	// 				for(var i=0;i<data.length;i++){
	// 					if(data[i]['SENSOR_ID'] == uniqueSensors[j]){
	// 						if(!unit)
	// 							unit = data[i]['UOM_NAME'];
	// 						if(!param)
	// 							param = data[i]['ATTR_NAME'];
	// 						if(!sensorName)
	// 							sensorName = data[i]['SENSOR_NAME'];

	// 						arr.push([data[i].MEASURED_DATE,data[i].ATTR_VALUE]);
	// 					}
	// 				}
					
	// 				$scope.chartData[j][0].values = $.merge($scope.chartData[j][0].values,arr);
	// 				$scope.chartData[j][0].key = param;

	// 				$scope.widgetConfig.push({
	// 					title: sensorName+' Status',
	// 					subtitle: 'No Alarms'
	// 				});

	// 				$scope.widgetConfig.push({
	// 					title: sensorName+' Vibration Graph',
	// 					subtitle: unit
	// 				});

	// 				$scope.chartConfig.push({
	// 					chartType: 'line',
	// 					margin : {
	// 						left: 50,
	// 						right: 30,
	// 						bottom: 50,
	// 						top: 0
	// 					},
	// 					yAxisLabelDistance : -25,
	// 					yAxisLabel : param,
	// 					xAxisLabel : "Time",
	// 					chartId: 'chart'+j,
	// 					height: 143,
	// 				});
	// 				sensorCharts.push(uniqueSensors[j]);
	// 			}
	// 		}
	// 	},function(err){
	// 		console.log(err);
	// 	});
	// };
	
	// $scope.getSensorGraphData();

	// var sensorGraphDataInterval = setInterval(function(){
	// 	$scope.getSensorGraphData();
	// },2000);

	// intervalsList.push(sensorGraphDataInterval);

	// var clearGraphDataInterval = function(){
	// 	if(sensorGraphDataInterval!=undefined){
	// 		clearInterval(sensorGraphDataInterval);
	// 	}
	// }
});


function getMax(value){
	if(value!=undefined||value.length!=0){
		var max = 0;
		$.each(value,function(index,value1){
			max = value1[1]>max?value1[1]:max;
		})
		
		return Math.ceil(max+(10.0*max/100));
	}
	else{
		return 500;
	}
		
}

function getMin(value){
	if(value!=undefined||value.length!=0){
		var min = Number.POSITIVE_INFINITY;
		$.each(value,function(index,value1){
			min = value1[1]<min?value1[1]:min;
		})
		
		return Math.floor(min-(10.0*min/100));
	}
	else{
		return -1;
	}
		
}



