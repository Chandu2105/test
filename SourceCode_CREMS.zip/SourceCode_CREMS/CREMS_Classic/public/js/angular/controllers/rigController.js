angular.module('myApp').controller('RigController',function($scope,$rootScope,MainService,$state){
	MainService.hideBreadcrumb(false);
	$rootScope.$broadcast('updateRig',[{'name':$state.params.name,'url':'app.dashboard.rig','params': {id: $state.params.id,name: $state.params.name},'type': 'rig'},'rig']);
	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.dashboard.rig',
		params: {
			id: $state.params.id,
			name: $state.params.name
		}
	}))
}).controller('RigMapCtrl',function($scope,MainService,$state,$window){
	$scope.chartParams = {
		title: "Rig Map"
	}
	
	MainService.getRigCoordinates($state.params.id,'rig').then(function(data){
		if(data != undefined && data != null && data.constructor === Array && data.length > 0){
			MainService.setMapMarkers(data);
		}
	},function(data){
		console.log(data.ErrorMessage);
	});

	MainService.initialiseMap('rigMap');
}).controller('RigActivityLogControl',function($scope,$state,MainService){
	$scope.chartParams = {
		title: "Latest 10 Events"
	}
	$scope.tableData = [];
	
	$scope.getData = function(){
		MainService.getEventDetails('rig',$state.params.id).then(function(data){
			if(data != undefined && data != null && data.constructor === Array && data.length > 0){
				$scope.tableData = data;
			}
		},function(data){
			console.log(data.ErrorMessage);
		});
	}
	
	$scope.getData();
	rigActivityLogInterval = setInterval(function(){
		$scope.getData();
	},1000*30);
	
	intervalsList.push(rigActivityLogInterval);
	
}).controller('RigMaintController',function($scope,$state,MainService){
	$scope.chartParams = {
		title: "Rig Maintenance Information"
	}
	
	$scope.type="D";
	var selectedType = "DM";
	 $scope.typeFun=function(type,event){
	 	selectedType=type;
		fetchRigMaintenanceData();
		$("#filterRigEquipment li.active").removeClass('active');
		angular.element(event.currentTarget).addClass('active');
	};

	fetchRigMaintenanceData();
	
	rigCheckListInterval = setInterval(function(){
		fetchRigMaintenanceData();		
	}, 1000*30);		

	intervalsList.push(rigCheckListInterval);

	function fetchRigMaintenanceData(){
		MainService.getRigMaintenanceData($state.params.id,selectedType).then(function(data){
			if(data != undefined && data != null && data.constructor === Array && data.length > 0){
				$scope.tableData = data;
			}else{
				$scope.tableData=[];
			}
		},function(err){
			console.log(err);
		});
	}
	$scope.tableData=[];
	
	$scope.goModel = function(option){
		MainService.clearArrayIntervals();
		$state.go('app.dashboard.equipment',{id: option.EQUIPMENT_ID,name: option.EQUIPMENT_NAME},{location: false});
	}
}).controller('RigIncidentLogCtrl',function($scope,$rootScope,$state,MainService){
	$scope.tableData=[];
	$scope.allClosed = true;
	$scope.getData = function(){
		MainService.getIncidentDetails('rig',$state.params.id).then(function(data){
			if(data != undefined && data != null && data.constructor === Array && data.length != 0){
				$scope.tableData = data;
				$scope.allClosed = MainService.closeAllIncidents($scope.tableData);
			}else{
				$scope.tableData = [];
			}
		},function(data){
			console.log(data.ErrorMessage);
		});
	}
	
	$scope.getData();
	rigIncidentLogInterval = setInterval(function(){
		$scope.getData();
	},1000*30);
	
	intervalsList.push(rigIncidentLogInterval);
	
	$scope.chartParams = {
		title: "Alarms"
	}
	
	$scope.openModal = function(option,index){
		$rootScope.$broadcast('openRigModal',[option,index]);
	}
	
	$rootScope.$on('saveRigIncident',function(event,mess){
		// $scope.tableData[mess[2]].INCIDENT_STATUS = mess[1];
		// $scope.allClosed = MainService.closeAllIncidents($scope.tableData);
		$scope.getData();
	});
})
.controller('DashboardTableController',function($scope,$state,RigService,MainService){
	$scope.chartParams = {
		title: "Equipment Status"
	}
	$scope.maxList = [];
	
	$scope.getData = function(){
		RigService.getAllRigEquipments($state.params.id).then(function(data){
			if(data!=null && data!=undefined && data.constructor === Array && data.length!=0){
				$scope.generatorList = data.filter(function(val){
					return val.DESCRIPTION.toLowerCase()=='generator'?true:false;
				});
				$scope.compressorList = data.filter(function(val){
					return val.DESCRIPTION.toLowerCase()=='compressor'?true:false;
				});
				$scope.mudPumpList = data.filter(function(val){
					return val.DESCRIPTION.toLowerCase()=='mud pump'?true:false;
				});
				$scope.agitatorList = data.filter(function(val){
					return val.DESCRIPTION.toLowerCase()=='agitator'?true:false;
				});
				$scope.shakerList = data.filter(function(val){
					return val.DESCRIPTION.toLowerCase()=='shaker'?true:false;
				});
				$scope.drawboxList = data.filter(function(val){
					return val.DESCRIPTION.toLowerCase()=='drawworks'?true:false;
				});
				$scope.maxList = [$scope.generatorList,$scope.compressorList,$scope.mudPumpList,$scope.agitatorList,$scope.shakerList,$scope.drawboxList];
				$scope.maxList = $scope.maxList.filter(function(value){
					return value.length == Math.max($scope.generatorList.length,$scope.compressorList.length,$scope.mudPumpList.length,$scope.agitatorList.length,$scope.shakerList.length,$scope.drawboxList.length)?true:false;
				});
			}else{
				$scope.maxList = [];
			}
		},function(data){
			console.log(data.ErrorMessage);
		})
	}
	
	$scope.getData();
	dashboardTableInterval = setInterval(function(){
	
		$scope.getData();
	},1000*30);
	
	intervalsList.push(dashboardTableInterval);
	
	$scope.goNavigate = function(val){
		sessionStorage.setItem('currentRig',$state.params.id);
		MainService.clearArrayIntervals();
		$state.go('app.dashboard.equipment',{id: val.equip_id,name: val.equip_name},{location: false});
	}
}).controller('WellInfoController',function($scope,$state,RigService,MainService){
	$scope.chartParams = {
		title: "Well Information",
		tabEnabled : true
	}
	$scope.tabList = ["Rig Information" , "Well Information"];
	$scope.wellAttributes = [];
	$scope.currTab = 0;
	$scope.wellInfo = [];
	$scope.rigInfo = [];
	
	RigService.getRigWellAttributes($state.params.id).then(function(data){
		if(data != undefined && data != null && data.constructor === Array && data.length != 0){
			$scope.wellInfo = data;
			console.log($scope.wellInfo);
		}else{
			$scope.wellInfo = [];
		}
	},function(data){
		console.log(data.ErrorMessage);
	});
	
	RigService.getRigInfo($state.params.id).then(function(data){
		var rigInfo = ["Rig Name","Owner","Operator","Commission Date","Effective Date"];
		if(data != undefined && data != null && data.constructor === Array && data.length > 0){
			$scope.rigInfo = rigInfo.map(function(x){
				var c = {};
				c.key = x;
				c.value = data[0][x];
				return c;
			});
		}else{
			$scope.rigInfo = [];
		}
	},function(data){
		console.log(data.ErrorMessage);
	})
}).controller('RigModalController',function($scope,$rootScope,MainService){
	$rootScope.$on('openRigModal',function(event,mess){	
		$scope.equipId = mess[0].RIG_EQUIPMENT_ID;
		$scope.desc = mess[0].INCIDENT_DESCRIPTION;
		$scope.action = mess[0].INCIDENT_ASSIGNEE_COMMENT;
		$scope.id = mess[0].EQUIP_INCIDENT_ID;
		$scope.status = mess[0].INCIDENT_STATUS+'';
		$scope.currentIndex = mess[1];
		$('#rigModal').modal('show');
	});
	
	$scope.saveIncident = function(){
		if(parseInt($scope.status)==1){
			if($scope.action == "" || $scope.action == undefined || $scope.action == null){
				$scope.action = "Alarm \""+$scope.desc+"\" closed";
			}
			//$scope.action = $scope.action ? $scope.action : "Alarm \""+$scope.desc+"\" closed";
			MainService.updateIncident($scope.id,$scope.action,$scope.status).then(function(data){
				
			},function(data){
				console.log(data.ErrorMessage);
			});

			MainService.updateEventLogForIncidents($scope.equipId,$scope.desc).then(function(data){

			},function(err){
				console.log(err.ErrorMessage);
			});
		}else if(parseInt($scope.status)==0 && $scope.action != '' && $scope.action != undefined && $scope.action != null){
			MainService.updateIncident($scope.id,$scope.action,$scope.status).then(function(data){
				
			},function(data){
				console.log(data.ErrorMessage);
			});
		}
		$('#rigModal').modal('hide');
		$rootScope.$broadcast('saveRigIncident',[parseInt($scope.status),$scope.currentIndex]);		
	}
});