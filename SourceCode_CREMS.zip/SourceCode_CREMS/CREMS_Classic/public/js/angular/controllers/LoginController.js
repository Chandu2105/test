angular.module('myApp').controller('LoginController',function($scope,$state,MainService){
	
	$scope.username="admin@admin.in";
	$scope.password="admin";
	$scope.role = "";

	$scope.submitForm = function(){
	
		if($scope.username!="" && $scope.password!="" && $scope.role!=""){
			
			MainService.authenticateUser($scope.username,$scope.password,$scope.role).then(function(data){
				if(data.length!=0 && data.errorMessage == undefined){
					switch(data[0].ROLE_ID){
						case 1:
							$scope.$emit('setUser',data[0]);
							$state.go('app.dashboard.area',{id: data[0].RIG_ID,name: data[0].owner},{location: false});
							break;
						case 2:
							$scope.$emit('setUser',data[0]);
							$state.go('app.dashboard.rig',{id: data[0].RIG_ID,name: data[0].Owner},{location: false});
							break;
						case 3:
							var ids = [];
							var eqnames = [];
							$.each(data,function(ind,val){
								ids.push(val.RIG_ID);
								eqnames.push(val.Owner);
							});
							
							var f = {};
							$.extend(true,f,data[0]);
							f.RIG_ID = ids;
							f.Owner = eqnames;
							
							$scope.$emit('setUser',f);
							
							$state.go('app.dashboard.equipment',{id: data[0].RIG_ID,name: data[0]["Owner"]},{location: false});
							// switch(data[0]["Owner"].split(' -')[0].toLowerCase()){
							// 	case 'generator':
							// 		$state.go('app.dashboard.genset',{id: data[0].RIG_ID,name: data[0]["Owner"].split(" ")},{location: false});
							// 		break;
							// 	case 'compressor':
							// 		$state.go('app.dashboard.compressor',{id: data[0].RIG_ID,name: data[0]["Owner"].split(" ")},{location: false});
							// 		break;
							// 	case 'mud pump':
							// 		$state.go('app.dashboard.mudpump',{id: data[0].RIG_ID,name: data[0]["Owner"].split(" ")},{location: false});
							// 		break;
							// 	case 'agitator':
							// 		$state.go('app.dashboard.agitator',{id: data[0].RIG_ID,name: data[0]["Owner"].split(" ")},{location: false});
							// 		break;
							// 	case 'shaker':
							// 		$state.go('app.dashboard.shaker',{id: data[0].RIG_ID,name: data[0]["Owner"].split(" ")},{location: false});
							// 		break;
							// 	case 'drawbox':
							// 		$state.go('app.dashboard.drawbox',{id: data[0].RIG_ID,name: data[0]["Owner"].split(" ")},{location: false});
							// 		break;
							// 	default: 
							// 		var e = "Sorry, credentials do not match any registered user!";
							// 		$scope.$emit('popup',e,'error');
							// 		break;
							// }
							break;
						case 4:
							$scope.$emit('setUser',data[0]);
							$state.go('app.addition.assetmaster',{id: data[0].RIG_ID,name: data[0].Owner},{location: false});
							break;
					}
					//$scope.$emit('popup','Authentication successful!','info');
				}else{
					var e = "Invalid username, password or role!";
					$scope.$emit('popup',e,'error');
				}
			},function(data){
				$scope.error = data.ErrorMessage;
				$scope.$emit('popup',data.ErrorMessage,'error');
			})
		}else{
			var e = 'Please enter all fields!';
			$scope.$emit('popup',e,'error');
		}
		
		//$state.go('app.dashboard.area',{id: 4789,name: 'India'},{location: false});
	}

	$scope.roles = [];

	$scope.getAllRoles = function(){
		MainService.getAllRoles().then(function(data){
			$scope.roles = data;
			$scope.role = 4;
		},function(data){
			console.log(data);
		})
	}
});