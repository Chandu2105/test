var paramPlotArr = {
	"ac": ["Plot All"],
	"ir": [],
	"vac": [],
	"mg": []
};

var counter = 0;

angular.module('myApp').controller('ParamController',function($scope,MainService,$rootScope){
	$scope.getCollectorList = function(){
		if($('#machine').val()!=""){
			MainService.getCollectorsListForMachine($('#machine').val()).then(function(data){
				$scope.collectorList = changeKeys(data);
			},function(data){
				console.log(data.ErrorMessage);
			});
		}
	}
	
	$scope.checkSelected = function(val){
		return $('#'+val).val()==''?true:false;
	}
	
	$scope.getParamPlotList = function(){
		$scope.paramPlotList = paramPlotArr[$('#collector').val()];
	}
	
	MainService.getAllMachinesList().then(function(data){
		$scope.machineList = changeKeys(data);
	},function(data){
		console.log(data.ErrorMessage);
	});
	
	MainService.getAllSensorsList().then(function(data){
		$scope.sensorList = data;
	},function(data){
		console.log(data.ErrorMessage);
	});
	
	$scope.renderGraphs = function(){
		if($('#machine').val() == ""||$('#collector').val() == ""||$('#plotValue').val() == ""||$('#sensor').val() == ""){
			alert("Gotta catch'em all!");
		}else{
			if($('#collector').val()=="ac"){
				//var tim = setInterval(function(){
					var ts = timestampProvider(26);
				
					MainService.getRawSensorData(ts[0],ts[1],$('#sensor').val().split(':').join(''),[$('#collector').val()]).then(function(data){
						counter = counter==0?10:counter+1;
						$rootScope.$broadcast('chartData',data);
					},function(data){
						console.log(data.ErrorMessage);
					});
				//}, 6000);
			}
		}
	}
	
	function timestampProvider(date){
		var returnVal = [];
		var start = new Date();
		minStart=counter==0?0:counter;
		minEnd=minStart==0?10:minStart+1;
		start.setDate(date);
		start.setMonth(6);
		start.setHours(9, minStart, 0, 0);
		returnVal.push(start.getTime());
		start.setHours(9, minEnd, 0, 0);
		returnVal.push(start.getTime());
		return returnVal;
	}
	
	function changeKeys(data){
		var keys = Object.keys(data[0]);
		$.each(keys,function(index,value){
			data = JSON.parse(JSON.stringify(data).split(value).join(value.replace("-","")));
		});
		return data;
	}
	
}).controller('ChartController',function($scope,$rootScope,MainService){
	$scope.chartParams = {
			title: "Accelerometer Readings:"
	};
	
	/*$scope.chartData = [];
	
	$rootScope.$on('chartData',function(event,mess){
		$scope.chartData = mess;
		MainService.callChart("#chart1", $scope.chartData);
	});
	
	function volatileChart(startPrice, volatility, numPoints){
		    var rval =  [];
	        var now =+new Date();
	        numPoints = numPoints || 100;
	        for(var i = 1; i < numPoints; i++) {
	            rval.push({x: now + i * 1000 * 60 * 60 * 24, y: startPrice});
	            var rnd = Math.random();
	            var changePct = 2 * volatility * rnd;
	            if ( changePct > volatility) {
	                changePct -= (2*volatility);
	            }
	            startPrice = startPrice + startPrice * changePct;
	        }
	        return rval;
	}*/
}).controller('XController',function($scope,$rootScope){
	$scope.chartMargin = {
			left: 60,
			right: 60,
			top: 20,
			bottom: 50
		};
		
		$scope.chartData = [{
			"key": "Accelerometer(X-Value)",
			"color": "rgb(1, 184, 170)",
			"values": []
		}];
		
		$scope.xAxisLabel = "Time(s)";
		$scope.yAxisLabel = "Accelerometer(X-Value)";
		$scope.yAxisLabelDistance = 30;
		
		$scope.xValueFunction = function(){
			return function(d){
				return moment(d.datetime,"YYYY-MM-DDTHH:mm:ss.SSSZ").unix()*1000;
			}
		}
		
		$scope.yValueFunction = function(){
			return function(d){
				return d['ac']['x'];
			}
		}
		
		$rootScope.$on('chartData',function(event,mess){
			if(counter!=10){
				$scope.chartData[0].values.splice(0,mess.length);
				$scope.chartData[0].values = $scope.chartData[0].values.concat(mess);
			}else
				$scope.chartData[0].values = mess;
			
			$rootScope.$broadcast('dataChanged',[$scope.chartData,'lineChartX']);
		});
		
		$scope.xAxisTickFormatFunction = function(){
			return function(d,i){
				return d3.time.format('%H:%M:%S')(new Date(d));
			}
		}
		
		$scope.tooltipContentFunction = function(){
			return function(key,x,y,e,graph){
				return '<h3>'+key+'</h3>'+
					   '<p>'+y+' at '+x+'</p>';
			}
		}
}).controller('YController',function($scope,$rootScope){
	$scope.chartMargin = {
			left: 60,
			right: 60,
			top: 20,
			bottom: 50
		};
		
		$scope.chartData = [{
			"key": "Accelerometer(Y-Value)",
			"color": "rgb(254, 150, 102)",
			"values": []
		}];
		
		$scope.xAxisLabel = "Time(s)";
		$scope.yAxisLabel = "Accelerometer(Y-Value)";
		$scope.yAxisLabelDistance = 30;
		
		$scope.xValueFunction = function(){
			return function(d){
				return moment(d.datetime,"YYYY-MM-DDTHH:mm:ss.SSSZ").unix()*1000;
			}
		}
		
		$scope.yValueFunction = function(){
			return function(d){
				return d['ac']['y'];
			}
		}
		
		$rootScope.$on('chartData',function(event,mess){
			if(counter!=10){
				$scope.chartData[0].values.splice(0,mess.length);
				$scope.chartData[0].values = $scope.chartData[0].values.concat(mess);
			}else
				$scope.chartData[0].values = mess;
			
			$rootScope.$broadcast('dataChanged',[$scope.chartData,'lineChartY']);
		});
		
		$scope.xAxisTickFormatFunction = function(){
			return function(d,i){
				return d3.time.format('%H:%M:%S')(new Date(d));
			}
		}
		
		$scope.tooltipContentFunction = function(){
			return function(key,x,y,e,graph){
				return '<h3>'+key+'</h3>'+
					   '<p>'+y+' at '+x+'</p>';
			}
		}
}).controller('ZController',function($scope,$rootScope){
	$scope.chartMargin = {
			left: 60,
			right: 60,
			top: 20,
			bottom: 50
		};
		
		$scope.chartData = [{
			"key": "Accelerometer(Z-Value)",
			"color": "rgb(253, 129, 126)",
			"values": []
		}];
		
		$scope.xAxisLabel = "Time(s)";
		$scope.yAxisLabel = "Accelerometer(Z-Value)";
		$scope.yAxisLabelDistance = 30;
		
		$scope.xValueFunction = function(){
			return function(d){
				return moment(d.datetime,"YYYY-MM-DDTHH:mm:ss.SSSZ").unix()*1000;
			}
		}
		
		$rootScope.$on('chartData',function(event,mess){
			if(counter!=10){
				console.log($scope.chartData[0].values.length);
				$scope.chartData[0].values.splice(0,mess.length);
				$scope.chartData[0].values = $scope.chartData[0].values.concat(mess);
				console.log($scope.chartData[0].values.length);
			}else
				$scope.chartData[0].values = mess;
			
			$rootScope.$broadcast('dataChanged',[$scope.chartData,'lineChartZ']);
		});
		
		$scope.yValueFunction = function(){
			return function(d){
				return d['ac']['z'];
			}
		}
		
		$scope.xAxisTickFormatFunction = function(){
			return function(d,i){
				return d3.time.format('%H:%M:%S')(new Date(d));
			}
		}
		
		$scope.tooltipContentFunction = function(){
			return function(key,x,y,e,graph){
				return '<h3>'+key+'</h3>'+
					   '<p>'+y+' at '+x+'</p>';
			}
		}
});