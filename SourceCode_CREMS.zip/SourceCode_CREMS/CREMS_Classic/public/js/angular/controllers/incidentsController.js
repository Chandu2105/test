
angular.module('myApp').controller('AllIncidentsController',function($scope,$rootScope,MainService,DropDownService,$filter){

	$scope.chartParams = {
		title: "Alarm Log"
	}

	$scope.tableData = [];
	$scope.mainTable = [];
	$scope.pageTable = [];
	$scope.entries = 15;
	$scope.noob = false;

	$scope.allClosed = true;
	
	MainService.hideBreadcrumb(true);
	$rootScope.$broadcast('updateRig',[{'name':'Incidents','url':'app.incidents',type: 'incidents'},'incidents']);

	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.incidents',
		params: null
	}))

	$scope.choices = [];

	$scope.areaOptions = [];
	$scope.rigOptions = [];
	$scope.modelOptions = [];
	$scope.assignOptions = [];
	//AssetOptions means equipment types like generator, mud pump, etc.
	$scope.assetOptions = [];
	$scope.statusOptions = ["","0","1"];
	
	var x = MainService.getDescription().map(function(v){
		return v.value;
	});

	//Setting the equipment types
	$scope.assetOptions = x;

	$scope.getData = function(){
		//Filling up the dropdowns with the choices relevant to current user
		DropDownService.getDropDownMenu($scope.user.ROLE_ID).then(function(data){
			
			var obj = {
				area: $scope.iArea,
				rig: $scope.iRig,
				asset: $scope.iAsset,
				equipment: $scope.iModel,
				status: !$scope.noob || ($scope.iStatus=="")?"":parseInt($scope.iStatus),
				user: $scope.iAssign
			}

			var temp = '';
			
			switch($scope.user.ROLE_ID){
				case 1:
					$scope.choices = data.filter(function(v){
						return v.AREA_ID == $scope.user.RIG_ID;
					});

					$scope.areaOptions = data.filter(function(v){
						return v.AREA_ID == $scope.user.RIG_ID;
					}).map(function(v){
						return v.PREFERRED_NAME;
					}).filter(function(value,index,inputArray){
						return inputArray.indexOf(value) == index;
					});

					obj.area = ($scope.areaOptions[0] != undefined && $scope.areaOptions[0] != null && $scope.areaOptions[0] != '') ? $scope.areaOptions[0] : '';

					$scope.rigOptions = data.filter(function(v){
						return ($.inArray(v.PREFERRED_NAME,$scope.areaOptions) > -1)
						&&
						(($scope.iArea != '' && $scope.iArea != undefined && $scope.iArea != null) ? ($scope.iArea == v.PREFERRED_NAME) : true);
					}).map(function(v){
						return v.RIG_NAME;
					}).filter(function(value,index,inputArray){
						return inputArray.indexOf(value) == index;
					});
					
					//console.log($scope.rigOptions);
					// $scope.assetOptions = data.filter(function(v){
					// 	return $.inArray(v.PREFERRED_NAME,$scope.areaOptions) > -1;
					// }).map(function(v){
					// 	return v.DESCRIPTION;
					// }).filter(function(value,index,inputArray){
					// 	return inputArray.indexOf(value) == index;
					// });

					$scope.modelOptions = data.filter(function(v){
						return ($.inArray(v.PREFERRED_NAME,$scope.areaOptions) > -1)
						&&
						(($scope.iRig != '' && $scope.iRig != undefined && $scope.iRig != null) ? ($scope.iRig == v.RIG_NAME) : true)
						&&
						(($scope.iAsset != '' && $scope.iAsset != undefined && $scope.iAsset != null) ? ($scope.iAsset == v.DESCRIPTION) : true);
					}).map(function(v){
						return v.EQUIPMENT_NAME;
					}).filter(function(value,index,inputArray){
						return inputArray.indexOf(value) == index;
					});

					break;
				case 2:
					$scope.choices = data.filter(function(v){
						return v.RIG_ID == $scope.user.RIG_ID;
					});
					$scope.rigOptions = data.filter(function(v){
						return v.RIG_ID == $scope.user.RIG_ID;
					}).map(function(v){
						return v.RIG_NAME;
					}).filter(function(value,index,inputArray){
						return inputArray.indexOf(value) == index;
					});

					obj.rig = ($scope.rigOptions[0] != undefined && $scope.rigOptions[0] != null && $scope.rigOptions[0] != '') ? $scope.rigOptions[0] : '';

					$scope.areaOptions = data.filter(function(v){
						return $.inArray(v.RIG_NAME,$scope.rigOptions) > -1;
					}).map(function(v){
						return v.PREFERRED_NAME;
					}).filter(function(value,index,inputArray){
						return inputArray.indexOf(value) == index;
					});

					// $scope.modelOptions = data.filter(function(v){
					// 	return $.inArray(v.RIG_NAME,$scope.rigOptions) > -1;
					// }).map(function(v){
					// 	return v.EQUIPMENT_NAME;
					// }).filter(function(value,index,inputArray){
					// 	return inputArray.indexOf(value) == index;
					// });

					$scope.modelOptions = data.filter(function(v){
						return ($.inArray(v.RIG_NAME,$scope.rigOptions) > -1)
						&&
						(($scope.iAsset != '' && $scope.iAsset != undefined && $scope.iAsset != null) ? ($scope.iAsset == v.DESCRIPTION) : true);
					}).map(function(v){
						return v.EQUIPMENT_NAME;
					}).filter(function(value,index,inputArray){
						return inputArray.indexOf(value) == index;
					});
					break;
				case 3:
					
					$scope.choices = data.filter(function(v){
						return ($.inArray(v.EQUIPMENT_ID[0],$scope.user.RIG_ID) > -1)
					});
					
					var t = data.filter(function(v){
						return ($.inArray(v.EQUIPMENT_ID[0],$scope.user.RIG_ID) > -1)
						&&
						(($scope.iAsset != '' && $scope.iAsset != undefined && $scope.iAsset != null) ? ($scope.iAsset == v.DESCRIPTION) : true);
					});

					$scope.modelOptions = t.map(function(v){
						return v.EQUIPMENT_NAME;
					}).filter(function(value,index,inputArray){
						return inputArray.indexOf(value) == index;
					});

					obj.equipment = ($scope.modelOptions[0] != undefined && $scope.modelOptions[0] != null && $scope.modelOptions[0] != '') ? $scope.modelOptions[0] : '';

					$scope.rigOptions = $scope.choices.map(function(v){
						return v.RIG_NAME;
					}).filter(function(value,index,inputArray){
						return inputArray.indexOf(value) == index;
					});

					$scope.areaOptions = $scope.choices.map(function(v){
						return v.PREFERRED_NAME;
					}).filter(function(value,index,inputArray){
						return inputArray.indexOf(value) == index;
					});

					break;
				default:
					break;
			}

			//Getting the incidents
			MainService.getFilteredIncidents(obj).then(function(receivedData){
				if(receivedData != undefined && receivedData != null && receivedData.constructor == Array && receivedData.length != 0){
					
					if(!$scope.noob){
						$scope.iStatus = "";
						$scope.noob = true;
						// $scope.areaOptions = [];
						// $scope.rigOptions = [];
						// $scope.modelOptions = [];
						$scope.assignOptions=[];
						//$scope.assetOptions = [];
						//$scope.statusOptions = ["","0","1"];

						$scope.tableData = receivedData;
						$scope.mainTable = $scope.tableData;
						
						switch($scope.user.ROLE_ID){
							case 1:
								$scope.assignOptions = receivedData.filter(function(v){
									return v.AREA_ID == $scope.user.RIG_ID;
								}).map(function(v){
									return v.USER_FIRST_NAME+" "+v.USER_LAST_NAME;
								}).filter(function(value,index,inputArray){
									return inputArray.indexOf(value) == index;
								});
								break;
							case 2:
								$scope.assignOptions = receivedData.filter(function(v){
									return v.RIG_ID == $scope.user.RIG_ID;
								}).map(function(v){
									return v.USER_FIRST_NAME+" "+v.USER_LAST_NAME;
								}).filter(function(value,index,inputArray){
									return inputArray.indexOf(value) == index;
								});
								break;
							case 3:
								$scope.assignOptions = receivedData.filter(function(v){
								return ($.inArray(v.EQUIPMENT_ID,$scope.user.RIG_ID) > -1);
								}).map(function(v){
									return v.USER_FIRST_NAME+" "+v.USER_LAST_NAME;
								}).filter(function(value,index,inputArray){
									return inputArray.indexOf(value) == index;
								});
								break;
							default:
								break;
						}

						$scope.tableData = $filter('incidentsFilter')(receivedData,$scope.iArea,$scope.iAsset,$scope.iRig,$scope.iModel,$scope.iAssign,$scope.iStatus);
						
						// $scope.tableData.filter(function(value){
						// 	$.inArray(value.PREFERRED_NAME,$scope.areaOptions)==-1?$scope.areaOptions.push(value.PREFERRED_NAME):1;
						// });

						// $scope.tableData.filter(function(value){
						// 	$.inArray(value.RIG_NAME,$scope.rigOptions)==-1?$scope.rigOptions.push(value.RIG_NAME):1;
						// });

						// //AssetOptions means equipment options type: genset, mud pump, etc.
						// // $scope.tableData.filter(function(value){
						// // 	$.inArray(value.DESCRIPTION,$scope.assetOptions)==-1?$scope.assetOptions.push(value.DESCRIPTION):1;
						// // });

						// $scope.tableData.filter(function(value){
						// 	$.inArray(value.EQUIPMENT_NAME,$scope.modelOptions)==-1?$scope.modelOptions.push(value.EQUIPMENT_NAME):1;
						// });

						// $scope.tableData.filter(function(value){
						// 	$.inArray(value.USER_FIRST_NAME+" "+value.USER_LAST_NAME,$scope.assignOptions)==-1?$scope.assignOptions.push(value.USER_FIRST_NAME+" "+value.USER_LAST_NAME):1;
						// });
						
						$scope.tableData = $scope.tableData.filter(function(value){
							return $scope.iStatus != '' ? (value.INCIDENT_STATUS == parseInt($scope.iStatus)) : true;
						});
						
					}else{
						$scope.tableData = receivedData;
					}
				}else{
					$scope.tableData = [];
				}
			},function(errorData){
				console.log(errorData);
			});
			//End of getting the incidents
		},function(err){
			console.log(err);
		})
	}

	$scope.resetAllOptions = function(){
		$scope.iArea="";
		$scope.iRig="";
		//Asset means equipment type like generator, mud pump, etc.
		$scope.iAsset="";
		$scope.iModel="";
		$scope.iAssign="";
		$scope.iStatus = "";

		$scope.getData();		
	}
	
	$scope.resetAllOptions();
	
	$scope.getData();

	incidentsPageInterval = setInterval(function(){
		$scope.getData();
	},1000*30);

	intervalsList.push(incidentsPageInterval);

	$scope.openModal = function(option,index){
		$scope.$broadcast('openIncidentsModal',[option,index]);
	}

	$scope.$on('saveIncident',function(event,mess){
		$scope.getData();
	});
	
	$scope.filterOptions = function(valueArray){
		if(!isNaN(valueArray)){
			if(valueArray>2){
				$scope.areaOptions = [];
				$scope.iArea = "";
			}
			if(valueArray>1){
				$scope.rigOptions = [];
				$scope.iRig = "";
			}
			if(valueArray>0){
				//$scope.assetOptions = [];
				$scope.iAsset = "";
			}
			if(valueArray>-1){
				$scope.iModel = "";
				$scope.modelOptions = [];
			}

		 	//var tableData = $filter('incidentsFilter')($scope.mainTable,$scope.iArea,$scope.iAsset,$scope.iRig,$scope.iModel,$scope.iAssign,$scope.iStatus);

			// tableData.filter(function(value){
			// 	$.inArray(value.PREFERRED_NAME,$scope.areaOptions)==-1&&valueArray>2?$scope.areaOptions.push(value.PREFERRED_NAME):1;
			// });
		 	
			if($scope.choices != undefined && $scope.choices != null && $scope.choices.constructor === Array && $scope.choices.length > 0){
				
				var tableData = $scope.choices;

				if(valueArray > 2){
					$scope.areaOptions = tableData.map(function(v){
						return v.PREFERRED_NAME;
					}).filter(function(value,index,inputArray){
						return inputArray.indexOf(value) == index;
					})
				}

				if(valueArray > 1){
					$scope.rigOptions = tableData.filter(function(v){
						return (($scope.iArea != undefined && $scope.iArea != null && $scope.iArea != '') ? (v.PREFERRED_NAME == $scope.iArea) : true);
					}).map(function(v){
						return v.RIG_NAME;
					}).filter(function(value,index,inputArray){
						return inputArray.indexOf(value) == index;
					});
				}
				// tableData.filter(function(value){
				// 	$.inArray(value.RIG_NAME,$scope.rigOptions)==-1&&valueArray>1?$scope.rigOptions.push(value.RIG_NAME):1;
				// });

				//AssetOptions means equipment options type: genset, mud pump, etc.
				// tableData.filter(function(value){
				// 	$.inArray(value.DESCRIPTION,$scope.assetOptions)==-1&&valueArray>0?$scope.assetOptions.push(value.DESCRIPTION):1;
				// });

				// tableData.filter(function(value){
				// 	$.inArray(value.EQUIPMENT_NAME,$scope.modelOptions)==-1&&valueArray>-1?$scope.modelOptions.push(value.EQUIPMENT_NAME):1;
				// });

				if(valueArray > -1){
					$scope.modelOptions = tableData.filter(function(v){
						return (($scope.iRig != undefined && $scope.iRig != null && $scope.iRig != '') ? (v.RIG_NAME == $scope.iRig) : true)
						&&
						(($scope.iAsset != '' && $scope.iAsset != undefined && $scope.iAsset != null) ? ($scope.iAsset == v.DESCRIPTION) : true);
					}).map(function(v){
						return v.EQUIPMENT_NAME;
					}).filter(function(value,index,inputArray){
						return inputArray.indexOf(value) == index;
					});
				}
			}
			

			// tableData.filter(function(value){
			// 	$.inArray(value.EQUIPMENT_NAME,$scope.modelOptions)==-1&&valueArray>-1?$scope.modelOptions.push(value.EQUIPMENT_NAME):1;
			// });
		}
		/*else{
			$scope.tableData = $filter('incidentsFilter')($scope.tableData,$scope.mainTable,$scope.iArea,$scope.iAsset,$scope.iRig,$scope.iModel,$scope.iAssign,$scope.iStatus);
		}*/
	}

	/*$scope.$watch("iArea",function(newVal,oldVal){
		$scope.iRig = "";
		$scope.iAsset = "";
		$scope.iModel = "";
	});

	$scope.$watch("iRig",function(newVal,oldVal){
		$scope.iAsset = "";
		$scope.iModel = "";
	});

	$scope.$watch("iAsset",function(newVal,oldVal){
		$scope.iModel = "";
	});*/
	
}).controller('IncidentsModalController',function($scope,$rootScope,MainService){
	$scope.$on('openIncidentsModal',function(event,mess){
		$scope.equipId = mess[0].RIG_EQUIPMENT_ID;
		$scope.desc = mess[0].INCIDENT_DESCRIPTION;
		$scope.action = mess[0].INCIDENT_ASSIGNEE_COMMENT;
		$scope.id = mess[0].EQUIP_INCIDENT_ID;
		$scope.status = mess[0].INCIDENT_STATUS+'';
		$scope.currentIndex = mess[1];
		$('#incidentsModal').modal('show');
	});
	
	$scope.saveIncident = function(){
		if(parseInt($scope.status)==1){	
			if($scope.action == "" || $scope.action == undefined || $scope.action == null){
				$scope.action = "Alarm \""+$scope.desc+"\" closed";
			}
			//$scope.action = $scope.action ? $scope.action : "Alarm \""+$scope.desc+"\" closed";
			MainService.updateIncident($scope.id,$scope.action,$scope.status).then(function(data){
				
			},function(data){
				console.log(data.ErrorMessage);
			});

			MainService.updateEventLogForIncidents($scope.equipId,$scope.desc).then(function(data){
				
			},function(err){
				console.log(err.ErrorMessage);
			})
		}else if(parseInt($scope.status)==0 && $scope.action != '' && $scope.action != undefined && $scope.action != null){
			MainService.updateIncident($scope.id,$scope.action,$scope.status).then(function(data){
				
			},function(data){
				console.log(data.ErrorMessage);
			});
		}

		$('#incidentsModal').modal('hide');
		$scope.$emit('saveIncident',[parseInt($scope.status),$scope.currentIndex]);		
	
	}
});