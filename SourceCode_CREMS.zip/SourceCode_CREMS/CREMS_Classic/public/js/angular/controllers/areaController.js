angular.module('myApp').controller("AreaController",function($scope,$rootScope,MainService,$state){
	$rootScope.$broadcast('updateRig',[{'name':$state.params.name,'url':'app.dashboard.area','params': {id: $state.params.id,name: $state.params.name},'type': 'area'},'area']);
	MainService.hideBreadcrumb(true);
	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.dashboard.area',
		params: {
			id: $state.params.id,
			name: $state.params.name
		}
	}))
}).controller('AreaActivityLogControl',function($scope,MainService,$state){
	$scope.chartParams = {
		title: "Latest 10 Events"
	}

	$scope.tableData = [];
	
	$scope.getData = function(){
		MainService.getEventDetails('area',$state.params.id).then(function(data){
			$scope.tableData = data;
		},function(data){
			console.log(data.ErrorMessage);
		});
	}
	
	$scope.getData();
	areaActivityLogInterval = setInterval(function(){
		$scope.getData();
	},1000*30);
	
	intervalsList.push(areaActivityLogInterval);
	
	$scope.goRig = function(val){
		MainService.clearArrayIntervals();
		$state.go('app.dashboard.rig',{id: val.RIG_ID,name: val.RIG_NAME},{location: false});
	}
}).controller('AreaMapCtrl',function($scope,MainService,$timeout,$window,$state){
	MainService.getRigCoordinates($state.params.id,'area').then(function(data){
		MainService.setMapMarkers(data);
	},function(data){
		console.log(data.ErrorMessage);
	});

	MainService.initialiseMap('areaMap');

	$scope.chartParams = {
		title: "Area Map"
	}
}).controller('AreaIncidentLogCtrl',function($scope,$rootScope,$state,MainService){
	$scope.tableData=[];
	$scope.allClosed = true;
	$scope.getData = function(){
		MainService.getIncidentDetails('area',$state.params.id).then(function(data){
			$scope.tableData = data;
			$scope.allClosed = MainService.closeAllIncidents($scope.tableData);
		},function(data){
			console.log(data.ErrorMessage);
		});
	}
	
	$scope.getData();
	areaIncidentLogInterval = setInterval(function(){
		$scope.getData();
	},1000*30);
	
	intervalsList.push(areaIncidentLogInterval);
	
	$scope.chartParams = {
		title: "Alarms"
	}
	
	$scope.goRig = function(val){
		MainService.clearArrayIntervals();
		$state.go('app.dashboard.rig',{id: val.RIG_ID,name: val.RIG_NAME},{location: false});
	}
	
	$scope.openModal = function(option,index){
		$rootScope.$broadcast('openAreaModal',[option,index]);
	}
	
	$rootScope.$on('saveAreaIncident',function(event,mess){
		// $scope.tableData[mess[1]].INCIDENT_STATUS = mess[0];
		// $scope.allClosed = MainService.closeAllIncidents($scope.tableData);
		$scope.getData();
	});
}).controller('AllRigInfoController',function($scope,$rootScope,$state,AreaService,MainService){
	$scope.getData = function(){
		AreaService.getRigEquipmentsDeploymentList($state.params.id).then(function(data){
			var names = [];
			$scope.tableData = [];
			$.each(data,function(index,val){
				$.inArray(val.rigName,names)==-1?names.push(val.rigName) && $scope.tableData.push({rigName: val.rigName}):1;
			});
			
			$.each($scope.tableData,function(ind,val){
				$.each(data,function(index,value){
					if(value.rigName==val.rigName){
						val.rigId = value.rigId;
						switch(value.DESCRIPTION.toLowerCase()){
							case 'compressor':
								val.compTotal = value.TOTAL;
								val.compActive = value.ACTIVE;
								val.compDefect = (value.STATUS!=-1);
								break;
							case 'generator':
								val.genTotal = value.TOTAL;
								val.genActive = value.ACTIVE;
								val.genDefect = (value.STATUS!=-1);
								break;
							case 'mud pump':
								val.mpumpTotal = value.TOTAL;
								val.mpumpActive = value.ACTIVE;
								val.mpumpDefect = (value.STATUS!=-1);
								break;
							case 'agitator':
								val.agitatorTotal = value.TOTAL;
								val.agitatorActive = value.ACTIVE;
								val.agitatorDefect = (value.STATUS!=-1);
								break;
							case 'shaker':
								val.shakerTotal = value.TOTAL;
								val.shakerActive = value.ACTIVE;
								val.shakerDefect = (value.STATUS!=-1);
								break;
							case 'drawworks':
								val.drawboxTotal = value.TOTAL;
								val.drawboxActive = value.ACTIVE;
								val.drawboxDefect = (value.STATUS!=-1);
								break;
							default: 
								break;
						}
					}
				})
			});
		},function(data){
			console.log(data.ErrorMessage);
		});
	}
	
	$scope.getData();
	
	allRigInfoInterval = setInterval(function(){
		$scope.getData();
	},1000*30);
	
	intervalsList.push(allRigInfoInterval);
	
	$scope.goRig = function(val){
		MainService.clearArrayIntervals();
		$state.go('app.dashboard.rig',{id: val.rigId,name: val.rigName},{location: false});
	}
	
	$scope.chartParams = {
		title: "Rig Equipments (Active/Deployed)"
	}
}).controller('AreaMaintController',function($scope,$state,MainService,$rootScope){
	$scope.chartParams = {
		title: "Area Maintenance Information"
	}

	$scope.type="D";

	var selectedType = "DM";
	 $scope.typeFun = function(type,event){
        selectedType=type;
        fetchAreaMaintData();
		$("#filterAreaEquipment li.active").removeClass('active');
		angular.element(event.currentTarget).addClass('active');
	}

	fetchAreaMaintData();

	areaMaintInterval = setInterval(function(){
		fetchAreaMaintData();
	}, 1000*60);		
	intervalsList.push(areaMaintInterval);

	function fetchAreaMaintData(){
		MainService.getAreaMaintData($state.params.id,selectedType).then(function(data){
			$scope.tableData=data;
        },function(err){
            console.log(err);
        });
	}
	
	$scope.tableData = [];

	$scope.goRig = function(val){
		MainService.clearArrayIntervals();
		$state.go('app.dashboard.rig',{id: val.RIG_ID,name: val.RIG_NAME},{location: false});
	}
	
	$scope.goModel = function(option){
		MainService.clearArrayIntervals();
		$rootScope.$broadcast('updateRig',[{'name':option.RIG_NAME,'url':'app.dashboard.rig','params': {id: option.RIG_ID,name: option.RIG_NAME},'type': 'rig'},'rig']);
		$state.go('app.dashboard.equipment',{id: option.EQUIPMENT_ID,name: option.EQUIPMENT_NAME},{location: false});
	}

}).controller('AreaModalController',function($scope,$rootScope,MainService){
	
	$rootScope.$on('openAreaModal',function(event,mess){
		$scope.equipId = mess[0].RIG_EQUIPMENT_ID;
		$scope.desc = mess[0].INCIDENT_DESCRIPTION;
		$scope.action = mess[0].INCIDENT_ASSIGNEE_COMMENT;
		$scope.id = mess[0].EQUIP_INCIDENT_ID;
		$scope.status = mess[0].INCIDENT_STATUS+'';
		$scope.currentIndex = mess[1];
		$('#areaModal').modal('show');
	});
	
	$scope.saveIncident = function(){
		if(parseInt($scope.status)==1){
			if($scope.action == "" || $scope.action == undefined || $scope.action == null){
				$scope.action = "Alarm \""+$scope.desc+"\" closed";
			}
			//$scope.action = $scope.action ? $scope.action : "Alarm \""+$scope.desc+"\" closed";
			
			MainService.updateIncident($scope.id,$scope.action,$scope.status).then(function(data){
				
			},function(data){
				console.log(data.ErrorMessage);
			});

			MainService.updateEventLogForIncidents($scope.equipId,$scope.desc).then(function(data){

			},function(err){
				console.log(err.ErrorMessage);
			});
		}else if(parseInt($scope.status)==0 && $scope.action != '' && $scope.action != undefined && $scope.action != null){
			//console.log($scope.action);
			MainService.updateIncident($scope.id,$scope.action,$scope.status).then(function(data){
				
			},function(data){
				console.log(data.ErrorMessage);
			});
		}
		
		$('#areaModal').modal('hide');
		$rootScope.$broadcast('saveAreaIncident',[parseInt($scope.status),$scope.currentIndex]);		
	}
});