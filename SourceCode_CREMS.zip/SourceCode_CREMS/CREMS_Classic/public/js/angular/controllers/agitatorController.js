angular.module('myApp').controller('AgitatorController',function($scope,$state,$rootScope,$timeout,MainService,GensetService){
	
	 $scope.header = $state.params.id;
	 $rootScope.$broadcast('updateRig',[{'name':$state.params.name,'url':'app.dashboard.agitator','params': {id: $state.params.id,name: $state.params.name},'type': 'equipment'},'equipment']);	
	 MainService.hideBreadcrumb(false);
	 MainService.initialiseSettingsPanel();

	// /*$scope.paramsToShow={};
	// GensetService.getMappedParameters($state.params.id).then(function(data){
	// 	
	// 	if(data!=undefined&&data.length!=0){
	// 		var count=1;
	// 		var stringData="";
	// 		for(params in data){
	// 			if(count<5){
	// 				$scope.paramsToShow[data[params].ATTR_NAME]=true;
	// 			}
	// 			else{
	// 				$scope.paramsToShow[data[params].ATTR_NAME]=false;
	// 			}
	// 			count++;				
	// 		}		
	// 	}
	// 			
	// },function(err){
	// 	console.log(err.error_message);
	// });*/
	
	$scope.paramsToShow = {
		// "Mud Weight": true,
		// "Pump Output": true,
		// "Total SPM": true,
		// "Mud Pump Pressure": true,
		// "Stand Pipe Pressure": false
		"Graph 1":true,
		"Graph 2":true,
		"Graph 3":true,
		"Graph 4":true				
	};
	
	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.dashboard.agitator',
		params: {
			id: $state.params.id,
			name: $state.params.name
		}
	}))
	
	$scope.openSVGModal = function(modalId,chartId){
		$scope.showCross = true;
		$('#'+modalId).on('shown.bs.modal',function(event){
			var height = $('#'+modalId).height();
			var width = $('#'+modalId).width();
			$('#'+chartId+" svg").attr("width",width);
			$('#'+chartId+" svg").attr("height",height);
			$rootScope.$broadcast('updateLineChart',chartId);
		});

		$('#'+modalId).modal('show');	
	};

	$scope.paramClicked = function(key){
		$scope.paramsToShow[key] = !$scope.paramsToShow[key];		
		$scope.$broadcast('redrawGensetCharts','');
		$timeout(function(){
			$rootScope.$broadcast('updateChart','');
		},1);
	}	
	
	$scope.getData = function(){
		// GensetService.getGensetParameters($state.params.id).then(function(data){
		// 	$scope.currentTime=moment(new Date()).format('DD/MM/YYYY HH:mm');
		// 	$scope.$broadcast('agitatorParametersData',data);
		// },function(err){
		// 	console.log(err.error_message);
		// });	

		MainService.getEquipmentState($state.params.id).then(function(data){
			if(data!=undefined && data != null && data.constructor === Array && data.length > 0){
				switch(data[0].EQUIP_STATUS_ID){
					case 101:
					case 102:
					case 103:
						$scope.eqState = 'Deactivated';
						$scope.eqStatus = 'grey';
						break;
					case 104:
						$scope.eqState = 'Active';
						$scope.eqStatus = 'green';
						break;
					case 105:
						$scope.eqState = 'Active but not reachable';
						$scope.eqStatus = 'red';
						break;
					default:
						$scope.eqState = 'Deactivated';
						$scope.eqStatus = 'grey';
						break;
				}
			}
		},function(err){
			console.log(err.ErrorMessage);
		})
	}
	//to get all the parameters data from DB in every 10 sec
	$scope.getData();	
	
	mudInterval = setInterval(function(){
		$scope.getData();
	}, 1000*60);
	intervalsList.push(mudInterval);	
	
}).controller('agitatorDetailsController',function($scope,$rootScope,MainService,$state,GensetService){
	$scope.chartParams = {
		title : "Equipment Specifications",
		subtitle:"Agitator",
		downloadEnabled: true,
		downloadTitle: "Download Operation Manual"
	};
	
	$scope.downloadFile = function(){
		MainService.downloadFile($state.params.id);
	}
		
	GensetService.getGensetSpecifications($state.params.id).then(function(data){
		$scope.agitatorDetails=data;		
	},function(err){
		console.log(err.error_message);		
	});
}).controller('AgitatorIncidentLogController',function($scope,$rootScope,MainService,$state){
	$scope.chartParams = {
		title : "Alarm Log"
	};
	$scope.agitatorIncDetails = [];
	$scope.allClosed = true;
	$scope.getData = function(){
		MainService.getIncidentDetails('agitator',$state.params.id).then(function(data){
			$scope.agitatorIncDetails = data.filter(function(value){
				return value.INCIDENT_STATUS==0?true:false;
			});
			$scope.allClosed = MainService.closeAllIncidents($scope.agitatorIncDetails);
		},function(data){
			console.log(data.ErrorMessage);		
		});
	}
	
	$scope.getData();
	agitatorIncidentLogInterval = setInterval(function(){
		$scope.getData();
	},30000);
	
	intervalsList.push(agitatorIncidentLogInterval);
	
	$scope.openModal = function(option,index){
		$rootScope.$broadcast('openAgitatorModal',[option,index]);
	}
	
	$rootScope.$on('saveAgitatorIncident',function(event,status,indexVal){
		$scope.agitatorIncDetails[indexVal].INCIDENT_STATUS = status;
		$scope.allClosed = MainService.closeAllIncidents($scope.agitatorIncDetails);
	});

	/*$scope.allClosedIncidents = function(){
		if($scope.pumpIncDetails.length==0)
			return true;
		else if($scope.pumpIncDetails.filter(function(value){return value.INCIDENT_STATUS==0}).length==0)
			return true;
		else
			return false;
	}*/
})
.controller('agitatorEventLogController',function($scope,$rootScope,MainService,$state){
	$scope.chartParams = {
		title: "Event Feed",
		subtitle:"Last 10",
		linkEnabled: true,
		linkTitle: "View Alarms",
		modalId: "#agitatorModal",
		currentView: 'incidentLog'
	};
	$scope.openModal = function(currentView){
		$rootScope.$broadcast('openAgitatorModalView',currentView);
	}
	$scope.tableData = [];
	
	$scope.getData = function(){
		MainService.getEventDetails('agitator',$state.params.id).then(function(data){
			$scope.tableData = data;
		},function(data){
			console.log(data.ErrorMessage);
		});
	}
	
	$scope.getData();
	agitatorEventLogInterval = setInterval(function(){
		$scope.getData();
	},30000);
	
	intervalsList.push(agitatorEventLogInterval);
	MainService.getEventDetails('agitator',$state.params.id).then(function(data){
		$scope.tableData = data;
	},function(data){
		console.log(data.ErrorMessage);
	});
}).controller('AgitatorEngineCoolantTempCtrl', function($scope, $timeout,$rootScope) {
	$scope.chartParams = {
			title: "Blower Vibration"
			// ,
			// subtitle: "(-)"
		};
$scope.chartMargin = {
			left: 60,
			right: 60,
			bottom: 60,
			top: 0
	}
	$scope.yAxisLabelDistance = -15;
	$scope.xAxisLabelDistance = -5;
	
	 $scope.yAxisLabel = "Blower Vibration";
	 $scope.xAxisLabel = "Time";
	$scope.modalId = "BlowerVibrationModal";
	$scope.tickValues = [0,1,2,3,4,5,6,7,8,9];	
	$scope.storeValues = [];
	
	$scope.chartData = [{
		"values": [[0,40],[1,50],[2,20],[3,90],[4,-10],[5,-60],[6,5],[7,90],[8,-40],[9,65] ],
		"key": "PM Function: Blower Vibration",
		"color": "rgb(253, 129, 126)"
	},{
		"values": [[0,10],[1,10],[2,10],[3,10],[4,10],[5,10],[6,10],[7,10],[8,10],[9,10]],
		"key": "BaseLine",
		"color": "rgb(122,122,122)"
	}];
	
	
	$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];	
	
	
}).controller('AgitatorOutputCtrl', function($scope,$timeout,$rootScope) {
	// $scope.chartParams = {
		// title : "Pump Output",
		// subtitle : "bbl/stk"
	// }
	// $scope.middleData="75";
	// //$scope.rightData="100.00";
	
	// $scope.$on('mudParametersData',function(event,data){			
			// for(var spect=0;spect<data.length;spect++){
			// if($scope.chartParams.title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				// $scope.chartParams.title=data[spect].SPEC_DESC;
				// $scope.chartParams.subtitle=data[spect].UOM_QUANTITY_TYPE;
				// $scope.middleData=data[spect].ATTR_VALUE;
				// break;
				// }
		// }
		// $rootScope.$broadcast('updateChart','');
	// });
	$scope.chartParams = {
			title: "Oil Check"
			// ,
			// subtitle: "(-)"
		};
	$scope.chartMargin = {
			left: 60,
			right: 60,
			bottom: 60,
			top: 0
	}
	$scope.yAxisLabelDistance = -15;
	$scope.xAxisLabelDistance = -5;
	$scope.modalId = "OilCheckModal";

	
	$scope.yAxisLabel = "Oil Check";
	$scope.xAxisLabel = "Time";
	
	$scope.tickValues = [0,1,2,3,4,5,6,7,8,9];	
	$scope.storeValues = [];
	
	$scope.chartData = [{
		"values": [[0,1.40],[1,1.50],[2,1.20],[3,1.90],[4,1.1],[5,1.60],[6,1.05],[7,1.90],[8,1.40],[9,1.65] ],
		"key": "PM Function: Oil Check",
		"color": "rgb(184, 135, 173)"
	},{
		"values": [[0,0.5],[1,0.5],[2,0.5],[3,0.5],[4,0.5],[5,0.5],[6,0.5],[7,0.5],[8,0.5],[9,0.5]],
		"key": "BaseLine",
		"color": "rgb(122,122,122)"
	}];
	
	
	$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];

	// $scope.$on('mudParametersData',function(event,data){	
			// var noOfTimeStampsToshow=-1;
			// var initialNoOfTimeStamps=9;
			// var timeStamps=[];
			// var values=[];
			
			// for(var spect=0;spect<data.length;spect++){
			// if($scope.chartParams.title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				// //$scope.chartParams.title=data[spect].SPEC_DESC;
				// $scope.chartParams.title="Oil Check";
				// $scope.chartData[0].key=data[spect].SPEC_DESC;
				// //$scope.chartParams.subtitle=data[spect].UOM_QUANTITY_TYPE;
				// var time=moment(data[spect].MEASURED_DATE).format("HH:mm:ss");
				// timeStamps.push(time);
				// values.push([initialNoOfTimeStamps,parseFloat(data[spect].ATTR_VALUE)]);				
				// initialNoOfTimeStamps--;
				// if(initialNoOfTimeStamps==noOfTimeStampsToshow)
					// break;
				// }
		// }
		// $scope.storeValues=timeStamps.sort();
		// $scope.chartData[0].values=values.sort();	

		// $scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
		// $rootScope.$broadcast('updateLineChart','svg2modal');		
	// });
	
	// $scope.$on('redrawGensetCharts',function(event,mess){
		// setTimeout(function(){
			// $rootScope.$broadcast('updateLineChart','svg2modal');
		// },1);
	// });
	
	$scope.tooltipContentFunction = function(){		
		return function(key,y,e,graph){

			return '<p>'+key+'</p>'+
				   '<p>'+y+'</p>';
		}
	}
	
	$scope.xAxisTickFormatFunction = function(){
		return function(d){
			return $scope.storeValues[d];
		}
	}
	
	$scope.colorFunction = function(){
		return function(d,i){
			return "rgb(1, 184, 170)";
		}
	}
	
}).controller('AgitatorPressureCtrl',function($scope,$timeout,$rootScope) {
	// $scope.chartParams = {
			// title: "Stand Pipe Pressure",
			// subtitle: "PSI"
		// };
	// $scope.chartMargin = {
			// left: 50,
			// right: 30,
			// bottom: 40,
			// top: 0
	// }
	// $scope.yAxisLabelDistance = -15;
	// $scope.xAxisLabelDistance = -5;
	
	// $scope.yAxisLabel = "PSI";
	// $scope.xAxisLabel = "Time";
	
	// //$scope.tickValues = [0,1,2,3,4,5,6,7,8,9];
	
	// $scope.storeValues = [];
	
	// $scope.chartData = [{
		// "values": [ ],
		// "key": "PSI",
		// "color": "rgb(184, 135, 173)"
	// }];
	
	
	// $scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];

	// $scope.$on('mudParametersData',function(event,data){	
			// var noOfTimeStampsToshow=-1;
			// var initialNoOfTimeStamps=9;
			// var timeStamps=[];
			// var values=[];
			
			// for(var spect=0;spect<data.length;spect++){
			// if($scope.chartParams.title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				// $scope.chartParams.title=data[spect].SPEC_DESC;
				// $scope.chartData[0].key=data[spect].SPEC_DESC;
				// $scope.chartParams.subtitle=data[spect].UOM_QUANTITY_TYPE;
				// var time=moment(data[spect].MEASURED_DATE).format("HH:mm:ss");
				// timeStamps.push(time);
				// values.push([initialNoOfTimeStamps,parseFloat(data[spect].ATTR_VALUE)]);				
				// initialNoOfTimeStamps--;
				// if(initialNoOfTimeStamps==noOfTimeStampsToshow)
					// break;
				// }
		// }
		// $scope.storeValues=timeStamps.sort();
		// $scope.chartData[0].values=values.sort();	

		// $scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
		// $rootScope.$broadcast('updateLineChart','standPipePressure');		
	// });
	
	// $scope.$on('redrawGensetCharts',function(event,mess){
		// setTimeout(function(){
			// $rootScope.$broadcast('updateLineChart','standPipePressure');
		// },1);
	// });
	
	// $scope.tooltipContentFunction = function(){		
		// return function(key,y,e,graph){

			// return '<p>'+key+'</p>'+
				   // '<p>'+y+'</p>';
		// }
	// }
	
	// $scope.xAxisTickFormatFunction = function(){
		// return function(d){
			// return $scope.storeValues[d];
		// }
	// }
	
	// $scope.colorFunction = function(){
		// return function(d,i){
			// return "rgb(1, 184, 170)";
		// }
		$scope.modalId = "FilterStatusModal";
	// }
	$scope.chartParams = {
			title: "Filter Status"
			// ,
			// subtitle: "(-)"
		};
	$scope.chartMargin = {
			left: 60,
			right: 60,
			bottom: 60,
			top: 0
	}
	$scope.yAxisLabelDistance = -15;
	$scope.xAxisLabelDistance = -5;
	
	$scope.yAxisLabel = "Filter Status";
	$scope.xAxisLabel = "Time";
	
	$scope.tickValues = [0,1,2,3,4,5,6,7,8,9];	
	$scope.storeValues = [];
	
	$scope.chartData = [{
		"values": [],
		"key": "PM Function: Filter Status",
		"color": "rgb(184, 135, 173)"
	},{
		"values": [],
		"key": "BaseLine",
		"color": "rgb(122,122,122)"
	}];
	
	
	$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
	
}).controller('AgitatorActivityScheduleCtrl',function($scope,$state,GensetService,$rootScope){
	$scope.chartParams = {
		title: "Maintenance Activity Checklist",
		subtitle:"Status"
	}
	$scope.type="D";
	setTimeout(function(){
		$('#filterGenset li').click(function(){			
			$("#filterGenset li.active").removeClass('active');
			$(this).addClass('active');
		});
	},10);
	var selectedType;
	 $scope.typeFun=function(type){
	 	selectedType=type;
		
				fetchActivityChecklistData();			
			$rootScope.$broadcast('highlightType',type);

	};	

		agitatorCheckListInterval = setInterval(function(){
		fetchActivityChecklistData();		
		}, 1000*60);		
	intervalsList.push(agitatorCheckListInterval);

	function fetchActivityChecklistData(){
		GensetService.getActivityChecklist($state.params.id,selectedType).then(function(data){
			$scope.tableData=data;	
			
			},function(err){
				console.log(err);
			});
	}
	$scope.tableData = [];
	
	// to get Activity checklist data from DB
	$scope.typeFun('DM');
	$scope.UpdateStatus=function(index){
		bootbox.confirm("Do you want to close the activity?", function(result) {
			if(result==true){
				var userId=$scope.user.Id;
				//update closing date and last_update_user_id
				GensetService.updateActivityStatus($scope.tableData[index].ACTIVITY_ID,userId).then(function(data){
					$scope.tableData[index].STATUS=1;
				},function(err){
					console.log(err);
				});

				//update closing date in eqip maint table   
			  	GensetService.updateEquipMaintClosingDate($scope.tableData[index].ACTIVITY_ID).then(function(data){
			  	},function(err){
			  		console.log(err);
			  	});
				
				//log event in event table
				GensetService.updateEventLog($scope.tableData[index].ACTIVITY_ID,$state.params.id,$scope.tableData[index].ACTIVITY_DESC).then(function(data){			
				},function(err){
					console.log(err)
				});
				//refresh maint and activity table on ui
				fetchActivityChecklistData();
				$rootScope.$broadcast('refreshMainSch','');
				//If all the status are closed, save a common comment
				GensetService.getActivityChecklist($state.params.id,selectedType).then(function(data){
					var dataLength=data.length;
					var statusAll=1;
					for(var check=0;check<dataLength;check++){
						if(data[check].STATUS==0){
							statusAll=0;
							break;
						}
					}
					// if all the checklists are closed, log a common comment
					if(statusAll==1){
						bootbox.prompt("Please enter comment", function(result) {    
		            
						  if (result !== undefined && result!=null &&result.length!=0) {  
						  //update comment in eqip maint table
						  	GensetService.updateCheckListComment($scope.tableData[index].ACTIVITY_ID,result).then(function(data){
						  	$rootScope.$broadcast('refreshMainSch','');
						  	},function(err){
						  		console.log(err);
						  	});
		                         
						  } 
						});
					}
			},function(err){
				console.log(err);
			});	


			}
			}); 
	
	}
	
}).controller('AgitatorSPMCtrl', function($scope,$timeout,$rootScope) {
	// $scope.chartParams = {
		// title : "Total SPM",
		// subtitle : "(-)"
	// }
	// $scope.middleData="75";
	// //$scope.rightData="100.00";
	
	// $scope.$on('mudParametersData',function(event,data){			
			// for(var spect=0;spect<data.length;spect++){
			// if($scope.chartParams.title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				// $scope.chartParams.title=data[spect].SPEC_DESC;
				// //$scope.chartParams.subtitle=data[spect].UOM_QUANTITY_TYPE;
				// $scope.middleData=data[spect].ATTR_VALUE;
				// break;
				// }
		// }
		// $rootScope.$broadcast('updateChart','');
	// });
	$scope.modalId = "BeltTensionModal";

	$scope.chartParams = {
			title: "Belt Tension"
			// ,
			// subtitle: "(-)"
		};
	$scope.chartMargin = {
			left: 60,
			right: 60,
			bottom: 60,
			top: 0
	}
	$scope.yAxisLabelDistance = -15;
	$scope.xAxisLabelDistance = -5;
	
	$scope.yAxisLabel = "Belt Tension";
	$scope.xAxisLabel = "Time";
	
	$scope.tickValues = [0,1,2,3,4,5,6,7,8,9];	
	$scope.storeValues = [];
	
	$scope.chartData = [{
		"values": [[0,1.40],[1,1.50],[2,1.20],[3,1.90],[4,1.1],[5,1.60],[6,1.05],[7,1.90],[8,1.40],[9,1.65] ],
		"key": "PM Function: Belt Tension",
		"color": "rgb(184, 135, 173)"
	},{
		"values": [[0,0.5],[0,0.5],[2,0.5],[3,0.5],[4,0.5],[5,0.5],[6,0.5],[7,0.5],[8,0.5],[9,0.5]],
		"key": "BaseLine",
		"color": "rgb(122,122,122)"
	}];
	
	
	$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
	
}).controller('agitatorPressureCtrl',function($scope,$timeout,$rootScope){
	// $scope.chartParams = {
			// title: "Mud Pump Pressure",
			// subtitle: "PSI"
		// };
	// $scope.chartMargin = {
			// left: 50,
			// right: 30,
			// bottom: 40,
			// top: 0
	// }
	// $scope.yAxisLabelDistance = -15;
	// $scope.xAxisLabelDistance = -5;
	
	// $scope.yAxisLabel = "PSI";
	// $scope.xAxisLabel = "Time";
	
	// //$scope.tickValues = [0,1,2,3,4,5,6,7,8,9];
	
	// $scope.storeValues = [];
	
	// $scope.chartData = [{
		// "values": [ ],
		// "key": "PSI",
		// "color": "rgb(1, 184, 170)"
	// }];
	
	
	// $scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
// //	console.log($scope.chartData);
	// $scope.$on('mudParametersData',function(event,data){	
			// var noOfTimeStampsToshow=-1;
			// var initialNoOfTimeStamps=9;
			// var timeStamps=[];
			// var values=[];
			
			// for(var spect=0;spect<data.length;spect++){
			// if($scope.chartParams.title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				// $scope.chartParams.title=data[spect].SPEC_DESC;
				// $scope.chartData[0].key=data[spect].SPEC_DESC;
				// $scope.chartParams.subtitle=data[spect].UOM_QUANTITY_TYPE;
				// var time=moment(data[spect].MEASURED_DATE).format("HH:mm:ss");
				// timeStamps.push(time);
				// values.push([initialNoOfTimeStamps,parseFloat(data[spect].ATTR_VALUE)]);				
				// initialNoOfTimeStamps--;
				// if(initialNoOfTimeStamps==noOfTimeStampsToshow)
					// break;
				// }
		// }
		// $scope.storeValues=timeStamps.sort();
		// $scope.chartData[0].values=values.sort();	
		// console.log($scope.chartData)
		// $scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
		// $rootScope.$broadcast('updateLineChart','mudpumpPressure');		
	// });
	
	// $scope.$on('redrawGensetCharts',function(event,mess){
		// setTimeout(function(){
			// $rootScope.$broadcast('updateLineChart','mudpumpPressure');
		// },1);
	// });
	
	// $scope.tooltipContentFunction = function(){		
		// return function(key,y,e,graph){
			// console.log(key+" "+y)
			// return '<p>'+key+'</p>'+
				   // '<p>'+y+'</p>';
		// }
	// }
	
	// $scope.xAxisTickFormatFunction = function(){
		// return function(d){
			// return $scope.storeValues[d];
		// }
	// }
	
	// $scope.colorFunction = function(){
		// return function(d,i){
			// return "rgb(1, 184, 170)";
		// }
	// }
	$scope.chartParams = {
			title: "Oil Overfill Indicator"
			// ,
			// subtitle: "(-)"
		};
	$scope.chartMargin = {
			left: 60,
			right: 60,
			bottom: 60,
			top: 0
	}
	$scope.yAxisLabelDistance = -15;
	$scope.xAxisLabelDistance = -5;
	
	$scope.yAxisLabel = "Oil Overflow Indicator";
	$scope.xAxisLabel = "Time";

	$scope.modalId = "OilOverflowModal";
	
	$scope.tickValues = [0,1,2,3,4,5,6,7,8,9];	
	$scope.storeValues = [];
	
	$scope.chartData = [{
		"values": [[0,0.40],[1,0.50],[2,0.20],[3,0.90],[4,0.1],[5,0.60],[6,0.05],[7,0.90],[8,0.40],[9,0.65] ],
		"key": "PM Function: Oil Overfill Indicator",
		"color": "rgb(253, 129, 126)"
	},{
		"values": [[0,0.2],[1,0.2],[2,0.2],[3,0.2],[4,0.2],[5,0.2],[6,0.2],[7,0.2],[8,0.2],[9,0.2]],
		"key": "BaseLine",
		"color": "rgb(122,122,122)"
	}];
	
	
	$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
	
}).controller('agitatorImage',function($scope){
	var threshold={};	
	var time="";
	$scope.chartParams = {
		title: "Critical Agitator Parameters",
		subtitle:"Last Updated at"+time
	};

	$scope.$on('agitatorParametersData',function(event,mess){
		threshold=mess;	
		if(mess!=undefined&&mess.length!=0){
			time=moment(mess[0].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
		}	
		$scope.chartParams.subtitle="Last Updated at "+time;
		
		$scope.agitatorImpParams = [{
			name: "Mud Pump Pressure",
			value: parameterValue('Mud Pump Pressure'),
			warning: checkWarning('Mud Pump Pressure',parameterValueOnly('Mud Pump Pressure')),
			posTop: "18em",
			posLeft: "15em"
		},{
			name: "Pump Output",
			value: parameterValue('Pump Output'),
			warning: checkWarning('Pump Output',parameterValueOnly('Pump Output')),
			posTop: "14em",
			posLeft: "1em"
		},{
			name: "Stand Pipe Pressure",
			value: parameterValue('Stand Pipe Pressure'),
			warning: checkWarning('Stand Pipe Pressure',parameterValueOnly('Stand Pipe Pressure')),
			posTop: "10em",
			posLeft: "21em"
		},{
			name: 'Total SPM',
			value: parameterValue('Total SPM'),
			posTop: "23em",
			posLeft: "7em",
			warning: checkWarning('Total SPM',parameterValueOnly('Total SPM'))
		}];
	});

	$scope.agitatorImpParams = [{
		name: "Operating Pressure",
		value: '3.4 bar',
		warning: false,
		posTop: "11em",
		posLeft: "22em"
	},{
		name: "Dynamic Viscosity",
		value: '0.3 cP',
		warning: false,
		posTop: "16em",
		posLeft: "7em"
	},{
		name: "Surface Temperature",
		value: '45 C',
		warning: false,
		posTop: "15em",
		posLeft: "25em"
	},{
		name: 'Speed',
		value: '90 RPM',
		posTop: "11em",
		posLeft: "11em",
		warning: false
	}];

	time =  moment($.now()).format("DD/MM/YYYY HH:mm");
	$scope.chartParams.subtitle="Last Updated at "+time;

	var checkWarning=function(name,value){
		try{
			for(var parameter=0;parameter<threshold.length;parameter++){
			value=value.toString().substring(0,value.length);
			valueInNumber=parseFloat(value);
			if(name.toLowerCase()==threshold[parameter].SPEC_DESC.toLowerCase()){
				if(valueInNumber>parseFloat(threshold[parameter].MAX_VALUE)||parseFloat(valueInNumber<threshold[parameter].MIN_VALUE))
					return true;
				else
					return false;
			}
		}
		}catch(err){			
		}

	};
	
	var parameterValue=function(name){
		var flag=false;
		for(var parameter=0;parameter<threshold.length;parameter++){
			if(name.toLowerCase()==threshold[parameter].SPEC_DESC.toLowerCase()){
				return threshold[parameter].ATTR_VALUE.toFixed(2)+" "+threshold[parameter].UOM_QUANTITY_TYPE;
			}
		}
		if(flag==false){
			return 'NA'
		}
	}	
	var parameterValueOnly=function(name){
		for(var parameter=0;parameter<threshold.length;parameter++){
			if(name.toLowerCase()==threshold[parameter].SPEC_DESC.toLowerCase()){
		
				return threshold[parameter].ATTR_VALUE;
			}
		}
	}	
}).controller('AgitatorMaintenanceCycleCtrl',function($scope,GensetService,$state,$rootScope){
	$scope.chartParams = {
			title : "Maintenance Schedule",
			subtitle : "Last & Upcoming"
		}
		
		$scope.tableHeadData=[{col1:'Maintenance Type','col2':'Last',col3:'Upcoming',col4:'Comment'}];
		$scope.tableData=[];
		$scope.rcvHigh="DM";
		
		$rootScope.$on('highlightType',function(event, value){
		
			$scope.rcvHigh=value;
		});
		$rootScope.$on('refreshMainSch',function(event,mess){
				fetchMaintenanceScheduleData();
		});
		//to get all the maintenance data 	
		fetchMaintenanceScheduleData();


		agitatorMaintenanceInterval = setInterval(function(){
		fetchMaintenanceScheduleData();		
		}, 1000*60);		
		intervalsList.push(agitatorMaintenanceInterval);
		
		function fetchMaintenanceScheduleData(){
			GensetService.getMaintenanceScheduleData($state.params.id).then(function(data){
		
			$scope.tableData=[];
			for(var maint=0;maint<data.length;maint++){
				var type;
				var order;
				if(data[maint].Type=="DM"){
					type="Daily (DM)";
					order=0;
				}else if(data[maint].Type=="WM"){
					type="Weekly (WM)";
					order=1;
				}else if(data[maint].Type=="MM"){
					type="Monthly (MM)";
					order=2;
				}else if(data[maint].Type=="QM"){
					type="Quarterly (QM)";
					order=3;
				}else if(data[maint].Type=="HYM"){
					type="Half Yearly (HYM)"
					order=4;
				}else if(data[maint].Type=="YM"){
					type="Yearly (YM)"
					order=5;
				}
				var last;
				var next;
				if(data[maint].last_1!=null){
					last=moment(data[maint].last_1).format("DD/MM/YYYY HH:mm");
				}
				else{
					last="-";
				}
				if(data[maint].next_1!=null){
					next=moment(data[maint].next_1).format("DD/MM/YYYY HH:mm");
				}
				else{
					next="-";
				}
		
				var REMARK="";
				if(data[maint].REMARK==null||data[maint].REMARK.length==0){
					REMARK="-";
				}
				else
					REMARK=data[maint].REMARK;
				jsonObject={"type":type, "last":last, "next":next, "order":order,'high':data[maint].Type,"Comment":REMARK};
				$scope.tableData.push(jsonObject);
		
			}
			
			$scope.tableData.sort(function(a,b){
				return a.order-b.order;
			})

			
		},function(err){
			console.log(err.error_message);
		});	
}
}).controller('AgitatorMaintenanceBreakdownCtrl',function($scope,GensetService,$state,$rootScope){
	$scope.chartParams = {
			title : "Planned Vs Unplanned Summary",
			subtitle : "Last 6 Months",
			linkTitle:"Maintenance History",
			linkEnabled:true,						
			currentView: 'maintenanceHistory'
		}
		$scope.openModal = function(currentView){
			$rootScope.$broadcast('openAgitatorModalView',currentView);
		}
		var months=[{mon:"Jan",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Feb",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Mar",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Apr",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"May",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Jun",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Jul",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Aug",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Sep",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Oct",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Nov",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Dec",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''}];
	// to get MaintenanceBreakdownSummary
	$scope.monthlyData=[];
	GensetService.getMaintenanceBreakdownSummary($state.params.id).then(function(data){

			if(data!=undefined&&data.length!=0){
				for(var month=0;month<data.length;month++){
			if(data[month].Type.toLowerCase()=="mm"){
			months[new Date(data[month].next_1).getMonth()].visible=true;
			months[new Date(data[month].next_1).getMonth()].backgroundcolor='rgba(1, 184, 170,0.6)';
			months[new Date(data[month].next_1).getMonth()].PM=data[month].REMARK;

			}
			if(data[month].Type.toLowerCase()=="ubd"){
			//months[new Date(data[month].last_1).getMonth()].visibleBD=true;
			//months[new Date(data[month].last_1).getMonth()].backgroundcolor='rgb(253, 129, 126)';
			months[new Date(data[month].last_1).getMonth()].backgroundcolorBD='rgb(254, 150, 102)';
			months[new Date(data[month].last_1).getMonth()].UPM=data[month].REMARK;

			}
			
		}
		var lastMonth=data[0].CurrentMonth-1;
		var last6thMonth=data[0].CurrentMonth-7;

		$scope.monthlyData=[];
		while(last6thMonth<lastMonth){
			$scope.monthlyData.push(months[last6thMonth]);
			last6thMonth++;
		}
			}
		
		

		
	},function(err){
		console.log(err);
	});
		
}).controller('AgitatorChart1Ctrl', function($scope,$timeout,$rootScope) {
	
$scope.chartParams = {
			title: "Graph 1",
			subtitle:"LAST UPDATED AT ",
		modalEnabled:false
		};
	$scope.chartMargin = {
			left: 50,
			right: 30,
			bottom: 30,
			top: 0
	}
	$scope.yAxisLabelDistance = -15;
	$scope.xAxisLabelDistance = -15;
	$scope.yAxisLabel = "Pressure";
	$scope.xAxisLabel = "Time";
	
	//$scope.tickValues = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59]
	
	//var timeRange = ['12:00 AM','12:01 AM','12:02 AM','12:03 AM','12:04 AM','12:05 AM','12:06 AM','12:07 AM','12:08 AM','12:09 AM','12:10 AM','12:01 AM','12:02 AM','12:03 AM','12:04 AM','12:05 AM','12:06 AM','12:07 AM','12:08 AM','12:09 AM','12:10 AM','12:01 AM','12:02 AM','12:03 AM','12:04 AM','12:05 AM','12:06 AM','12:07 AM','12:08 AM','12:09 AM','12:10 AM','12:01 AM','12:02 AM','12:03 AM','12:04 AM','12:05 AM','12:06 AM','12:07 AM','12:08 AM','12:09 AM','12:10 AM','12:01 AM','12:02 AM','12:03 AM','12:04 AM','12:05 AM','12:06 AM','12:07 AM','12:08 AM','12:09 AM','01:00 PM'];
	$scope.storeValues = [];
	
	$scope.chartData = [{
		"values": [ ],
		"key": "Fuel Consumption Rate",
		"color": "rgb(1, 184, 170)"
	},{
		"values": [ ],
		"key": "Min",
		"color": "rgb(255,100,100)",
		 "classed": 'dashed'
	},{
		"values": [ ],
		"key": "Max",
		"color": "rgb(255,100,100)",
		 "classed": 'dashed'
	}];
	
	
	$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];

	
	//to get threshold values
	var min=0;
	var max=0;
	var title=$scope.chartParams.title;
		$scope.$on('gensetParametersData',function(event,data){	
			var noOfTimeStampsToshow=-1;
			var initialNoOfTimeStamps=9;
			var timeStamps=[];
			var values=[];
			var maxValue=[];
			var minValue=[];
			var flag=0;
			for(var spect=0;spect<data.length;spect++){
			if(title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				if(flag==0){

					$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
					flag++;
				}				
				$scope.chartData[0].key=data[spect].SPEC_DESC;
				var time=moment(data[spect].MEASURED_DATE).format("HH:mm:ss");
				timeStamps.push(time);
				min=data[spect].MIN_VALUE;
				max=data[spect].MAX_VALUE;
				minValue.push([initialNoOfTimeStamps,min]);
				maxValue.push([initialNoOfTimeStamps,max]);
				values.push([initialNoOfTimeStamps,parseFloat(data[spect].ATTR_VALUE)]);				
				initialNoOfTimeStamps--;
				if(initialNoOfTimeStamps==noOfTimeStampsToshow){
					$scope.chartParams.title=data[spect].SPEC_DESC+" ("+data[spect].UOM_QUANTITY_TYPE+")";	
					break;		
				}		
					
				}
		}
		$scope.storeValues=timeStamps.sort();
		$scope.chartData[0].values=values;
		$scope.chartData[1].values=minValue;	
		$scope.chartData[2].values=maxValue;
		$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
		$rootScope.$broadcast('updateLineChart','oilFlowLine');	
	});
	
	$scope.$on('redrawGensetCharts',function(event,mess){
		setTimeout(function(){
			$rootScope.$broadcast('updateLineChart','oilFlowLine');	
		},10);
	});
	$scope.tooltipContentFunction = function(){		
		return function(key,y,e,graph){

			return '<p>'+key+'</p>'+
				   '<p>'+y+'</p>';
		}
	}
	
	$scope.xAxisTickFormatFunction = function(){
		return function(d){
			return $scope.storeValues[d];
		}
	}
	
	$scope.colorFunction = function(){
		return function(d,i){
			return "rgb(1, 184, 170)";
		}
	}
	
}).controller('AgitatorMaintenanceHistoryCtrl',function($scope,GensetService,$state,$timeout){
	$scope.chartParams = {
			title : "Maintenance History",
			subtitle : ""
		}
		$scope.tableHeadData=['Activity Date','Planned Date','Type','Comment','Status'];
		$scope.tableData=[];
		$timeout(function(){
		$(".openStatus:contains('Maintenance History')").click(function(){
			GensetService.getMaintenanceHistory($state.params.id).then(function(data){
				$scope.tableData=data;

			},function(err){
				console.log(err);
			})
	});
	},15);

}).controller('AgitatorModalController',function($scope,$rootScope,MainService,$timeout){
	$rootScope.$on('openAgitatorModal',function(event,mess){
		$scope.equipId = mess[0].RIG_EQUIPMENT_ID;
		$scope.desc = mess[0].INCIDENT_DESCRIPTION;
		$scope.id = mess[0].EQUIP_INCIDENT_ID;
		$scope.status = mess[0].INCIDENT_STATUS+'';
		$scope.currentIndex = mess[1];
		$('#closeIncidentForm').slideDown(300);
	});
	$scope.modalDate="AgitatorModalCal";
	$scope.saveIncident = function(){
		if(parseInt($scope.status)==1){
			
			MainService.closeIncident($scope.id).then(function(data){
			
			},function(data){
				console.log(data.ErrorMessage);
			});

			MainService.updateEventLogForIncidents($scope.equipId,$scope.desc).then(function(data){

			},function(err){
				console.log(err.ErrorMessage);
			});
		}
		$('#closeIncidentForm').slideUp(300);
		$rootScope.$broadcast('saveAgitatorIncident',parseInt($scope.status),$scope.currentIndex);		
	}
	
	$('#agitatorModal').on('show.bs.modal',function(){
		$('#closeIncidentForm').hide();
	});
	
	$rootScope.$on('openagitatorModalView',function(event,mess){
		$scope.currentView = mess;
		if($scope.currentView=="incidentLog"){
			$scope.title="Incident View";
			$scope.subtitle="";
		}
		else if($scope.currentView=="maintenanceHistory"){
			$scope.title="Maintenance History";
			var startDate="";
			  var endDate="";
			  	var startDate1="";
			  var endDate1="";
			$scope.subtitle="From "+startDate+" to "+endDate;	
			dateRangePickerFnct($scope.modalDate,"down","left");
			
			$timeout(function(){	
				var dateObject=$('#'+$scope.modalDate).data('daterangepicker');
				startDate=moment(dateObject.startDate._d).format('DD/MM/YYYY');
				endDate=moment(dateObject.endDate._d).format('DD/MM/YYYY');
				startDate1=moment(dateObject.startDate._d).utc().format('YYYY/MM/DD');
				endDate1=moment(dateObject.endDate._d).utc().format('YYYY/MM/DD');
				var data=[startDate1,endDate1];
				$rootScope.$broadcast('getMaintHist',data);
				$scope.subtitle="From "+startDate+" to "+endDate;
			$('#'+$scope.modalDate).on('apply.daterangepicker', function(ev, picker) {	
			  startDate=moment(picker.startDate._d).format('DD/MM/YYYY');
			  endDate=moment(picker.endDate._d).format('DD/MM/YYYY');
			  startDate1=moment(dateObject.startDate._d).utc().format('YYYY/MM/DD');
				endDate1=moment(dateObject.endDate._d).utc().format('YYYY/MM/DD');
			   // call miantenance data form db for particulat date
			   var data=[startDate1,endDate1];
			   $rootScope.$broadcast('getMaintHist',data);			   
			   $scope.subtitle="From "+startDate+" to "+endDate;
			   $scope.$digest();

			});	
		
		},50);	

	
		}
		$('#agitatorModal').modal('show');
	});
}).controller('agitatorSensorGraphsController',function($scope,$state,MainService){
	$scope.chartConfig = [];
	
	//var sensorCharts = [];
	//var batchStartId = undefined;

	// $scope.chartConfig = [{
	// 	chartType: 'line',
	// 	margin : {
	// 		left: 50,
	// 		right: 30,
	// 		bottom: 50,
	// 		top: 0
	// 	},
	// 	yAxisLabelDistance : -25,
	// 	yAxisLabel : "Litres",
	// 	xAxisLabel : "Time",
	// 	chartId: 'chart1',
	// 	height: 143
	// },{
	// 	chartType: 'line',
	// 	margin : {
	// 		left: 50,
	// 		right: 30,
	// 		bottom: 50,
	// 		top: 0
	// 	},
	// 	yAxisLabelDistance : -25,
	// 	yAxisLabel : "Litres",
	// 	xAxisLabel : "Time",
	// 	chartId: 'chart2',
	// 	height: 143
	// },{
	// 	chartType: 'line',
	// 	margin : {
	// 		left: 50,
	// 		right: 30,
	// 		bottom: 50,
	// 		top: 0
	// 	},
	// 	yAxisLabelDistance : -25,
	// 	yAxisLabel : "Litres",
	// 	xAxisLabel : "Time",
	// 	chartId: 'chart3',
	// 	height: 143
	// }];

	$scope.widgetConfig = [];
	// $scope.widgetConfig = [{
	// 	title: 'Sensor 1 Status',
	// 	subtitle: 'No alarms'
	// },{
	// 	title: 'Sensor 1 Vibration Curve',
	// 	subtitle: 'No Unit'
	// },{
	// 	title: 'Sensor 2 Status',
	// 	subtitle: 'No alarms'
	// },{
	// 	title: 'Sensor 2 Vibration Curve',
	// 	subtitle: 'No Unit'
	// },{
	// 	title: 'Sensor 3 Status',
	// 	subtitle: 'No alarms'
	// },{
	// 	title: 'Sensor 3 Vibration Curve',
	// 	subtitle: 'No Unit'
	// }];

	$scope.chartData = [];
	// $scope.chartData = [[{
	// 	color: 'red',
	// 	key: 'Vibration Graph 1',
	// 	values: []
	// }],[{
	// 	color: 'blue',
	// 	key: 'Vibration Graph 2',
	// 	values: []
	// }],[{
	// 	color: 'green',
	// 	key: 'Vibration Graph 3',
	// 	values: []
	// }]];

	MainService.getEquipmentSensorStats($state.params.id).then(function(data){
		var uniqueSensors = [];
		
		$.each(data,function(index,value){
			if($.inArray(value.SENSOR_ID,uniqueSensors) == -1){
				uniqueSensors.push(value.SENSOR_ID);
			}
		});
		count = 0;
		for(j in uniqueSensors){
			var unit = undefined;
			var param = undefined;
			var sensorName = undefined;
			$scope.chartData.push([{
				color: 'green',
				key: '',
				values : []
			}]);
			for(var i=0;i<data.length;i++){
				if(data[i]['SENSOR_ID'] == uniqueSensors[j]){
					if(unit == undefined){
						console.log(data[i]['SENSOR_ID']);
						console.log(data[i]['SENSOR_NAME']);
						unit = data[i]['UOM_NAME'];
					}
					if(param == undefined){
						console.log('param undefined');
						param = data[i]['ATTR_NAME'];
					}
					if(sensorName == undefined){
						console.log('sensorName undefined');
						sensorName = data[i]['SENSOR_NAME'];
					}
					$scope.chartData[count][0].values.push([data[i].MEASURED_DATE,data[i].ATTR_VALUE]);
				}
			}
			$scope.chartData[count][0].key = param;

			$scope.widgetConfig.push({
				title: sensorName+' Status',
				subtitle: 'No Alarms'
			});

			$scope.widgetConfig.push({
				title: sensorName+' Vibration Graph',
				subtitle: unit
			});

			$scope.chartConfig.push({
				chartType: 'line',
				margin : {
					left: 50,
					right: 30,
					bottom: 50,
					top: 0
				},
				yAxisLabelDistance : -25,
				yAxisLabel : param,
				xAxisLabel : "Time",
				chartId: 'chart'+count,
				height: 143
			});

			count++;
		}
	},function(err){
		console.log(err);
	});
	
	// $scope.getSensorGraphData = function(){
	// 	MainService.getEquipmentSensorStats($state.params.id,batchStartId).then(function(data){
	// 		var uniqueSensors = [];
	// 		if(data!=undefined && data != null && data.constructor == Array && data.length!=0){
	// 			//console.log(data.length);
	// 			if(data.length < 500){
	// 				clearGraphDataInterval();
	// 			}
	// 			var sortedSensorIds = data.map(function(p){
	// 				return p['MEAS_ATTR_ID'];
	// 			}).sort();

	// 			batchStartId = sortedSensorIds[0];
	// 		}else{
	// 			clearGraphDataInterval();
	// 		}

	// 		$.each(data,function(index,value){
	// 			if($.inArray(value.SENSOR_ID,uniqueSensors) == -1){
	// 				uniqueSensors.push(value.SENSOR_ID);
	// 			}
	// 		});

	// 		for(j in uniqueSensors){
	// 			var unit = undefined;
	// 			var param = undefined;
	// 			var sensorName = undefined;

	// 			if($.inArray(uniqueSensors[j],sensorCharts) != -1){
	// 				var x = sensorCharts.indexOf(uniqueSensors[j]);
	// 				var arr = [];
	// 				for(var i=0;i<data.length;i++){
	// 					if(data[i]['SENSOR_ID'] == uniqueSensors[j]){						
	// 						arr.push([data[i].MEASURED_DATE,data[i].ATTR_VALUE]);
	// 					}
	// 				}
	// 				$scope.chartData[x][0].values = $.merge($scope.chartData[x][0].values,arr); 
	// 			}else{
	// 				$scope.chartData.push([{
	// 					color: 'green',
	// 					key: '',
	// 					values : []
	// 				}]);
	// 				var arr = [];
	// 				for(var i=0;i<data.length;i++){
	// 					if(data[i]['SENSOR_ID'] == uniqueSensors[j]){
	// 						if(!unit)
	// 							unit = data[i]['UOM_NAME'];
	// 						if(!param)
	// 							param = data[i]['ATTR_NAME'];
	// 						if(!sensorName)
	// 							sensorName = data[i]['SENSOR_NAME'];

	// 						arr.push([data[i].MEASURED_DATE,data[i].ATTR_VALUE]);
	// 					}
	// 				}
					
	// 				$scope.chartData[j][0].values = $.merge($scope.chartData[j][0].values,arr);
	// 				$scope.chartData[j][0].key = param;

	// 				$scope.widgetConfig.push({
	// 					title: sensorName+' Status',
	// 					subtitle: 'No Alarms'
	// 				});

	// 				$scope.widgetConfig.push({
	// 					title: sensorName+' Vibration Graph',
	// 					subtitle: unit
	// 				});

	// 				$scope.chartConfig.push({
	// 					chartType: 'line',
	// 					margin : {
	// 						left: 50,
	// 						right: 30,
	// 						bottom: 50,
	// 						top: 0
	// 					},
	// 					yAxisLabelDistance : -25,
	// 					yAxisLabel : param,
	// 					xAxisLabel : "Time",
	// 					chartId: 'chart'+j,
	// 					height: 143,
	// 				});
	// 				sensorCharts.push(uniqueSensors[j]);
	// 			}
	// 		}
	// 	},function(err){
	// 		console.log(err);
	// 	});
	// };
	
	// $scope.getSensorGraphData();

	// var sensorGraphDataInterval = setInterval(function(){
	// 	$scope.getSensorGraphData();
	// },2000);

	// intervalsList.push(sensorGraphDataInterval);

	// var clearGraphDataInterval = function(){
	// 	if(sensorGraphDataInterval!=undefined){
	// 		clearInterval(sensorGraphDataInterval);
	// 	}
	// }
});