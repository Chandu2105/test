angular.module('myApp').controller('AdminEventsController',function($scope,MainService,$rootScope){
        

        $scope.chartParams = {
                title: "All Events' Logs"
        }

        $scope.tableData = [];
        $scope.pageTable = [];
        $scope.entries = 15;
        $scope.allClosed = true;
        
        MainService.hideBreadcrumb(true);
        $rootScope.$broadcast('updateRig',[{'name':'Event Logs','url':'app.events',type: 'events'},'events']);

        sessionStorage.setItem('lastState',JSON.stringify({
                state: 'app.events',
                params: null
        }));

        var id = "1 OR 1=1";
        
        MainService.getEventLogsAdmin(id).then(function(data){
                if(data != undefined && data != null && data.length!=0){
                        $scope.tableData = data;
                        id = data[data.length-1].EVENT_ID;
        
                }       
        },function(error){
                        console.log(error);
        });
})
