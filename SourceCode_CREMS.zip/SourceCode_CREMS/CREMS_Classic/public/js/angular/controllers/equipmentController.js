angular.module('myApp').controller('EquipmentController',function($scope,$state,$rootScope,MainService,$http,GensetService,$timeout){
	
	$scope.header = $state.params.id;
	$scope.equipmentDesc = "Equipment";
	
	$rootScope.$broadcast('updateRig',[{'name':$state.params.name,'url':'app.dashboard.equipment','params': {id: $state.params.id,name: $state.params.name},'type': 'equipment'},'equipment']);
	
	MainService.hideBreadcrumb(false);
	MainService.initialiseSettingsPanel();
	$scope.paramsToShow={};
	
	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.dashboard.equipment',
		params: {
			id: $state.params.id,
			name: $state.params.name
		}
	}))
	
	$scope.getData = function(){
		MainService.getEquipmentState($state.params.id).then(function(data){
			if(data!=undefined && data != null && data.constructor === Array && data.length > 0){
                $scope.equipmentDesc = data[0].DESCRIPTION;
                $scope.$broadcast('updateEquipType',data[0].DESCRIPTION);
				switch(data[0].EQUIP_STATUS_ID){
					case 101:
					case 102:
					case 103:
						$scope.eqState = 'Deactivated';
						$scope.eqStatus = 'grey';
						break;
					case 104:
						$scope.eqState = 'Active';
						$scope.eqStatus = 'green';
						break;
					case 105:
						$scope.eqState = 'Active but not reachable';
						$scope.eqStatus = 'red';
						break;
					default:
						$scope.eqState = 'Deactivated';
						$scope.eqStatus = 'grey';
						break;
				}
			}
		},function(err){
			console.log(err.ErrorMessage);
		})
	}

	//to get all the parameters data from DB in every 1 min
	$scope.getData();

	equipmentInterval = setInterval(function(){
		$scope.getData();
	}, 1000*30);
		
	intervalsList.push(equipmentInterval);	
	
	$scope.lastRefreshed = "Last Updated at "+moment($.now()).format("DD/MM/YYYY HH:mm");

	$scope.$on('refreshLastUpdate',function(event,msg){
		$scope.lastRefreshed = msg;
	});
	
}).controller('equipmentDetailsController',function($scope,GensetService,$state,MainService){
    $scope.chartParams = {
		title : "Equipment Specifications",
		subtitle: $scope.equipmentDesc,
		downloadEnabled: true,
		downloadTitle: "Download Operation Manual"
	};	

    $scope.$on('updateEquipType',function(event,message){
        $scope.chartParams.subtitle = message;
    });
	
	$scope.equipmentDetails = [];

	$scope.downloadFile = function(){
		MainService.downloadFile($state.params.id).then(function(data){
			
		},function(err){
			$scope.$emit('popup',err.ErrorMessage,"error");
		});
	}
    
	GensetService.getGensetSpecifications($state.params.id).then(function(data){
		if(data != undefined && data != null && data.constructor === Array && data.length != 0){
			$scope.equipmentDetails=data;
		}else{
			$scope.equipmentDetails = [];
		}
	},function(err){
		console.log(err.error_message);		
	});
	
}).controller('EquipmentComponentsController',function($scope,$state,GensetService,MainService,$rootScope,$interval){
	$scope.hour = Math.abs(21 - new Date().getHours());
	$scope.minutes = Math.abs(60 - new Date().getMinutes());
	$scope.equipName = "";

	$interval(function(){
		$scope.hour = Math.abs(21 - new Date().getHours());
		$scope.minutes = Math.abs(60 - new Date().getMinutes());
	},1000)

	var threshold = {};
	var time="";
	$scope.chartParams = {
		title: " Critical "+ MainService.capitalizeFirstLetter($scope.equipmentDesc) +" Parameters ",
		subtitle:"Last Updated at "+time,
		linkTitle:"Temperature History",
		linkEnabled:true,						
		currentView: 'temperatureHistory'
	};
	
    $scope.equipmentImage = "images/Generator.jpg";

    $scope.$on('updateEquipType',function(event,message){
        $scope.chartParams.title = " Critical "+MainService.capitalizeFirstLetter(message)+" Parameters ";
		$scope.equipmentImage = MainService.getEquipmentImagePaths(message);
    });

	$scope.equipmentImpParams = [];

	// $scope.equipmentImpParams = [{
	// 	name: 'Engine Speed', //1 - ATTR_ID
	// 	value: '1500 RPM',
	// 	warning: false
	// },{
	// 	name: 'Crankcase Pressure', //4
	// 	value: '800 PSI',
	// 	warning: false
	// },{
	// 	name: 'Fuel Consumption Rate', //3
	// 	value: '476 L/hr',
	// 	warning: false
	// },{
	// 	name: 'Surface Temperature', //2
	// 	value: '42 C',
	// 	warning: false
	// }];

	time = moment($.now()).format("DD/MM/YYYY HH:mm");
	$scope.chartParams.subtitle="Last Refreshed at "+time;

	$scope.showPredictions = function(option){
		$scope.tempWarn = option.warning;
		$scope.sensorLocation = option.sensorLocation;

		$('#tempWidgetOverlay').css({'left':'0','opacity': '1'});
	}

	$scope.removePredictions = function(){
		$('#tempWidgetOverlay').css({'left':'-50%','opacity': '0'});
	}

	$scope.getData = function(){

		//To get details of all attached temperature sensors
		MainService.getEquipmentSensorStats($state.params.id,'Temperature').then(function(data){
			if(data != null && data != undefined && data.constructor === Array && data.length > 0){
				$scope.equipName = data[0].EQUIPMENT_NAME;
				$scope.equipmentImpParams = data.map(function(v){
					var x = {};
					x.sensorId = v.SENSOR_ID;
					x.name = v.SENSOR_NAME+": "+v.SENSOR_LOCATION;
					x.sensorLocation = v.SENSOR_LOCATION;
					x.value = "NA";
					x.warning = false;
					x.timestamp = "";
					return x;
				});

				//To get the alert status(s) of the temperature sensors attached to the equipment
				MainService.getTempAlertState(data[0].RIG_EQUIPMENT_ID,"Temperature").then(function(data){
					if(data != null && data != undefined){
						var temp1 = [];
						
						try{
							temp1 = JSON.parse(JSON.parse(data));
						}catch(e){
							console.log(e);
						}

						if(temp1 != null && temp1 != undefined && temp1.constructor === Array && temp1.length > 0){
							$.each($scope.equipmentImpParams,function(index,value){
								var temp = temp1.filter(function(v){
									return v.SensorMac == value.sensorId;
								})
								value.warning = temp[0].alert;
							})
						}
					}
				},function(err){
					console.log(err);
				})

				//To get temperature data
				MainService.getLatestCriticalParams($state.params.id).then(function(data){
					if(data != undefined && data != null && data.constructor === Array && data.length != 0){
						$scope.chartParams.subtitle="Last Refreshed at "+moment($.now()).format("DD/MM/YYYY HH:mm");
						if($scope.equipmentImpParams.constructor === Array && $scope.equipmentImpParams.length > 0){
							$.each(data,function(index,value){
								$.each($scope.equipmentImpParams,function(i,v){
									if(v.sensorId == value.SENSOR_ID){
										v.value = parseFloat(value.ATTR_VALUE).toFixed(2)+" "+value.UOM_QUANTITY_TYPE;
										v.timestamp = moment(value.MEASURED_DATE).format("DD/MM/YYYY HH:mm");
										//for generating temperature alert
										if(parseInt(v.value) > 34 || parseInt(v.value) < 12){
											v.warning = true;
										}
										else{
											v.warning = false;
										}
										return false;									
									}
								})
							});
						}else{
							$scope.equipmentImpParams = [];
						}
					}
				},function(err){
					console.log(err);
				})

			}else{
				$scope.equipmentImpParams = [];					
			}
		},function(data){
			console.log(data);
		});
	}

	$scope.getData();

	equipmentCriticParamInterval = setInterval(function(){
		//call the function here
		$scope.getData();
	}, 1000*30);
	
	intervalsList.push(equipmentCriticParamInterval);

	$scope.openModal = function(currentView){
		$rootScope.$broadcast('openEquipmentModalView',currentView);
	}
}).controller('EquipmentActivityScheduleCtrl',function($scope,GensetService,$timeout,$state,$rootScope){
	$scope.chartParams = {
		title: "Maintenance Activity Checklist",
		subtitle:"Status"
	}

	$scope.type="D";

	var selectedType = "DM";

	setInterval(function(){
		$('li#predictive > a').fadeToggle('slow');
	},500)

	 $scope.typeFun = function(type,event){
        selectedType=type;
        fetchActivityChecklistData();
		$("#filterEquipment li.active").removeClass('active');
		angular.element(event.currentTarget).addClass('active');
        $rootScope.$broadcast('highlightType',type);	
	};

	equipmentCheckListInterval = setInterval(function(){
		fetchActivityChecklistData();		
	}, 1000*30);
	intervalsList.push(equipmentCheckListInterval);

	function fetchActivityChecklistData(){
		GensetService.getActivityChecklist($state.params.id,selectedType).then(function(data){
			if(data != undefined && data != null && data.constructor === Array && data.length != 0){
				$scope.tableData=data;
			}else{
				$scope.tableData = [];
			}
        },function(err){
            console.log(err);
        });
	}
	$scope.tableData = [];
	
	fetchActivityChecklistData();

	$scope.UpdateStatus=function(index){
		bootbox.confirm("Do you want to close the activity?", function(result) {
			if(result==true){

				if(selectedType != 'PM'){
					var userId=$scope.user.Id;

					//update closing date and last_update_user_id
					GensetService.updateActivityStatus($scope.tableData[index].TRACKER_ID,userId).then(function(data){
						$scope.tableData[index].STATUS=1;
					},function(err){
						console.log(err);
					});

					//update closing date in equip maint table   
					// GensetService.updateEquipMaintClosingDate($scope.tableData[index].TRACKER_ID).then(function(data){
					// },function(err){
					// 	console.log(err);
					// });
					
					//log event in event table
					GensetService.updateEventLog($scope.tableData[index].ACTIVITY_ID,$state.params.id,$scope.tableData[index].ACTIVITY_DESC).then(function(data){			
					},function(err){
						console.log(err)
					});
					//refresh maint and activity table on ui
					
					fetchActivityChecklistData();
					$rootScope.$broadcast('refreshMainSch','');
					//If all the status are closed, save a common comment
					GensetService.getActivityChecklist($state.params.id,selectedType).then(function(data){
						if(data != undefined && data != null && data.constructor == Array){
							var dataLength=data.length;
							var statusAll=1;
							
							for(var check=0;check<dataLength;check++){
								if(data[check].STATUS==0){
									statusAll=0;
									break;
								}
							}
							// if all the checklists are closed, log a common comment
							if(statusAll==1){
								bootbox.prompt("Please enter comment", function(result) {
									var comment = "";   
									if (result !== undefined && result!=null && result.length!=0) {  
										comment = result;
									} else{
										comment = "Maintenance closed."
									}

									//update comment in equip maint table
									GensetService.updateCheckListComment($scope.tableData[index].TRACKER_ID,comment).then(function(data){
										$rootScope.$broadcast('refreshMainSch','');
									},function(err){
										console.log(err);
									});

								});
							}
						}					
					},function(err){
						console.log(err);
					});
				}else {
					bootbox.prompt("Please enter comment", function(result) {
						var comment = "";   
						if (result !== undefined && result!=null && result.length!=0) {  
							comment = result;
						} else{
							comment = "Maintenance closed."
						}

						GensetService.updatePredictiveMaintenance($scope.tableData[index].RIG_EQUIPMENT_ID,comment,$scope.user.Id).then(function(data){
							$scope.$emit('popup',data,'info');
							fetchActivityChecklistData();
						},function(err){
							console.log(err);
							$scope.$emit('popup',err,'error');
						})
					});
				}
			}
		}); 
	}
}).controller('EquipmentIncLogController',function($scope,$rootScope,$state,MainService){
	
	$scope.chartParams = {
		title : "Alarm Log"
	};
	$scope.equipmentIncLog=[];
	$scope.allClosed = true;
	$scope.currInc = -1;
	
	$scope.getData = function(){
		MainService.getIncidentDetails('equipment',$state.params.id).then(function(data){
			if(data!=undefined && data != null && data.constructor == Array && data.length != 0){
				console.log("Superman");
				console.log(data);
				$scope.equipmentIncLog = data.filter(function(value){
					return value.INCIDENT_STATUS==0?true:false;
				});
				$scope.allClosed = MainService.closeAllIncidents($scope.equipmentIncLog);
			}else{
				$scope.equipmentIncLog = [];
			}
		},function(data){
			console.log(data.ErrorMessage);		
		});
	}
	
	$scope.getData();
	equipmentIncLogInterval = setInterval(function(){
		$scope.getData();
	},1000*30);
	
	intervalsList.push(equipmentIncLogInterval);
	
	$scope.openModal = function(option,index){
		$scope.currInc = index;
		$rootScope.$broadcast('openEquipmentModal',[option,index]);
	}
	
	$rootScope.$on('saveEquipmentIncident',function(event,status,indexVal){
		// $scope.gensetIncLog[indexVal].INCIDENT_STATUS = status;
		// $scope.allClosed = MainService.closeAllIncidents($scope.gensetIncLog);
		$scope.getData();
	});
	
}).controller('EquipmentEventLogController',function($scope,$state,$rootScope,MainService){
	$scope.chartParams = {
		title: "Event Feed",
		subtitle:"Last 10",
		linkEnabled: true,
		linkTitle: "View Alarms",
		modalId: '#equipmentModal',
		currentView: 'incidentLog'
	}
	$scope.openModal = function(currentView){
		$rootScope.$broadcast('openEquipmentModalView',currentView);
	}
	$scope.tableData = [];
	
	$scope.getData = function(){
		MainService.getEventDetails('genset',$state.params.id).then(function(data){
			if(data != undefined && data != null && data.constructor == Array && data.length!=0){
				$scope.tableData = data;
			}else{
				$scope.tableData = [];
			}
		},function(data){
			console.log(data.ErrorMessage);
		});
	}
	$scope.getData();
	gensetEventLogInterval = setInterval(function(){
		$scope.getData();
	},1000 * 30);
	
	intervalsList.push(gensetEventLogInterval);
	
}).controller('EquipmentMaintenanceCycleCtrl',function($scope,$rootScope,GensetService,$state){
		$scope.chartParams = {
			title : "Maintenance Schedule",
			subtitle : "Last & Upcoming",
			linkTitle:"Maintenance History",
			linkEnabled:true,						
			currentView: 'maintenanceHistory'
		};
		
		$scope.tableHeadData=[{col1:'Maintenance Type',col2:'Last',col3:'Upcoming',col4:'Comment'}];
				
		$scope.tableData=[];
		$scope.rcvHigh="DM";
		
		$rootScope.$on('highlightType',function(event, value){
			$scope.rcvHigh=value;
		});
		
		$rootScope.$on('refreshMainSch',function(event,mess){
			fetchMaintenanceScheduleData();
		});

		//to get all the maintenance data 	
		fetchMaintenanceScheduleData();

		equipmentMaintenanceInterval = setInterval(function(){
			fetchMaintenanceScheduleData();		
		}, 1000*30);

		intervalsList.push(equipmentMaintenanceInterval);

		function fetchMaintenanceScheduleData(){
			GensetService.getMaintenanceScheduleData($state.params.id).then(function(data){
				if(data != null && data != undefined && data.constructor == Array && data.length != 0){
					$scope.tableData=[];
					for(var maint=0;maint<data.length;maint++){
						var type;
						var order;
						if(data[maint].Type=="DM"){
							type="Daily (DM)";
							order=0;
						}else if(data[maint].Type=="WM"){
							type="Weekly (WM)";
							order=1;
						}else if(data[maint].Type=="MM"){
							type="Monthly (MM)";
							order=2;
						}else if(data[maint].Type=="QM"){
							type="Quarterly (QM)";
							order=3;
						}else if(data[maint].Type=="HYM"){
							type="Half Yearly (HYM)"
							order=4;
						}else if(data[maint].Type=="YM"){
							type="Yearly (YM)"
							order=5;
						}else if(data[maint].Type=="PM"){
							type="Predictive (PM)"
							order=6;
						}

						var last;
						var next;
						if(data[maint].last_1!=null){
							last=moment(data[maint].last_1).format("DD/MM/YYYY HH:mm");
						}
						else{
							last="-";
						}
						if(data[maint].next_1!=null){
							next=moment(data[maint].next_1).format("DD/MM/YYYY HH:mm");
						}
						else{
							next="-";
						}
						
						var REMARK="";
						if(data[maint].REMARK==null||data[maint].REMARK.length==0){
							REMARK="-";
						}
						else
							REMARK=data[maint].REMARK;
						jsonObject={"type":type, "last":last, "next":next, "order":order,'high':data[maint].Type,"Comment":REMARK};
						$scope.tableData.push(jsonObject);
					}

					$scope.tableData.sort(function(a,b){
						return a.order-b.order;
					})
				}
				else{
					$scope.tableData=[];
				}
			},function(err){
				console.log(err.error_message);
			});
		}

		$scope.openModal = function(currentView){
			$rootScope.$broadcast('openEquipmentModalView',currentView);
		}

}).controller('EquipmentMaintenanceBreakdownCtrl',function($scope,GensetService,$state,$rootScope){
	$scope.chartParams = {
		title : "Unplanned Maintenance Summary",
		subtitle : "Last 6 Instances"
		// linkTitle:"Unplanned Maintenance History",
		// linkEnabled: true,						
		// currentView: 'unplannedMaintenanceHistory'
	}

	$scope.type="DM";
	var selectedType = "DM";

	//$scope.tableData = [];
	$scope.plannedData = [];
	$scope.unplannedData = [];
	
	$scope.plannedBgColor = 'rgba(1, 184, 170,0.6)';
	$scope.unplannedBgColor = 'rgb(254, 150, 102)';

	$scope.plannedTextColor = 'rgba(0, 27, 25, 0.6)';
	// $scope.unplannedTextColor = '#692A14';
	$scope.unplannedTextColor = '#211e21';

	$scope.typeFun=function(type,event){
		$scope.type = type; 
		selectedType = type;
		$("#filterEquipmentBreakdown li.active").removeClass('active');
		angular.element(event.currentTarget).addClass('active');
		fetchSixInstanceData();
	}

	fetchSixInstanceData();

	equipmentSixInstanceInterval = setInterval(function(){
		fetchSixInstanceData();		
	}, 1000*30);
	intervalsList.push(equipmentSixInstanceInterval);

	function fetchSixInstanceData(){
		GensetService.getSixInstanceData($state.params.id,selectedType).then(function(data){	
			//console.log(data);
			if(data!=undefined && data != null && data.constructor == Array && data.length!=0){
				console.log(data);
				// $scope.tableData = [];
				// for(var i=0;i<data.length;i++){
				// 	var instances = {};
				// 	switch(data[i].Type){
				// 		case 'DM' :
				// 			instances = {mon: "",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''};
				// 			instances.backgroundcolor = 'rgba(1, 184, 170,0.6)';
				// 			instances.PM = data[i].REMARK;
				// 			instances.mon = moment(data[i].next_1).format("DD/MM/YYYY");
				// 			break;
				// 		case 'WM' :
				// 			instances = {visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''};
				// 			instances.backgroundcolor = 'rgba(1, 184, 170,0.6)';
				// 			instances.PM = data[i].REMARK;
				// 			instances.mon = moment(data[i].next_1).format("DD/MM/YYYY");
				// 			break;
				// 		case 'MM' :
				// 			instances = {visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''};
				// 			instances.backgroundcolor = 'rgba(1, 184, 170,0.6)';
				// 			instances.PM = data[i].REMARK;
				// 			instances.mon = moment(data[i].next_1).format("DD/MM/YYYY");
				// 			break;
				// 		case 'QM' :
				// 			instances = {visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''};
				// 			instances.backgroundcolor = 'rgba(1, 184, 170,0.6)';
				// 			instances.PM = data[i].REMARK;
				// 			instances.mon = moment(data[i].next_1).format("DD/MM/YYYY");
				// 			break;
				// 		case 'HYM' :
				// 			instances = {visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''};
				// 			instances.backgroundcolor = 'rgba(1, 184, 170,0.6)';
				// 			instances.PM = data[i].REMARK;
				// 			instances.mon = moment(data[i].next_1).format("DD/MM/YYYY");
				// 			break;
				// 		case 'YM' :
				// 			instances = {visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''};
				// 			instances.backgroundcolor = 'rgba(1, 184, 170,0.6)';
				// 			instances.PM = data[i].REMARK;
				// 			instances.mon = moment(data[i].next_1).format("DD/MM/YYYY");
				// 			break;
				// 		case 'UBD' :
				// 			instances = {visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''};
				// 			instances.UPM = data[i].REMARK;
				// 			instances.backgroundcolorBD = 'rgb(254, 150, 102)';
				// 			instances.mon = moment(data[i].last_1).format("DD/MM/YYYY");
				// 			break;
				// 	}
					
				// 	$scope.tableData.push(instances);
				// }

				var plannedData = data.filter(function(v){
					return v.Type.toLowerCase()!='ubd';
				});

				$scope.unplannedData = data.filter(function(v){
					return v.Type.toLowerCase()=='ubd';
				}).map(function(g){
					var f = {};
					f = g;
					//f.REMARK = f.REMARK + " - " +  moment(f.last_1).format("DD/MM/YYYY");
					f.REMARK = f.REMARK;// + " - " +  moment(f.next_1).format("DD/MM/YYYY");
					f.Day = moment(g.next_1).date();
					f.Year = moment(g.next_1).year();
					var z = moment.months()[moment(g.next_1).month()];
					f.Month = z.slice(0,3);
					f.actual_start_date = moment(f.last_1).format("DD/MM/YY") == "Invalid date"?"-":moment(f.last_1).format("DD/MM/YY");
					f.actual_end_date = moment(f.next_1).format("DD/MM/YY") == "Invalid date"?"-":moment(f.next_1).format("DD/MM/YY");
					return f;
				});
				
				$scope.plannedData = data.filter(function(v){
					return v.Type.toLowerCase()!='ubd';
				}).map(function(g){
					var f = {};
					f = g;
					//f.REMARK = f.REMARK + " - " +  moment(f.last_1).format("DD/MM/YYYY");
					f.REMARK = f.REMARK; // + " - " +  moment(f.next_1).format("DD/MM/YYYY");
					f.Day = moment(g.next_1).date();
					f.Year = moment(g.next_1).year();
					var z = moment.months()[moment(g.next_1).month()];
					f.Month = z.slice(0,3);
					f.actual_start_date = moment(f.last_1).format("DD/MM/YY") == "Invalid date"?"-":moment(f.last_1).format("DD/MM/YY");
					f.actual_end_date = moment(f.next_1).format("DD/MM/YY") == "Invalid date"?"-":moment(f.next_1).format("DD/MM/YY");
					return f;
				});

				// var minTimestamp = Number.POSITIVE_INFINITY;
				// var maxTimestamp = Number.NEGATIVE_INFINITY;
				
				// $.each(plannedData,function(ind,val){
				// 	var c = moment(moment(val.last_1,'YYYY-MM-DDTHH:mm:ss.SSSZ').format('DD/MM/YYYY'),'DD/MM/YYYY').valueOf();
				// 	if(c < minTimestamp){
				// 		minTimestamp = c;
				// 	}
				// 	if(c > maxTimestamp){
				// 		maxTimestamp = c;
				// 	}
				// }).map(function(u){
				// 	var t = u;
				// 	t.COMMENT = moment(u.last_1,'YYYY-MM-DDTHH:mm:ss.SSSZ').format('DD/MM/YYYY')+" - "+u.REMARK;
				// 	return t;
				// });

				// var unplannedData = data.filter(function(val){
				// 	return val.Type.toLowerCase() == 'ubd'
				// 		&& moment(moment(val.last_1,'YYYY-MM-DDTHH:mm:ss.SSSZ').format('DD/MM/YYYY'),'DD/MM/YYYY').valueOf() != undefined 
				// 		&& moment(moment(val.last_1,'YYYY-MM-DDTHH:mm:ss.SSSZ').format('DD/MM/YYYY'),'DD/MM/YYYY').valueOf() >= minTimestamp
				// 		&& moment(moment(val.last_1,'YYYY-MM-DDTHH:mm:ss.SSSZ').format('DD/MM/YYYY'),'DD/MM/YYYY').valueOf() <= maxTimestamp;
				// });

				// plannedData.sort(function(a,b){
				// 	return moment(moment(a.last_1,'YYYY-MM-DDTHH:mm:ss.SSSZ').format('DD/MM/YYYY'),'DD/MM/YYYY').valueOf() - moment(moment(b.last_1,'YYYY-MM-DDTHH:mm:ss.SSSZ').format('DD/MM/YYYY'),'DD/MM/YYYY').valueOf();
				// });

				// var unplannedDataGrouped = [];
				// if(plannedData.length > 1){
				// 	$.each(plannedData,function(index,value){
				// 		var a = index;
				// 		var b = index + 1;
				// 		if(plannedData[b] != undefined){
				// 			var c = moment(moment(plannedData[b].last_1,'YYYY-MM-DDTHH:mm:ss.SSSZ').format('DD/MM/YYYY'),'DD/MM/YYYY').valueOf();
				// 			var d = moment(moment(plannedData[a].last_1,'YYYY-MM-DDTHH:mm:ss.SSSZ').format('DD/MM/YYYY'),'DD/MM/YYYY').valueOf();
				// 			var ubd = unplannedData.filter(function(g){
				// 				return moment(moment(g.last_1,'YYYY-MM-DDTHH:mm:ss.SSSZ').format('DD/MM/YYYY'),'DD/MM/YYYY').valueOf() <= c
				// 						&& moment(moment(g.last_1,'YYYY-MM-DDTHH:mm:ss.SSSZ').format('DD/MM/YYYY'),'DD/MM/YYYY').valueOf() >= d;
				// 			})

				// 			var arr = [];
				// 			$.each(ubd,function(i,v){
				// 				arr.push(moment(v.last_1,'YYYY-MM-DDTHH:mm:ss.SSSZ').format('DD/MM/YYYY')+" - "+v.REMARK);
				// 			})
				// 			unplannedDataGrouped.push(arr);
				// 			a++;
				// 			b++;
				// 		}else{
				// 			return false;
				// 		}
				// 	})
				// }else if(plannedData.length == 1){
				// 	unplannedDataGrouped.push(moment(unplannedData[0].last_1,'YYYY-MM-DDTHH:mm:ss.SSSZ').format('DD/MM/YYYY')+" - "+unplannedData[0].REMARK);
				// }

				// $scope.plannedData = plannedData;
				// $scope.unplannedData = unplannedDataGrouped;

				//console.log($scope.unplannedData);
			}else{
				$scope.plannedData = [];
				$scope.unplannedData = [];
			}

        },function(err){
            console.log(err);
        });
	}

	$scope.openModal = function(currentView){
		$rootScope.$broadcast('openEquipmentModalView',currentView);
	}
	
	$scope.monthlyData=[];

}).controller('EquipmentMaintenanceHistoryCtrl',function($scope,$timeout,GensetService,$state,$rootScope){
	$scope.chartParams = {
		title : "Maintenance History"
	}

	$scope.totalData = [];
	$scope.tableHeadData=['Planned Date','Activity Date','Type','Assignee','Closed By','Comment'];
	$scope.tableData=[];
	

	$rootScope.$on('getMaintHist',function(event,mess){
		$scope.selectedType="";
		fetchMaintenanceHistory(mess[0],mess[1]);
	})

	var initStartDate = moment().subtract(1,'months');
	var initEndDate = moment();

	initStartDate = initStartDate.format('YYYY-MM-DD');
	initEndDate = initEndDate.format('YYYY-MM-DD');

	setInterval(function(){
		$('li#predictiveHistory > a').fadeToggle('slow');
	},500)

	fetchMaintenanceHistory(initStartDate,initEndDate);

	function fetchMaintenanceHistory(startDate,endDate){
		GensetService.getMaintenanceHistory($state.params.id,startDate,endDate).then(function(data){
			if(data!=undefined && data != null && data.constructor === Array && data.length!=0){
				//$scope.tableData = data;
				$scope.totalData = data;
				//$scope.tableData = $scope.selectedType != '' ? $filter('filter')($scope.totalData,{ABBREVIATION: $scope.selectedType}) : $scope.totalData;
				if($scope.selectedType != ''){
					$scope.tableData = $scope.totalData.filter(function(v){
						return v.ABBREVIATION == $scope.selectedType || v.ABBREVIATION == 'UBD';
					});
				}else{
					$scope.tableData = $scope.totalData;
				}
				//$scope.tableData = $filter('filter')($scope.totalData,{ABBREVIATION: $scope.selectedType})
			}
			else{
				$scope.tableData = [];
			}
		},function(err){
			console.log(err);
		});
	}

	$scope.selectedType="";

	$scope.typeFun=function(type,event){
	 	$scope.selectedType=type;
		//$scope.tableData = $scope.selectedType != '' ? $filter('filter')($scope.totalData,{ABBREVIATION: $scope.selectedType}) : $scope.totalData;
		$("#filterEquipmentMaintHistory li.active").removeClass('active');
		if($scope.selectedType != ''){
			$scope.tableData = $scope.totalData.filter(function(v){
				return v.ABBREVIATION == $scope.selectedType || v.ABBREVIATION == 'UBD';
			});
			angular.element(event.currentTarget).addClass('active');
		}else{
			$scope.tableData = $scope.totalData;
		}
	}
	
	// $timeout(function(){
	// 	var domElement = $('#filterEquipmentMaintHistory > li').first();
	// 	angular.element(domElement).triggerHandler('click');
	// },0);
}).controller('EquipmentModalController',function($scope,$rootScope,MainService,$timeout,GensetService,$state){
	
	//For the historical data in charts - Real Time Insights
	$scope.historicalChartConfig = {
		chartType: 'line',
		margin : {
			left: 80,
			right: 60,
			bottom: 50,
			top: 0
		},
		yAxisLabelDistance : -5,
		yAxisLabel : "Y-Axis",
		xAxisLabel : "Time",
		chartId: 'historicalchart',
		height: 320,
		xDataFunction: function(){
			return function(d){
				if(d != null && d != undefined){
					if(d[0] != null && d[0] != undefined){
						return moment(d[0],'YYYY-MM-DDTHH:mm:ss.SSSZ').valueOf();
					}
				}
			}
		},
		yDataFunction: function(){
			return function(d){
				if(d != null && d != undefined){
					if(d[1] != null && d[1] != undefined){
						return d[1];
					}
				}
			}
		}
	}

	$scope.historicalChartData = [{
		key: 'Superman',
		color: 'green',
		values: []
	}];

	//For the historical data in charts - Unplanned Maintenance History
	$scope.unplannedHistoryConfig = {
		chartType: 'line',
		margin : {
			left: 80,
			right: 60,
			bottom: 50,
			top: 0
		},
		yAxisLabelDistance : -5,
		yAxisLabel : "Y-Axis",
		xAxisLabel : "Time",
		chartId: 'unplannedHistoryChart',
		height: 320
	}

	$scope.unplannedHistoryData = [{
		key: 'Superman',
		color: 'green',
		values: []
	},{
		key: 'Unplanned Maintenance',
		color: 'blue',
		values: []
	}];

	//Temperature History Graphs
	$scope.temperatureHistoryConfig = {
		chartType: 'line',
		margin : {
			left: 80,
			right: 60,
			bottom: 50,
			top: 0
		},
		yAxisLabelDistance : -5,
		yAxisLabel : "Y-Axis",
		xAxisLabel : "Time",
		chartId: 'temperatureHistory',
		height: 320,
		xDataFunction: function(){
			return function(d){
				if(d != null && d != undefined){
					if(d[0] != null && d[0] != undefined){
						return moment(d[0],'YYYY-MM-DDTHH:mm:ss.SSSZ').valueOf();
					}
				}
			}
		},
		yDataFunction: function(){
			return function(d){
				if(d != null && d != undefined){
					if(d[1] != null && d[1] != undefined){
						console.log(d[1]);
						return d[1];
					}
				}
			}
		}
	}

	$scope.temperatureHistoryData = [{
		key: 'TemperatureData',
		color: 'green',
		values: []
	}];

	//For closing incidents/alarms
	$rootScope.$on('openEquipmentModal',function(event,mess){
		$scope.equipId = mess[0].RIG_EQUIPMENT_ID;
		$scope.desc = mess[0].INCIDENT_DESCRIPTION;
		$scope.action = mess[0].INCIDENT_ASSIGNEE_COMMENT;
		$scope.id = mess[0].EQUIP_INCIDENT_ID;
		$scope.status = mess[0].INCIDENT_STATUS+'';
		$scope.currentIndex = mess[1];
		$('#closeIncidentForm').slideDown(300);
	});

	$scope.modalDate="EquipmentModalCal";
	dateRangePickerFnct($scope.modalDate,"down","left","all");

	$scope.saveIncident = function(){
		if(parseInt($scope.status)==1){
			if($scope.action == "" || $scope.action == undefined || $scope.action == null){
				$scope.action = "Alarm \""+$scope.desc+"\" closed";
			}
			//$scope.action = $scope.action ? $scope.action : "Alarm \""+$scope.desc+"\" closed";
			MainService.updateIncident($scope.id,$scope.action,$scope.status).then(function(data){
				
			},function(data){
				console.log(data.ErrorMessage);
			});

			MainService.updateEventLogForIncidents($scope.equipId,$scope.desc).then(function(data){

			},function(err){
				console.log(err.ErrorMessage);
			});
		}else if(parseInt($scope.status)==0 && $scope.action != '' && $scope.action != undefined && $scope.action != null){
			MainService.updateIncident($scope.id,$scope.action,$scope.status).then(function(data){
				
			},function(data){
				console.log(data.ErrorMessage);
			});
		}
		$('#closeIncidentForm').slideUp(300);
		$rootScope.$broadcast('saveEquipmentIncident',parseInt($scope.status),$scope.currentIndex);		
	}

	$('#equipmentModal').on('show.bs.modal',function(){
		$('#closeIncidentForm').hide();
	});

	function fireResize(){
		if (document.createEvent) { // W3C
			var ev = document.createEvent('Event');
			ev.initEvent('resize', true, true);
			window.dispatchEvent(ev);
		}
		else { // IE
			element = document.documentElement;
			var event=document.createEventObject();
			element.fireEvent("onresize",event);
		}
	}

	$('#equipmentModal').on('shown.bs.modal',function(){
		$timeout(function(){
			fireResize();
		},1);
	});
	
	$rootScope.$on('openEquipmentModalView',function(event,currentView,sensorId){
		$scope.currentView = currentView;
		if($scope.currentView=="incidentLog"){
			$scope.title="Alarms View";
			$scope.subtitle="";
		}
		else if($scope.currentView=="maintenanceHistory"){
			//$scope.modalDate="EquipmentModalCal";
			$scope.title="Maintenance History";
            var startDate="";
            var endDate="";
            var startDate1="";
			var endDate1="";

			$scope.subtitle="From "+startDate+" to "+endDate;	
			//dateRangePickerFnct($scope.modalDate,"down","left");
			
			$timeout(function(){	
				var dateObject=$('#'+$scope.modalDate).data('daterangepicker');
				startDate=moment(dateObject.startDate._d).format('DD/MM/YYYY');
				endDate=moment(dateObject.endDate._d).format('DD/MM/YYYY');
				startDate1=moment(dateObject.startDate._d).utc().format('YYYY/MM/DD');
				endDate1=moment(dateObject.endDate._d).utc().format('YYYY/MM/DD');
				var data=[startDate1,endDate1];
				$rootScope.$broadcast('getMaintHist',data);
				$scope.subtitle="From "+startDate+" to "+endDate;
			},50);
		}else if($scope.currentView=="historicalGraphs"){
			
			$scope.historicalChartData[0].values = [];
			
			var historyEnd = moment($.now()).format('DD/MM/YYYY');
			var historyStart = moment($.now() - 86400*1000).format('DD/MM/YYYY');

			var startDate = moment($.now() - 86400*1000).format('YYYY-MM-DD');
			var endDate = moment($.now()).format('YYYY-MM-DD');

			$scope.subtitle = "From "+historyStart+" to "+historyEnd;

			$scope.title="Historical Sensor Data";
			//dateRangePickerFnct($scope.modalDate,"down","left","all");

			MainService.getSensorHistoricalData(sensorId,startDate,endDate).then(function(data){
				var x = [];
				
				if(data != undefined && data != null && data.constructor == Array && data.length != 0){
					x = data.map(function(v){
						return [v.MEASURED_DATE,v.ATTR_VALUE];
					});
					
					$scope.historicalChartConfig.yAxisLabel = data[0].ATTR_NAME;
					$scope.historicalChartData[0].key = data[0].ATTR_NAME;
					$scope.historicalChartData[0].values = x;
				}		
			},function(err){
				console.log(err);
			});
		}else if($scope.currentView=="temperatureHistory"){
			
			$scope.temperatureHistoryData[0].values = [];
			
			var historyEnd = moment($.now()).format('DD/MM/YYYY');
			var historyStart = moment($.now() - 86400*1000).format('DD/MM/YYYY');

			var startDate = moment($.now() - 30 * 86400*1000).format('YYYY-MM-DD');
			var endDate = moment($.now()).format('YYYY-MM-DD');

			$scope.tempStartDate = startDate;
			$scope.tempEndDate = endDate;

			$scope.subtitle = "From "+historyStart+" to "+historyEnd;

			$scope.title="Historical Sensor Data";
			//dateRangePickerFnct($scope.modalDate,"down","left","all");
		}
		// else if($scope.currentView=="unplannedMaintenanceHistory"){
		// 	$scope.title="Unplanned Maintenance History";
		// 	$scope.subtitle="";
		// }


		$('#'+$scope.modalDate).on('apply.daterangepicker', function(ev, picker) {
			
			if($scope.currentView=="maintenanceHistory"){
				var dateObject=$('#'+$scope.modalDate).data('daterangepicker');
				startDate=moment(picker.startDate._d).format('DD/MM/YYYY');
				endDate=moment(picker.endDate._d).format('DD/MM/YYYY');
				startDate1=moment(dateObject.startDate._d).utc().format('YYYY/MM/DD');
				endDate1=moment(dateObject.endDate._d).utc().format('YYYY/MM/DD');

				// call maintenance data form db for particular date
				var data=[startDate1,endDate1];
				$rootScope.$broadcast('getMaintHist',data);			   
				$scope.subtitle="From "+startDate+" to "+endDate;
				$timeout(function(){
					$scope.$apply();
				},1)
			}else if($scope.currentView=="historicalGraphs"){

				startDate = moment(picker.startDate._d).format('YYYY-MM-DD');
				endDate = moment(picker.endDate._d).format('YYYY-MM-DD');

				var historyStart = moment(picker.startDate._d).format('DD/MM/YYYY');
				var historyEnd = moment(picker.endDate._d).format('DD/MM/YYYY');

				$scope.subtitle = "From "+historyStart+" to "+historyEnd;
				// alert(sensorId);
				// alert(startDate);
				// alert(endDate);
				MainService.getSensorHistoricalData(sensorId,startDate,endDate).then(function(data){
					var x = [];
					if(data != undefined && data != null && data.constructor == Array && data.length != 0){
						x = data.map(function(v){
							return [v.MEASURED_DATE,v.ATTR_VALUE];
						});
						
						$scope.historicalChartConfig.yAxisLabel = data[0].ATTR_NAME;
						$scope.historicalChartData[0].key = data[0].ATTR_NAME;
						$scope.historicalChartData[0].values = x;
					}else{
						$scope.historicalChartData[0].values = [];
					}
				},function(err){
					console.log(err);
				});

				$timeout(function(){
					$scope.$apply();
				},1)
			}
			else if($scope.currentView=="temperatureHistory"){

				startDate = moment(picker.startDate._d).format('YYYY-MM-DD');
				endDate = moment(picker.endDate._d).format('YYYY-MM-DD');

				$scope.tempStartDate = startDate;
				$scope.tempEndDate = endDate;

				var historyStart = moment(picker.startDate._d).format('DD/MM/YYYY');
				var historyEnd = moment(picker.endDate._d).format('DD/MM/YYYY');

				$scope.subtitle = "From "+historyStart+" to "+historyEnd;

				if($scope.tempSensorSelected!=undefined && $scope.tempSensorSelected!=null && $scope.tempSensorSelected!=''
				&& $scope.tempStartDate!=undefined && $scope.tempStartDate!=null && $scope.tempStartDate!=''
				&& $scope.tempEndDate!=undefined && $scope.tempEndDate!=null && $scope.tempEndDate!=''){
					
					MainService.getTemperatureHistoricalData($scope.tempSensorSelected.SENSOR_ID,$scope.tempStartDate,$scope.tempEndDate).then(function(data){
						var x = [];
						if(data != undefined && data != null && data.constructor == Array && data.length != 0){
							x = data.map(function(v){
								return [v.MEASURED_DATE,v.ATTR_VALUE];
							});
							
							$scope.temperatureHistoryConfig.yAxisLabel = data[0].ATTR_NAME;
							$scope.temperatureHistoryData[0].key = data[0].ATTR_NAME;
							$scope.temperatureHistoryData[0].values = x;
						}else{
							$scope.temperatureHistoryData[0].values = [];
						}
					},function(err){
						console.log(err);
					});
				}

				$timeout(function(){
					$scope.$apply();
				},1)
			}
		});

		$('#equipmentModal').modal('show');
		
	});


	//Handling Temperature History portions

	$scope.tempSensorSelected = "";
	$scope.sensors = [];

	MainService.getEquipmentSensorStats($state.params.id,'Temperature').then(function(data){
		$scope.sensors = data;
	},function(data){
		console.log(data);
	});

	$scope.$watch('tempSensorSelected',function(newVal,oldVal){
		if(newVal != null && newVal != undefined && newVal != ''){
			
			if($scope.tempStartDate!=undefined && $scope.tempStartDate!=null && $scope.tempStartDate!=''
				&& $scope.tempEndDate!=undefined && $scope.tempEndDate!=null && $scope.tempEndDate!=''){
					MainService.getTemperatureHistoricalData(newVal.SENSOR_ID,$scope.tempStartDate,$scope.tempEndDate).then(function(data){
						var x = [];
						if(data != undefined && data != null && data.constructor == Array && data.length != 0){
							x = data.map(function(v){
								return [v.MEASURED_DATE,v.ATTR_VALUE];
							});
							
							$scope.temperatureHistoryConfig.yAxisLabel = data[0].ATTR_NAME;
							$scope.temperatureHistoryData[0].key = data[0].ATTR_NAME;
							$scope.temperatureHistoryData[0].values = x;

							console.log("He-man");
							console.log($scope.temperatureHistoryData);
						}else{
							$scope.temperatureHistoryData[0].values = [];
						}
					},function(err){
						console.log(err);
					});
				}
		}else{
			$scope.temperatureHistoryData[0].values = [];
		}
	})
}).controller('EquipmentSensorGraphsController',function($scope,$state,MainService,$rootScope,$interval){
	$scope.chartConfig = [];
	var sensorCharts = [];
	var batchStartId = undefined;
    $scope.loading = true;

	$scope.equipName = "";
	$scope.widgetConfig = [];

	$scope.chartData = [];

	var equipSensorInterval;
	var uniqueSensors = [];
	var commonThreshold = 0.0;

	$scope.hour = Math.abs(21 - new Date().getHours());
	$scope.minutes = Math.abs(60 - new Date().getMinutes());

	$interval(function(){
		$scope.hour = Math.abs(21 - new Date().getHours());
		$scope.minutes = Math.abs(60 - new Date().getMinutes());
	},1000)

	$scope.getSensorStats = function(){
		MainService.getEquipmentSensorStats($state.params.id,'Blower Vibration').then(function(data){
			if(data != undefined && data != null && data.constructor == Array && data.length != 0){
				$scope.equipName = data[0].EQUIPMENT_NAME;
				$.each(data,function(index,value){
					if($.inArray(value.SENSOR_ID,uniqueSensors) == -1){
						uniqueSensors.push(value.SENSOR_ID);
					}
				});

				//Get the Vibration Threshold for this type of equipment
				MainService.getVibrationThresholds(data[0].DESCRIPTION.toLowerCase()).then(function(data1){
					try{
						data1 = data1.replace(new RegExp('"','g'), "");
						commonThreshold = parseFloat(data1);
						$scope.getData();
					}catch(e){
						console.log(e);
					}
				},function(err1){
					console.log(err1);
				});

				for(j in uniqueSensors){
					var unit = undefined;
					var param = undefined;
					var sensorName = undefined;
					var sensorLocation = undefined;

					$scope.chartData.push({
						id: uniqueSensors[j],
						data: [{
							color: 'green',
							key: '',
							values : []
						},{
							color: 'grey',
							key: 'Baseline',
							values: [],
							strokeWidth: 1,
							classed: 'dashed'
						}]
					});

					for(var i=0;i<data.length;i++){
						if(data[i]['SENSOR_ID'] == uniqueSensors[j]){
							if(unit == undefined){
								unit = data[i]['UOM_NAME'];
							}
							if(param == undefined){
								param = data[i]['ATTR_NAME'];
							}
							if(sensorName == undefined){
								sensorName = data[i]['SENSOR_NAME']+": "+data[i]['SENSOR_LOCATION'];
							}

							if(sensorLocation == undefined){
								sensorLocation = data[i]['SENSOR_LOCATION'];
							}
						}
					}

					$scope.chartData[j].data[0].key = param;

					$scope.widgetConfig.push({
						title: sensorName+' Status',
						subtitle: 'No Alarms',
						sensorLocation: sensorLocation,
						status: 0,
						statusInfo: ""
					});

					$scope.widgetConfig.push({
						title: sensorName+' Vibration Graph',
						subtitle: unit,
						historyEnabled: true,
						sensorId: uniqueSensors[j],
						historyFunction: function(sensorId){
							$rootScope.$broadcast('openEquipmentModalView','historicalGraphs',sensorId);
						}
					});

					$scope.chartConfig.push({
						chartType: 'line',
						margin : {
							left: 80,
							right: 50,
							bottom: 50,
							top: 0
						},
						yAxisLabelDistance : -5,
						yAxisLabel : param,
						xAxisLabel : "Time",
						chartId: 'chart'+j,
						height: 143,
						useInteractiveGuideline: true,
						uniqueId: uniqueSensors[j],
						xDataFunction: function(){
							return function(d){
								if(d != null && d != undefined){
									if(d[0] != null && d[0] != undefined){
										return moment(d[0],'YYYY-MM-DDTHH:mm:ss.SSSZ').valueOf();
									}
								}
							}
						},
						yDataFunction: function(){
							return function(d){
								if(d != null && d != undefined){
									if(d[1] != null && d[1] != undefined){
										return d[1];
									}
								}
							}
						}
					})
				}

				equipSensorInterval = setInterval(function(){
					$scope.getData();
				},1000*30);
				intervalsList.push(equipSensorInterval);
			}else{
				$scope.loading = false;
			}
		},function(err){
			console.log(err);
			$scope.loading = false;
		});
	}

	$scope.getSensorStats();
	//Uncomment from here for quicker page loads during development
	$scope.getData = function(){
		MainService.getEquipmentSensorData($state.params.id).then(function(data){
			if(data != undefined && data != null && data.constructor == Array && data.length != 0){
				var lastRefreshedAt = "Last Refreshed at "+moment($.now()).format("DD/MM/YYYY HH:mm");

				$scope.$emit('refreshLastUpdate',lastRefreshedAt);

				var vibrationData = data.filter(function(c){
					return c.ATTR_DESC == 'Blower Vibration';
				});
				
				var statusData = data.filter(function(c){
					return c.ATTR_DESC == 'Blower Vibration Status';
				});

				for(j in uniqueSensors){
					for(var i=0;i<vibrationData.length;i++){
						if(vibrationData[i]['SENSOR_ID'] == uniqueSensors[j]){
							//Commenting for vibration data in bulk
							// if($scope.chartData[j].data[0].values.length > 10){
							// 	$scope.chartData[j].data[0].values.shift();						
							// }

							var vibTimes = $scope.chartData[j].data[0].values.map(function(d){
								return d[0];
							})
							
							if(vibTimes.indexOf(vibrationData[i].MEASURED_DATE) == -1){
								$scope.chartData[j].data[0].values.push([vibrationData[i].MEASURED_DATE,vibrationData[i].ATTR_VALUE]);
								$scope.chartData[j].data[1].values.push([vibrationData[i].MEASURED_DATE,commonThreshold]);
							}
							
							$scope.widgetConfig[2*j + 1].subtitle = "Last Updated at: "+moment(vibrationData[i].MEASURED_DATE).format('DD/MM/YYYY HH:mm');
						}
					}
					
					// for(var i=0;i<statusData.length;i++){
					// 	if(statusData[i]['SENSOR_ID'] == uniqueSensors[j]){
					// 		$scope.widgetConfig[2*j].subtitle = "Last Updated at: "+moment(statusData[i].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
					// 		if(statusData[i].ATTR_VALUE < 1){
					// 			$scope.widgetConfig[2*j].statusInfo = 'No Alarms';
					// 			$scope.widgetConfig[2*j].status = 0;
					// 		}else if(statusData[i].ATTR_VALUE == 1){
					// 			$scope.widgetConfig[2*j].statusInfo = 'Warning: Vibration levels above normal';
					// 			$scope.widgetConfig[2*j].status = 1;
					// 		}else if(statusData[i].ATTR_VALUE > 1){
					// 			$scope.widgetConfig[2*j].statusInfo = 'Alarm: Vibration levels exceeded threshold';
					// 			$scope.widgetConfig[2*j].status = 2;								
					// 		}
					// 	}
					// }	
				}

				//To get the alert status(s) of the temperature sensors attached to the equipment
				MainService.getTempAlertState(data[0].RIG_EQUIPMENT_ID,"Blower Vibration").then(function(data){
					if(data != null && data != undefined){
						var temp1 = [];

						try{
							temp1 = JSON.parse(JSON.parse(data));
						}catch(e){
							console.log(e);
						}

						if(temp1 != null && temp1 != undefined && temp1.constructor === Array && temp1.length > 0){
							for(j in uniqueSensors){
								$.each(temp1,function(index,value){
									if(value.SensorMac == uniqueSensors[j]){
										//$scope.widgetConfig[2*j].subtitle = "Last Updated at: "+moment(statusData[i].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
										$scope.widgetConfig[2*j].status = value.alert ? 2 : 0;
										$scope.widgetConfig[2*j].statusInfo = value.alert ? "Alarm: Vibration levels exceeded threshold" : "Vibration levels normal.";
										return false;
									}
								})
							}
						}
					}
				},function(err){
					console.log("Error in vib");
					console.log(err);
				})
			}
		},function(err){
			console.log(err);
		});
	}
});


function getMax(value){
	if(value!=undefined||value.length!=0){
		var max = 0;
		$.each(value,function(index,value1){
			max = value1[1]>max?value1[1]:max;
		})
		
		return Math.ceil(max+(10.0*max/100));
	}
	else{
		return 500;
	}
		
}

function getMin(value){
	if(value!=undefined||value.length!=0){
		var min = Number.POSITIVE_INFINITY;
		$.each(value,function(index,value1){
			min = value1[1]<min?value1[1]:min;
		})
		return Math.floor(min-(10.0*min/100));
	}
	else{
		return -1;
	}
}