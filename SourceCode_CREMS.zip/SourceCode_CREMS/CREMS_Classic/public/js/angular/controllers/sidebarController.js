angular.module('myApp').controller('SidebarController',function($scope,MainService,$rootScope,$location){
	
	$scope.currStore = 0;
	$scope.checkActiveCurrentStore = function(val){
		return val==$scope.currStore?true:false;
	}
	$scope.selectStore = function(index,event){
		$scope.currStore = index;
		$('[id^=dropdownsign_]').find('span.glyphicon').removeClass('glyphicon-triangle-right').addClass('glyphicon-triangle-bottom');
		$('#dropdownsign_'+index).find('span.glyphicon').removeClass('glyphicon-triangle-bottom').addClass('glyphicon-triangle-right');
		
		$rootScope.$broadcast('clearAndUpdateRig',$scope.rigNames[index]);
	}
	
	MainService.activateSidebarButton();
	
	$rootScope.$on('rigList',function(event,mess){
		$scope.rigNames = mess;
	});
})