
angular.module('myApp').controller('CompressorController',function($scope,$rootScope,MainService,GensetService,$state,$timeout){
	
	$scope.header = $state.params.id;
	$rootScope.$broadcast('updateRig',[{'name':$state.params.name,'url':'app.dashboard.compressor','params': {id: $state.params.id,name: $state.params.name},'type': 'equipment'},'equipment']);
	MainService.hideBreadcrumb(false);
	MainService.initialiseSettingsPanel();
	/*$scope.paramsToShow = {
		"Dew Point Temperature": true,
		"Motor Current": true,
		// "On/Off Time": true,
		"Compressor Outlet Temperature": true,
		"Cooling Water In Temperature": true,
		"Delivery Air Pressure": false,
		"Cooling Water Out Temperature": false
	};*/

	$scope.paramsToShow={};
	GensetService.getMappedParameters($state.params.id).then(function(data){
	
		if(data!=undefined&&data.length!=0){
			var count=1;
			var stringData="";
			for(params in data){
				if(count<5){
					$scope.paramsToShow[data[params].ATTR_NAME]=true;
				}
				else{
					$scope.paramsToShow[data[params].ATTR_NAME]=false;
				}
				count++;				
			}		
		}
			
	},function(err){
		console.log(err.error_message);
	});
	
	sessionStorage.setItem('lastState',JSON.stringify({
		state: 'app.dashboard.compressor',
		params: {
			id: $state.params.id,
			name: $state.params.name
		}
	}))
	
	$scope.paramClicked = function(key){
		$scope.paramsToShow[key] = !$scope.paramsToShow[key];		
		$scope.$broadcast('redrawGensetCharts','');
		$timeout(function(){
			$rootScope.$broadcast('updateChart','');
		},1);
	}	
	
	$scope.getData = function(){
		GensetService.getGensetParameters($state.params.id).then(function(data){
			$scope.currentTime=moment(new Date()).format('DD/MM/YYYY HH:mm');
			$scope.$broadcast('compParametersData',data);
		},function(err){
			console.log(err.error_message);
		});

		MainService.getEquipmentState($state.params.id).then(function(data){
			if(data!=undefined && data != null && data.constructor === Array && data.length > 0){
				switch(data[0].EQUIP_STATUS_ID){
					case 101:
					case 102:
					case 103:
						$scope.eqState = 'Deactivated';
						$scope.eqStatus = 'grey';
						break;
					case 104:
						$scope.eqState = 'Active';
						$scope.eqStatus = 'green';
						break;
					case 105:
						$scope.eqState = 'Active but not reachable';
						$scope.eqStatus = 'red';
						break;
					default:
						$scope.eqState = 'Deactivated';
						$scope.eqStatus = 'grey';
						break;
				}
			}
		},function(err){
			console.log(err.ErrorMessage);
		})
	}
	//to get all the parameters data from DB in every 10 sec
	$scope.getData();	
	
	compInterval=setInterval(function(){
		$scope.getData();
	}, 1000*60);
	intervalsList.push(compInterval);	

}).controller('compressDetailsController',function($scope,GensetService,$state,MainService){

	$scope.chartParams = {
		title : "Equipment Specifications",
		subtitle:"Compressor",
		downloadEnabled: true,
		downloadTitle: "Download Operation Manual"
	};
		


	
	$scope.downloadFile = function(){
		MainService.downloadFile($state.params.id);
	}
	
	GensetService.getGensetSpecifications($state.params.id).then(function(data){
		$scope.mudpumpDetails=data;		
	},function(err){
		console.log(err.error_message);		
	});
	
	
}).controller('compressIncidentLogController',function($scope,$rootScope,MainService,$state){
	$scope.chartParams = {
		title : "Alarm Log"
	};
	$scope.compIncDetails = [];
	$scope.allClosed = true;

	$scope.getData = function(){
		MainService.getIncidentDetails('compressor',$state.params.id).then(function(data){
			$scope.compIncDetails = data.filter(function(value){
				return value.INCIDENT_STATUS==0?true:false;
			});
			$scope.allClosed = MainService.closeAllIncidents($scope.compIncDetails);
		},function(data){
			console.log(data.ErrorMessage);		
		});
	}
	
	$scope.getData();
	compressIncidentLogInterval = setInterval(function(){
		$scope.getData();
	},30000);
	
	intervalsList.push(compressIncidentLogInterval);
	
	$scope.openModal = function(option,index){
		$rootScope.$broadcast('openCompModal',[option,index]);
	}
	
	/*$scope.allClosedIncidents = function(){
		if($scope.compIncDetails.length==0)
			return true;
		else if($scope.compIncDetails.filter(function(value){return value.INCIDENT_STATUS==0}).length==0)
			return true;
		else
			return false;
	}*/
	
	$rootScope.$on('savecompIncident',function(event,status,indexVal){
		$scope.compIncDetails[indexVal].INCIDENT_STATUS = status;
		$scope.allClosed = MainService.closeAllIncidents($scope.compIncDetails);
	});
})
.controller('compEventLogController',function($scope,$state,$rootScope,MainService){
	$scope.chartParams = {
		title: "Event Feed",
		subtitle:'LAST 10',
		linkEnabled: true,
		linkTitle: "View Alarms",
		modalId: "#compModal",
		currentView: 'incidentLog'
	};
	$scope.openModal = function(currentView){
		$rootScope.$broadcast('openCompModalView',currentView);
	}
	
	$scope.tableData = [];
	
	$scope.getData = function(){
		MainService.getEventDetails('compressor',$state.params.id).then(function(data){
			$scope.tableData = data;
		},function(data){
			console.log(data.ErrorMessage);
		});
	}
	$scope.getData();
	compEventLogInterval = setInterval(function(){
		$scope.getData();
	},30000);
	
	intervalsList.push(compEventLogInterval);
}).controller('CompressorEngineCoolantTempCtrl', function($scope, $timeout,$rootScope) {
	$scope.chartParams = {
		title : "Dew Point Temperature",
		subtitle:"LAST UPDATED AT ",
		modalEnabled:false
	}

	$scope.textToInsert = "";
		
	$scope.$on('compParametersData',function(event,data){				
		for(var spect=0;spect<data.length;spect++){
			if($scope.chartParams.title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				$scope.chartParams.title=data[spect].SPEC_DESC+" (°"+data[spect].UOM_QUANTITY_TYPE+")";
				$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
				$scope.textToInsert=(data[spect].ATTR_VALUE).toFixed(2);
				$scope.thresholdValue=" Min: "+data[spect].MIN_VALUE+", Max: "+data[spect].MAX_VALUE;
				break;
				}
		}

		$rootScope.$broadcast('updateChart','');
	});
		
}).controller('CompressorCurrentCtrl', function($scope,$timeout,$rootScope) {
	$scope.chartParams = {
		title : "Motor Current",
		subtitle:"LAST UPDATED AT ",
		modalEnabled:false
	}
	//$scope.middleData="75";
	//$scope.rightData="100.00";
	
	$scope.config = {
		width: "100%",
		height: "100",
		sidefont: "10",
		middlefont: "22",
		id: "svg2",
		min: 0,
		max: 0
	}

	//$scope.middleData="75";
	/*$scope.min=0;
	$scope.max=0;*/

	$scope.$on('compParametersData',function(event,data){	
		
			for(var spect=0;spect<data.length;spect++){
			if($scope.chartParams.title.toString().toLowerCase() == data[spect].SPEC_DESC.toLowerCase()){
				$scope.chartParams.title=data[spect].SPEC_DESC+" ("+data[spect].UOM_QUANTITY_TYPE+")";
				$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
				$scope.middleData=data[spect].ATTR_VALUE;
				$scope.thresholdValueMin="Min: "+data[spect].MIN_VALUE;
				$scope.config.min=data[spect].MIN_VALUE;
				$scope.thresholdValueMax="Max: "+data[spect].MAX_VALUE;
				$scope.config.max=data[spect].MAX_VALUE;
				break;
				}
		}
		//$rootScope.$broadcast('updateChartRadial',[min,max]);
	});
	
}).controller('CompressorOnOffCtrl',
function($scope,$timeout,$rootScope) {
	$scope.chartParams = {
			title: "On/Off Time",
			subtitle: "Hours"
		};
	$scope.chartMargin = {
			left: 50,
			right: 30,
			bottom: 40,
			top: 0
	}
	$scope.yAxisLabelDistance = -15;
	$scope.xAxisLabelDistance = -5;
	
	$scope.yAxisLabel = "Hours";
	$scope.xAxisLabel = "Time";
	
	//$scope.tickValues = [0,1,2,3,4,5,6,7,8,9];
	
	$scope.storeValues = [];
	
	$scope.chartData = [{
		"values": [ ],
		"key": "Hours",
		"color": "rgb(184, 135, 173)"
	}];
	
	
	$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];

	$scope.$on('compParametersData',function(event,data){	
			var noOfTimeStampsToshow=-1;
			var initialNoOfTimeStamps=9;
			var timeStamps=[];
			var values=[];
			
			for(var spect=0;spect<data.length;spect++){
			if($scope.chartParams.title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				$scope.chartParams.title=data[spect].SPEC_DESC;
				$scope.chartData[0].key=data[spect].SPEC_DESC;
				$scope.chartParams.subtitle=data[spect].UOM_QUANTITY_TYPE;
				var time=moment(data[spect].MEASURED_DATE).format("HH:mm:ss");
				timeStamps.push(time);
				values.push([initialNoOfTimeStamps,parseFloat(data[spect].ATTR_VALUE)]);				
				initialNoOfTimeStamps--;
				if(initialNoOfTimeStamps==noOfTimeStampsToshow)
					break;
				}
		}
		$scope.storeValues=timeStamps.sort();
		$scope.chartData[0].values=values.sort();	

		$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
		$rootScope.$broadcast('updateLineChart','onOff');		
	});
	
	$scope.$on('redrawGensetCharts',function(event,mess){
		setTimeout(function(){
			$rootScope.$broadcast('updateLineChart','onOff');
		},1);
	});
	
	$scope.tooltipContentFunction = function(){		
		return function(key,y,e,graph){

			return '<p>'+key+'</p>'+
				   '<p>'+y+'</p>';
		}
	}
	
	$scope.xAxisTickFormatFunction = function(){
		return function(d){
			return $scope.storeValues[d];
		}
	}
	
	$scope.colorFunction = function(){
		return function(d,i){
			return "rgb(1, 184, 170)";
		}
	}
	
}).controller('CompActivityScheduleCtrl',function($scope,GensetService,$state,$rootScope){
	$scope.chartParams = {
		title: "Maintenance Activity Checklist",
		subtitle:'Status'
	}
	$scope.type="D";
	
	
	setTimeout(function(){
		$('#filterGenset li').click(function(){
			$("#filterGenset li.active").removeClass('active');
			$(this).addClass('active');
		});
	},10);
	var selectedType;
	$scope.typeFun=function(type){
selectedType=type;

fetchActivityChecklistData();			
			$rootScope.$broadcast('highlightType',type);

	};			

	compCheckListInterval = setInterval(function(){
		fetchActivityChecklistData();		
		}, 1000*60);		
	intervalsList.push(compCheckListInterval);

function fetchActivityChecklistData(){

		GensetService.getActivityChecklist($state.params.id,selectedType).then(function(data){

			$scope.tableData=data;	
	
			},function(err){
				console.log(err);
			});
	}
	$scope.tableData = [];
	
	// to get Activity checklist data from DB
	$scope.typeFun('DM');
	
	$scope.UpdateStatus=function(index){
		bootbox.confirm("Do you want to close the activity?", function(result) {

			if(result==true){
				var userId=$scope.user.Id;
				//update closing date and last_update_user_id
				GensetService.updateActivityStatus($scope.tableData[index].ACTIVITY_ID,userId).then(function(data){
					$scope.tableData[index].STATUS=1;
				},function(err){
					console.log(err);
				});

				//update closing date in eqip maint table   
			  	GensetService.updateEquipMaintClosingDate($scope.tableData[index].ACTIVITY_ID).then(function(data){
			  	},function(err){
			  		console.log(err);
			  	});
				
				//log event in event table
				GensetService.updateEventLog($scope.tableData[index].ACTIVITY_ID,$state.params.id,$scope.tableData[index].ACTIVITY_DESC).then(function(data){			
				},function(err){
					console.log(err)
				});
				//refresh maint and activity table on ui
				fetchActivityChecklistData();
				$rootScope.$broadcast('refreshMainSch','');
				//If all the status are closed, save a common comment
				GensetService.getActivityChecklist($state.params.id,selectedType).then(function(data){
					var dataLength=data.length;
					var statusAll=1;
					for(var check=0;check<dataLength;check++){
						if(data[check].STATUS==0){
							statusAll=0;
							break;
						}
					}
					// if all the checklists are closed, log a common comment
					if(statusAll==1){
						bootbox.prompt("Please enter comment", function(result) {    
            
						  if (result !== undefined && result!=null &&result.length!=0) {  
						  //update comment in eqip maint table
						  	GensetService.updateCheckListComment($scope.tableData[index].ACTIVITY_ID,result).then(function(data){
						  	$rootScope.$broadcast('refreshMainSch','');
						  	},function(err){
						  		console.log(err);
						  	});
                         
						  } 
						});
					}
			},function(err){
				console.log(err);
			});	
						}
			}); 
	}
	
}).controller('CompressorOutletTempCtrl', function($scope,$timeout,$rootScope) {
	
	$scope.chartParams = {
			title: "Compressor Outlet Temperature",
			subtitle:"LAST UPDATED AT ",
		modalEnabled:false
		};
		
	$scope.chartMargin = {
			left: 50,
			right: 30,
			bottom: 30,
			top: 0
	}
	$scope.yAxisLabelDistance = -15;
	$scope.xAxisLabelDistance = -15;
	
	$scope.yAxisLabel = "°C";
	$scope.xAxisLabel = "Time";
	
	//$scope.tickValues = [0,1,2,3,4,5,6,7,8,9];
	
	$scope.storeValues = [];
	
	$scope.chartData = [{
		"values": [],
		"key": "Fuel Consumption Rate",
		"color": "rgb(184, 135, 173)"
	},{
		"values": [],
		"key": "Min",
		"color": "rgb(255,100,100)",
		 "classed": 'dashed'
	},{
		"values": [],
		"key": "Max",
		"color": "rgb(255,100,100)",
		 "classed": 'dashed'
	}];
	
	
	$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];

var title=$scope.chartParams.title;
	$scope.$on('compParametersData',function(event,data){	
			var noOfTimeStampsToshow=-1;
			var initialNoOfTimeStamps=9;
			var timeStamps=[];
			var values=[];
			var minValue=[];
			var maxValue=[];
			var flag=0;
			for(var spect=0;spect<data.length;spect++){
			if(title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				if(flag==0){

					$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
					flag++;
				}				
				$scope.chartData[0].key=data[spect].SPEC_DESC;
				var time=moment(data[spect].MEASURED_DATE).format("HH:mm:ss");
				timeStamps.push(time);
				min=data[spect].MIN_VALUE;
				max=data[spect].MAX_VALUE;
				minValue.push([initialNoOfTimeStamps,min]);
				maxValue.push([initialNoOfTimeStamps,max]);
				values.push([initialNoOfTimeStamps,parseFloat(data[spect].ATTR_VALUE)]);				
				initialNoOfTimeStamps--;
				if(initialNoOfTimeStamps==noOfTimeStampsToshow){
					$scope.chartParams.title=data[spect].SPEC_DESC+" (°"+data[spect].UOM_QUANTITY_TYPE+")";	
					break;		
				}		
					
				}
		}
		$scope.storeValues=timeStamps.sort();
		$scope.chartData[0].values=values;
		$scope.chartData[1].values=minValue;	
		$scope.chartData[2].values=maxValue;	
		$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
		$rootScope.$broadcast('updateLineChart','oilFlowLine');		
	});
	
	$scope.$on('redrawGensetCharts',function(event,mess){
		setTimeout(function(){
			$rootScope.$broadcast('updateLineChart','oilFlowLine');
		},1);
	});
	
	$scope.tooltipContentFunction = function(){		
		return function(key,y,e,graph){

			return '<p>'+key+'</p>'+
				   '<p>'+y+'</p>';
		}
	}
	
	$scope.xAxisTickFormatFunction = function(){
		return function(d){
			return $scope.storeValues[d];
		}
	}
	
	$scope.colorFunction = function(){
		return function(d,i){
			return "rgb(1, 184, 170)";
		}
	}	
	
	
}).controller('CompCoolingIn', function($scope,$timeout,$rootScope) {
	$scope.chartParams = {
		title : "Cooling Water In Temperature",
		subtitle:"LAST UPDATED AT ",
		modalEnabled:false
	}
	//$scope.middleData="75";
	//$scope.rightData="100.00";
	
	$scope.config = {
		width: "100%",
		height: "100",
		sidefont: "10",
		middlefont: "22",
		id: "svg3",
		min: 0,
		max: 0
	}

	//$scope.middleData="75";
	/*$scope.min=0;
	$scope.max=0;*/

	$scope.$on('compParametersData',function(event,data){	
		
			for(var spect=0;spect<data.length;spect++){
			if($scope.chartParams.title.toString().toLowerCase() == data[spect].SPEC_DESC.toLowerCase()){
				$scope.chartParams.title=data[spect].SPEC_DESC+" (°"+data[spect].UOM_QUANTITY_TYPE+")";
				$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
				$scope.middleData=data[spect].ATTR_VALUE;
				$scope.thresholdValueMin="Min: "+data[spect].MIN_VALUE;
				$scope.config.min=data[spect].MIN_VALUE;
				$scope.thresholdValueMax="Max: "+data[spect].MAX_VALUE;
				$scope.config.max=data[spect].MAX_VALUE;

				break;
				}
		}
		//$rootScope.$broadcast('updateChartRadial',[min,max]);
	});	
		
}).controller('compPressureCtrl',function($scope,$timeout,$rootScope){

$scope.chartParams = {
			title: "Delivery Air Pressure",
			subtitle:"LAST UPDATED AT ",
		modalEnabled:false
		};
	$scope.chartMargin = {
			left: 50,
			right: 30,
			bottom: 30,
			top: 0
	}
	$scope.yAxisLabelDistance = -15;
	$scope.xAxisLabelDistance = -15;
	
	$scope.yAxisLabel = "Bar";
	$scope.xAxisLabel = "Time";
	
	//$scope.tickValues = [0,1,2,3,4,5,6,7,8,9];
	
	$scope.storeValues = [];
	
	$scope.chartData = [{
		"values": [],
		"key": "Fuel Consumption Rate",
		"color": "rgb(184, 135, 173)"
	},{
		"values": [],
		"key": "Min",
		"color": "rgb(255,100,100)",
		 "classed": 'dashed'
	},{
		"values": [],
		"key": "Max",
		"color": "rgb(255,100,100)",
		 "classed": 'dashed'
	}];
	
	
	$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];

var title=$scope.chartParams.title;
	$scope.$on('compParametersData',function(event,data){	
			var noOfTimeStampsToshow=-1;
			var initialNoOfTimeStamps=9;
			var timeStamps=[];
			var values=[];
			var minValue=[];
			var maxValue=[];
			var flag=0;
			for(var spect=0;spect<data.length;spect++){
			if(title.toString().toLowerCase()==data[spect].SPEC_DESC.toLowerCase()){
				if(flag==0){

					$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
					flag++;
				}				
				$scope.chartData[0].key=data[spect].SPEC_DESC;
				var time=moment(data[spect].MEASURED_DATE).format("HH:mm:ss");
				timeStamps.push(time);
				min=data[spect].MIN_VALUE;
				max=data[spect].MAX_VALUE;
				minValue.push([initialNoOfTimeStamps,min]);
				maxValue.push([initialNoOfTimeStamps,max]);
				values.push([initialNoOfTimeStamps,parseFloat(data[spect].ATTR_VALUE)]);				
				initialNoOfTimeStamps--;
				if(initialNoOfTimeStamps==noOfTimeStampsToshow){
					$scope.chartParams.title=data[spect].SPEC_DESC+" ("+data[spect].UOM_QUANTITY_TYPE+")";	
					break;		
				}		
					
				}
		}
		$scope.storeValues=timeStamps.sort();
		$scope.chartData[0].values=values;
		$scope.chartData[1].values=minValue;	
		$scope.chartData[2].values=maxValue;	
		$scope.forceY = [getMin($scope.chartData[0].values),getMax($scope.chartData[0].values)];
		$rootScope.$broadcast('updateLineChart','engineoilPressureLine');		
	});
	
	$scope.$on('redrawGensetCharts',function(event,mess){
		setTimeout(function(){
			$rootScope.$broadcast('updateLineChart','engineoilPressureLine');
		},1);
	});
	
	$scope.tooltipContentFunction = function(){		
		return function(key,y,e,graph){

			return '<p>'+key+'</p>'+
				   '<p>'+y+'</p>';
		}
	}
	
	$scope.xAxisTickFormatFunction = function(){
		return function(d){
			return $scope.storeValues[d];
		}
	}
	
	$scope.colorFunction = function(){
		return function(d,i){
			return "rgb(1, 184, 170)";
		}
	}
	
}).controller('compressorImage',function($scope){
	var threshold={};
	var time="";
	$scope.chartParams = {
		title : "Critical Compressor Parameter",
		subtitle:"Last Updated at"+time
	};
	
	$scope.$on('compParametersData',function(event,mess){

		threshold=mess;	
		if(mess!=undefined&&mess.length!=0){
			time=moment(mess[0].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
		}	
	$scope.chartParams.subtitle="Last Updated at "+time;
	
	$scope.compressorImpParams = [{
		name: 'Motor Current',
		value: parameterValue('Motor Current'),
		posTop: "15em",
		posLeft: "1em",
	warning: checkWarning('Motor Current',parameterValueOnly('Motor Current'))
	},{
		name: 'Dew Point Temperature',
		value: parameterValue('Dew Point Temperature'),
		posTop: "12em",
		posLeft: "23em",
		warning: checkWarning('Dew Point Temperature',parameterValueOnly('Dew Point Temperature'))
	},{
		name: 'Compressor Outlet Temperature',
		value: parameterValue('Compressor Outlet Temperature'),
		posTop: "8em",
		posLeft: "15em",
		warning: checkWarning('Compressor Outlet Temperature',parameterValueOnly('Compressor Outlet Temperature'))
	},{
		name: 'Delivery Air Pressure',
		value: parameterValue('Delivery Air Pressure'),
		posTop: "16em",
		posLeft: "21em",
		warning: checkWarning('Delivery Air Pressure',parameterValueOnly('Delivery Air Pressure'))
	},{
		name: 'Cooling Water In Temp.',
		value: parameterValue('Cooling Water In Temperature'),
		posTop: "23em",
		posLeft: "24em",
		warning: checkWarning('Cooling Water In Temperature',parameterValueOnly('Cooling water in temperature'))
	 }];
	});
	var checkWarning=function(name,value){
		try{
			for(var parameter=0;parameter<threshold.length;parameter++){

			// var secondIndex=value.indexOf(' ');
			// if(secondIndex==-1)
				// secondIndex=value.length;
			value=value.toString().substring(0,value.length);
			valueInNumber=parseFloat(value);
			if(name.toLowerCase()==threshold[parameter].SPEC_DESC.toLowerCase()){
				if(valueInNumber>parseFloat(threshold[parameter].MAX_VALUE)||parseFloat(valueInNumber<threshold[parameter].MIN_VALUE))
					return true;
				else
					return false;
			}
		}
		}catch(err){			
		}

	};
	
	var parameterValue=function(name){
		var flag=false;
		for(var parameter=0;parameter<threshold.length;parameter++){
			if(name.toLowerCase()==threshold[parameter].SPEC_DESC.toLowerCase()){
				return threshold[parameter].ATTR_VALUE.toFixed(2)+" "+threshold[parameter].UOM_QUANTITY_TYPE;
			}
		}
		if(flag==false){
			return 'NA'
		}
	}	
	var parameterValueOnly=function(name){
		for(var parameter=0;parameter<threshold.length;parameter++){
			if(name.toLowerCase()==threshold[parameter].SPEC_DESC.toLowerCase()){

				return threshold[parameter].ATTR_VALUE;
			}
		}
	}	
})
.controller('CompCoolingOutCtrl',function($scope,$timeout,$rootScope){
	$scope.chartParams = {
		title : "Cooling Water Out Temperature",
		subtitle:"LAST UPDATED AT ",
		modalEnabled:false
	}
	//$scope.middleData="75";
	//$scope.rightData="100.00";
	
	$scope.config = {
		width: "100%",
		height: "100",
		sidefont: "10",
		middlefont: "22",
		id: "svgFilteredFuel",
		min: 0,
		max: 0
	}

	//$scope.middleData="75";
	/*$scope.min=0;
	$scope.max=0;*/

	$scope.$on('compParametersData',function(event,data){	
		
			for(var spect=0;spect<data.length;spect++){
			if($scope.chartParams.title.toString().toLowerCase() == data[spect].SPEC_DESC.toLowerCase()){
				$scope.chartParams.title=data[spect].SPEC_DESC+" (°"+data[spect].UOM_QUANTITY_TYPE+")";
				$scope.chartParams.subtitle="LAST UPDATED AT "+moment(data[spect].MEASURED_DATE).format("DD/MM/YYYY HH:mm");
				$scope.middleData=data[spect].ATTR_VALUE;
				$scope.thresholdValueMin="Min: "+data[spect].MIN_VALUE;
				$scope.config.min=data[spect].MIN_VALUE;
				$scope.thresholdValueMax="Max: "+data[spect].MAX_VALUE;
				$scope.config.max=data[spect].MAX_VALUE;
				break;
				}
		}
		//$rootScope.$broadcast('updateChartRadial',[min,max]);
	});	
}).controller('CompMaintenanceCycleCtrl',function($scope,$rootScope,GensetService,$state){
		$scope.chartParams = {
			title : "Maintenance Schedule",
			subtitle : "Last & Upcoming"
		};
		
		$scope.tableHeadData=[{col1:'Maintenance Type','col2':'Last',col3:'Upcoming',col4:'Comment'}];
				
		$scope.tableData=[];
		$scope.rcvHigh="DM";
		
		$rootScope.$on('highlightType',function(event, value){
			
			$scope.rcvHigh=value;
		});
		
		$rootScope.$on('refreshMainSch',function(event,mess){
				fetchMaintenanceScheduleData();
		});

		//to get all the maintenance data 	
		fetchMaintenanceScheduleData();

		compMaintenanceInterval = setInterval(function(){
		fetchMaintenanceScheduleData();		
		}, 1000*60);		
		intervalsList.push(compMaintenanceInterval);

		function fetchMaintenanceScheduleData(){
			GensetService.getMaintenanceScheduleData($state.params.id).then(function(data){
			
			$scope.tableData=[];
			for(var maint=0;maint<data.length;maint++){
				var type;
				var order;
				if(data[maint].Type=="DM"){
					type="Daily (DM)";
					order=0;
				}else if(data[maint].Type=="WM"){
					type="Weekly (WM)";
					order=1;
				}else if(data[maint].Type=="MM"){
					type="Monthly (MM)";
					order=2;
				}else if(data[maint].Type=="QM"){
					type="Quarterly (QM)";
					order=3;
				}else if(data[maint].Type=="HYM"){
					type="Half Yearly (HYM)"
					order=4;
				}else if(data[maint].Type=="YM"){
					type="Yearly (YM)"
					order=5;
				}
				var last;
				var next;
				if(data[maint].last_1!=null){
					last=moment(data[maint].last_1).format("DD/MM/YYYY HH:mm");
				}
				else{
					last="-";
				}
				if(data[maint].next_1!=null){
					next=moment(data[maint].next_1).format("DD/MM/YYYY HH:mm");
				}
				else{
					next="-";
				}
			
				var REMARK="";
				if(data[maint].REMARK==null||data[maint].REMARK.length==0){
					REMARK="-";
				}
				else
					REMARK=data[maint].REMARK;
				jsonObject={"type":type, "last":last, "next":next, "order":order,'high':data[maint].Type,"Comment":REMARK};
				$scope.tableData.push(jsonObject);
			
			}
			
			$scope.tableData.sort(function(a,b){
				return a.order-b.order;
			})

			
		},function(err){
			console.log(err.error_message);
		});
		}

}).controller('CompMaintenanceBreakdownCtrl',function($scope,$state,GensetService,$rootScope){
	$scope.chartParams = {
			title : "Planned Vs Unplanned Summary",
			subtitle : "Last 6 Months",
			linkTitle:"Maintenance History",
			linkEnabled:true,						
			currentView: 'maintenanceHistory'
		}
	$scope.openModal = function(currentView){
			$rootScope.$broadcast('openCompModalView',currentView);
		}
		var months=[{mon:"Jan",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Feb",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Mar",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Apr",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"May",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Jun",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Jul",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Aug",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Sep",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Oct",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Nov",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''},
					{mon:"Dec",visible:false,backgroundcolor:'',visibleBD:'',backgroundcolorBD:'',PM:'',UPM:''}];
	// to get MaintenanceBreakdownSummary
	$scope.monthlyData=[];
	GensetService.getMaintenanceBreakdownSummary($state.params.id).then(function(data){
		if(data!=undefined&&data.length!=0){


			for(var month=0;month<data.length;month++){
			if(data[month].Type.toLowerCase()=="mm"){
			months[new Date(data[month].next_1).getMonth()].visible=true;
			months[new Date(data[month].next_1).getMonth()].backgroundcolor='rgba(1, 184, 170,0.6)';
			months[new Date(data[month].next_1).getMonth()].PM=data[month].REMARK;

			}
			if(data[month].Type.toLowerCase()=="ubd"){
			//months[new Date(data[month].last_1).getMonth()].visibleBD=true;
			//months[new Date(data[month].last_1).getMonth()].backgroundcolor='rgb(253, 129, 126)';
			months[new Date(data[month].last_1).getMonth()].backgroundcolorBD='rgb(254, 150, 102)';
			months[new Date(data[month].last_1).getMonth()].UPM=data[month].REMARK;

			}
			
		}
		var lastMonth=data[0].CurrentMonth-1;
		var last6thMonth=data[0].CurrentMonth-7;
		$scope.monthlyData=[];
		while(last6thMonth<lastMonth){
			$scope.monthlyData.push(months[last6thMonth]);
			last6thMonth++;
		}
		}
		
		

		
	},function(err){
		console.log(err);
	});
		
}).controller('CompMaintenanceHistoryCtrl',function($scope,$timeout,GensetService,$state,$rootScope){
	$scope.chartParams = {
			title : "Maintenance History"
		}
		$scope.tableHeadData=['Planned Date','Activity Date','Type','Assignee','Closed By','Comment'];
		$scope.tableData=[];
		/*$timeout(function(){
		$(".openStatus:contains('Maintenance History')").click(function(){
			GensetService.getMaintenanceHistory($state.params.id).then(function(data){
				$scope.tableData=data;
			},function(err){
				console.log(err);
			})
	});
	},15);*/

		$rootScope.$on('getMaintHist',function(event,mess){
			fetchMaintenanceHistory(mess[0],mess[1]);

		})

		function fetchMaintenanceHistory(startDate,endDate){

			GensetService.getMaintenanceHistory($state.params.id,startDate,endDate).then(function(data){
				$scope.tableData=data;

				},function(err){
				console.log(err);
				});	
		}


	$scope.selectedType="DM";
	$scope.typeFun=function(type){

	 	$scope.selectedType=type;

	};
	
	$scope.typeFun($scope.selectedType);


}).controller('CompModalController',function($scope,$rootScope,MainService,$timeout){
	$rootScope.$on('openCompModal',function(event,mess){
		$scope.equipId = mess[0].RIG_EQUIPMENT_ID;
		$scope.desc = mess[0].INCIDENT_DESCRIPTION;
		$scope.id = mess[0].EQUIP_INCIDENT_ID;
		$scope.status = mess[0].INCIDENT_STATUS+'';
		$scope.currentIndex = mess[1];
		$('#closeIncidentForm').slideDown(300);
	});
	$scope.modalDate="CompModalCal";
	
	$scope.saveIncident = function(){
		if(parseInt($scope.status)==1){

			MainService.closeIncident($scope.id).then(function(data){

			},function(data){
				console.log(data.ErrorMessage);
			});

			MainService.updateEventLogForIncidents($scope.equipId,$scope.desc).then(function(data){

			},function(err){
				console.log(err.ErrorMessage);
			});
		}
		
		$('#closeIncidentForm').slideUp(300);
		$rootScope.$broadcast('savecompIncident',parseInt($scope.status),$scope.currentIndex);
	}
	
	$('#compModal').on('show.bs.modal',function(){
		$('#closeIncidentForm').hide();
	});
	
	$rootScope.$on('openCompModalView',function(event,mess){
		$scope.currentView = mess;
		if($scope.currentView=="incidentLog"){
			$scope.title="Incident View";
			$scope.subtitle="";
		}
		else if($scope.currentView=="maintenanceHistory"){
			$scope.title="Maintenance History";
			var startDate="";
			  var endDate="";
			  	var startDate1="";
			  var endDate1="";
			$scope.subtitle="From "+startDate+" to "+endDate;	
			dateRangePickerFnct($scope.modalDate,"down","left");
			
			$timeout(function(){	
				var dateObject=$('#'+$scope.modalDate).data('daterangepicker');

				startDate=moment(dateObject.startDate._d).format('DD/MM/YYYY');
				endDate=moment(dateObject.endDate._d).format('DD/MM/YYYY');
				startDate1=moment(dateObject.startDate._d).utc().format('YYYY/MM/DD');
				endDate1=moment(dateObject.endDate._d).utc().format('YYYY/MM/DD');
				var data=[startDate1,endDate1];
				$rootScope.$broadcast('getMaintHist',data);
				$scope.subtitle="From "+startDate+" to "+endDate;
			$('#'+$scope.modalDate).on('apply.daterangepicker', function(ev, picker) {	
			  startDate=moment(picker.startDate._d).format('DD/MM/YYYY');
			  endDate=moment(picker.endDate._d).format('DD/MM/YYYY');
			  startDate1=moment(dateObject.startDate._d).utc().format('YYYY/MM/DD');
				endDate1=moment(dateObject.endDate._d).utc().format('YYYY/MM/DD');
			   // call miantenance data form db for particulat date
			   var data=[startDate1,endDate1];
			   $rootScope.$broadcast('getMaintHist',data);			   
			   $scope.subtitle="From "+startDate+" to "+endDate;
			   $scope.$digest();

			});	
		
		},50);	

	
		}
		$('#compModal').modal('show');
	});
});