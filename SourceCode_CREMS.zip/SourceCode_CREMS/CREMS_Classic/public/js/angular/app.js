angular
  .module('myApp', ['ui.router', 'ngSanitize'])
  .config(function($stateProvider, $urlRouterProvider, $httpProvider) {
    $httpProvider.interceptors.push(function() {
      return {
        request: function(config) {
          if (config.method === 'GET') {
            config.params = config.params || {};
            config.params.ts = Date.now();
          }
          return config;
        },
      };
    });

    $urlRouterProvider.otherwise('/');

    //Changes to URL Routing/View Injection
    $stateProvider
      .state('app', {
        url: '/',
        views: {
          content: {
            template: '<div></div>',
          },
        },
      })
      .state('app.login', {
        url: '/login',
        views: {
          'content@': {
            templateUrl: 'partials/loginPage.html',
            controller: 'LoginController',
          },
        },
      })
      .state('app.dashboard', {
        url: 'dashboard',
        views: {
          'content@': {
            templateUrl: 'partials/dashboard.html',
          },
        },
      })
      .state('app.dashboard.area', {
        url: '/area',
        params: {
          id: null,
          name: null,
        },
        views: {
          '': {
            controller: 'AreaController',
            templateUrl: 'partials/area.html',
          },
        },
      })
      .state('app.dashboard.rig', {
        url: '/rig',
        params: {
          name: null,
          id: null,
        },
        views: {
          '': {
            controller: 'RigController',
            templateUrl: 'partials/rig.html',
          },
        },
      })
      .state('app.dashboard.equipment', {
        url: '/equipment',
        params: {
          name: null,
          id: null,
        },
        views: {
          '': {
            controller: 'EquipmentController',
            templateUrl: 'partials/equipmentMonitor.html',
          },
        },
      })
      .state('app.incidents', {
        url: 'incidents',
        views: {
          'content@': {
            controller: 'AllIncidentsController',
            templateUrl: 'partials/incidents.html',
          },
        },
      })
      .state('app.events', {
        url: 'events',
        views: {
          'content@': {
            controller: 'AdminEventsController',
            templateUrl: 'partials/adminEvents.html',
          },
        },
      })
      .state('app.addition', {
        url: 'addition',
        views: {
          'content@': {
            controller: 'AdditionController',
            templateUrl: 'partials/addition.html',
          },
        },
      })
      .state('app.addition.areamaster', {
        url: '/areamaster',
        views: {
          '': {
            controller: 'AreaMasterController',
            templateUrl: 'partials/simpleMasterTemplate.html',
          },
        },
      })
      .state('app.addition.assetmaster', {
        url: '/assetmaster',
        views: {
          '': {
            controller: 'AssetMasterController',
            templateUrl: 'partials/simpleMasterTemplate.html',
          },
        },
      })
      .state('app.addition.wellmaster', {
        url: '/wellmaster',
        views: {
          '': {
            controller: 'WellMasterController',
            templateUrl: 'partials/simpleMasterTemplate.html',
          },
        },
      })
      .state('app.addition.rigmaster', {
        url: '/rigmaster',
        views: {
          '': {
            controller: 'RigMasterController',
            templateUrl: 'partials/simpleMasterTemplate.html',
          },
        },
      })
      .state('app.addition.equipmentmaster', {
        url: '/equipmentmaster',
        views: {
          '': {
            controller: 'EquipmentMasterController',
            templateUrl: 'partials/equipmentMaster.html',
          },
        },
      })
      .state('app.addition.activitymaster', {
        url: '/activitymaster',
        views: {
          '': {
            controller: 'ActivityMasterController',
            templateUrl: 'partials/activityMaster.html',
          },
        },
      })
      .state('app.addition.usermaster', {
        url: '/usermaster',
        views: {
          '': {
            controller: 'UserMasterController',
            templateUrl: 'partials/userMaster.html',
          },
        },
      })
      .state('app.addition.sensormaster', {
        url: '/sensormaster',
        views: {
          '': {
            controller: 'SensorMasterController',
            templateUrl: 'partials/sensorMaster.html',
          },
        },
      });
  })
  .controller('MainController', function(
    $scope,
    MainService,
    $rootScope,
    $state
  ) {
    $rootScope.breads = [];
    $scope.masterConfigurations = [
      { name: 'Asset Master', url: 'assetmaster' },
      { name: 'Area Master', url: 'areamaster' },
      { name: 'Rig Master', url: 'rigmaster' },
      { name: 'Well Master', url: 'wellmaster' },
      { name: 'Equipment Master', url: 'equipmentmaster' },
      { name: 'Maintenance Master', url: 'activitymaster' },
      { name: 'User Master', url: 'usermaster' },
      { name: 'Sensor Master', url: 'sensormaster' },
    ];

    $scope.currentConfigView = '';

    // $rootScope.$watch('breads',function(newVal,oldVal){
    // 	console.log(newVal);
    // },true)

    setTimeout(function() {
      $state.go('app.login', {}, { location: false });
    }, 1);

    if (
      sessionStorage.getItem('user') != undefined &&
      sessionStorage.getItem('user') != 'undefined'
    ) {
      var user = JSON.parse(sessionStorage.getItem('user'));
      $scope.user = user;
      $scope.user.Name = $scope.user.Name.split(' ')[0];
    }

    $scope.$on('setUser', function(event, user) {
      console.log(user);
      sessionStorage.setItem('user', JSON.stringify(user));
      $scope.user = user;
      console.log($scope.user);
      try {
        $scope.user.Name = $scope.user.Name.split(' ')[0];
      } catch (e) {
        $scope.user = null;
      }
    });

    $scope.openBirdEyeView = function() {
      $('#birdEyeModal').modal('show');
      $scope.$broadcast('initiateBird', '');
      $rootScope.$broadcast('overview', '');
    };
    $scope.navigateTo = function(a) {
      MainService.clearArrayIntervals();
      $scope.currentConfigView = a;
      $state.go('app.addition.' + a, {}, { location: false });
    };

    $scope.$on('clearConfigView', function(event, mess) {
      $scope.currentConfigView = '';
    });

    $scope.$on('setConfigView', function(event, mess) {
      $scope.currentConfigView = mess;
    });

    $scope.activate = function(val) {
      MainService.activateHeaderTab(val);
      if (val == 'Dashboard') {
        $('#menuButton').click(function() {
          $('#assetHierarchy').fadeToggle(300);
        });
      }
    };

    $scope.goHomePage = function() {
      MainService.clearArrayIntervals();
      var user = JSON.parse(sessionStorage.getItem('user'));
      //console.log(user);
      switch (user.ROLE_ID) {
        case 1:
          $state.go(
            'app.dashboard.area',
            { id: user.RIG_ID, name: user.owner },
            { location: false }
          );
          break;
        case 2:
          $state.go(
            'app.dashboard.rig',
            { id: user.RIG_ID, name: user.Owner },
            { location: false }
          );
          break;
        case 3:
          $state.go(
            'app.dashboard.equipment',
            { id: user.RIG_ID[0], name: user.Owner[0] },
            { location: false }
          );
          break;
        case 4:
          $state.go('app.addition.assetmaster', {}, { location: false });
          break;
        default:
          break;
      }
    };

    MainService.initialiseOuterClickHide();

    $scope.initialiseDropdownHover = function() {
      MainService.initialiseDropdownHover();
    };

    $scope.goNavigate = function(val) {
      MainService.clearArrayIntervals();

      switch (val) {
        case 'Dashboard':
          $scope.goHomePage();
          break;
        case 'Alarms':
          $state.go('app.incidents', {}, { location: false });
          break;
        case 'Configurator':
          $state.go('app.addition.assetmaster', {}, { location: false });
          break;
        case 'Logs':
          $state.go('app.events', {}, { location: false });
          break;
        default:
          $state.go('app.login', {}, { location: false });
          break;
      }
    };

    $scope.logOut = function() {
      sessionStorage.removeItem('user');
      sessionStorage.removeItem('lastState');
      sessionStorage.removeItem('breads');

      MainService.clearArrayIntervals();

      $state.go('app.login', {}, { location: false });
    };

    $scope.$on('popup', function(event, err, type) {
      $scope.error = err;
      MainService.showError(type);
      //bootbox.alert(err);
    });

    $rootScope.$on('$stateChangeStart', function(
      event,
      toState,
      toParams,
      fromState,
      fromParams
    ) {
      if (toState.name.indexOf('app.addition') == -1) {
        $scope.$emit('clearConfigView');
      }
      if (toState.name.indexOf('app.login') > -1) {
        if (sessionStorage.getItem('user') != null) {
          if (sessionStorage.getItem('lastState') != null) {
            event.preventDefault();
            var s = JSON.parse(sessionStorage.getItem('lastState'));
            if (s.params != null) {
              $state.go(s.state, s.params, { location: false });
            } else {
              $state.go(s.state, {}, { location: false });
            }
          }
        }
      }
    });
  });
