angular.module('myApp').controller('breadcrumbCtrl',function($rootScope,$scope,$state,MainService){	
	
	$rootScope.$on('updateRig',function(event,mess){
		var f = null;
		$rootScope.breads = JSON.parse(sessionStorage.getItem('breads')) || [];
		
		console.log($rootScope.breads);
		
		$.each($rootScope.breads,function(ind,val){
			if(val.type == mess[1]){
				f = ind;
				return false;
			}
		})

		if(f==null)
			$rootScope.breads.push(mess[0]);
		else
			$rootScope.breads.splice(f,$rootScope.breads.length,mess[0]);

		sessionStorage.setItem('breads',JSON.stringify($rootScope.breads) || JSON.stringify([]));
	});

	$rootScope.$on('clearRig',function(event,mess){
		
		$rootScope.breads = JSON.parse(sessionStorage.getItem('breads')) || [];
		$rootScope.breads=[];
		sessionStorage.setItem('breads',JSON.stringify($rootScope.breads) || JSON.stringify([]));
	});
	
	$scope.clearBreadCrum=function(index,bread){
		
		$rootScope.breads = JSON.parse(sessionStorage.getItem('breads')) || [];
		$rootScope.breads.splice(index,$rootScope.breads.length);
		sessionStorage.setItem('breads',JSON.stringify($rootScope.breads) || JSON.stringify([]));
		MainService.clearArrayIntervals();
		$state.go(bread.url,bread.params,{location: false});			
	}
	
	// $rootScope.$on('addCrumb',function(event,mess){
	// 	var f = null;
	// 	$rootScope.breads = JSON.parse(sessionStorage.getItem('breads')) || [];
	// 	$.each($rootScope.breads,function(ind,val){
	// 		if(val.type == mess[1]){
	// 			f = ind;
	// 			return false;
	// 		}
	// 	})
		
	// 	if(f==null)
	// 		$rootScope.breads.push(mess[0]);
	// 	else
	// 		$rootScope.breads.splice(f,$rootScope.breads.length,mess[0]);

	// 	sessionStorage.setItem('breads',JSON.stringify($rootScope.breads) || JSON.stringify([]));
	// });
	
}).controller('birdEyeViewController1',function($scope,MainService){
	//state 
	//0 for off
	// 1 for on
	// 2 for alarm 

	$scope.overlayData = MainService.getDescription();

	var equipmentPositions = {
		"Generator": {top: "26em",left: "12em"},
		"Mud Pump": {top: "24em",left: "6em"},
		"Agitator": {top: "20em",left: "10em"},
		"Shaker": {top: "20em",left: "18em"},
		"Drawworks": {top: "24em",left: "20em"}
	}

	$scope.overlayData = $scope.overlayData.map(function(v){
		v.type = v.value.charAt(0);
		v.positions = equipmentPositions[v.value];
		v.show = false;
		return v;
	})

	$scope.initiateBird = function(){
		var user = JSON.parse(sessionStorage.getItem('user'));
		
		if(user != undefined && user != null){
			$scope.role = user.ROLE_ID;
			
			$scope.id = user.RIG_ID;

			if(user.ROLE_ID == 1){
				$scope.getData('area',user.RIG_ID);
				$scope.getAllRigsForArea($scope.id);
			}else if(user.ROLE_ID == 2){
				$scope.type = user.Owner;
				$scope.getData('rig',user.RIG_ID,user.Owner);
			}
		}
	}

	$scope.$on('initiateBird',function(event,mess){
		$scope.initiateBird();
	});

	$scope.getData = function(type,id,name){
		if(type == 'rig'){
			$scope.type = name;
		}else if(type == 'area'){
			$scope.type = 'All Rigs';
		}
		MainService.getBirdEyeViewData(type,id).then(function(data){
			if(data != undefined && data != null && data.constructor === Array && data.length > 0){
				var uniqueTypes = [];
				$scope.birdTable = data;
				
				$.each($scope.birdTable,function(i,v){
					if($.inArray(v.type,uniqueTypes) == -1){
						uniqueTypes.push(v.type);
					}
				});
				
				$scope.overlayData.map(function(l){
					l.show = $.inArray(l.type,uniqueTypes) > -1;
					return l;
				});

			}else{
				$scope.birdTable = [];
			}
		},function(data){
			console.log(data.ErrorMessage);
		})
	}

	overviewBirdInterval = setInterval(function(){
			
	})

	$scope.getAllRigsForArea = function(id){
		MainService.getAllRigsForArea(id).then(function(data){
			$scope.rigs = data;
		},function(data){
			console.log(data.ErrorMessage);
		})
	}

	$scope.type = "All Rigs";
})
.controller('menuCtrl',function($scope,$rootScope,DropDownService,$state,MainService,$window){
	$scope.area="";
	$scope.rig="";
	$scope.asset="";
	$scope.model="";
	$scope.ass = "";

	$scope.getData = function(){
		console.log('Getting menu data..');
		DropDownService.getDropDownMenu($scope.user.ROLE_ID).then(function(data){
			
			$scope.data = data;
			$scope.assOptions = [];
			$scope.areaOptions = [];
			$scope.assetOptions = [];
			$scope.rigOptions = [];
			$scope.modelOptions = [];

			var temp = [];
			var coordinates = [];

			$scope.user = JSON.parse(sessionStorage.getItem('user'));

			if(data!=null && data!=undefined && data.constructor===Array && data.length!=0){

				data.filter(function(value){
					$scope.assOptions.filter(function(val){return val.AssetId==value.AssetId}).length==0?$scope.assOptions.push(value):1;
				});
				data.filter(function(value){
					$scope.areaOptions.filter(function(val){return val.AREA_ID==value.AREA_ID}).length==0?$scope.areaOptions.push(value):1;
				});
				data.filter(function(value){
					$scope.rigOptions.filter(function(val){return val.RIG_ID==value.RIG_ID}).length==0?$scope.rigOptions.push(value):1;
				});
				data.filter(function(value){
					$scope.modelOptions.filter(function(val){return val.EQUIPMENT_ID[0]==value.EQUIPMENT_ID[0]}).length==0?$scope.modelOptions.push(value):1;
				});
				data.filter(function(value){
					$scope.assetOptions.filter(function(val){return val==value.DESCRIPTION}).length==0?$scope.assetOptions.push(value.DESCRIPTION):1;
				});

				switch($scope.user.ROLE_ID){
					case 1:
						$scope.area = {
							"AREA_ID": $scope.user.RIG_ID,
							"PREFERRED_NAME": $scope.user.Owner
						};

						var a = $scope.data.filter(function(v){return v.AREA_ID == $scope.user.RIG_ID})[0];

						$scope.ass = {
							"AssetId": a.AssetId,
							"AssetName": a.AssetName
						};

						$scope.setRig();
						break;
					case 2:
						$scope.rig = {
							"RIG_ID": $scope.user.RIG_ID,
							"RIG_NAME": $scope.user.Owner
						};
						var a = $scope.data.filter(function(v){return v.RIG_ID == $scope.user.RIG_ID})[0];

						$scope.area = {
							"AREA_ID": a.AREA_ID,
							"PREFERRED_NAME": a.PREFERRED_NAME
						}
						
						$scope.ass = {
							"AssetId": a.AssetId,
							"AssetName": a.AssetName
						};

						$scope.setAsset();
						break;
					case 3:
						var a = $scope.data.filter(function(v){return v.EQUIPMENT_ID[0] == $scope.user.RIG_ID[0]})[0];

						$scope.area = {
							"AREA_ID": a.AREA_ID,
							"PREFERRED_NAME": a.PREFERRED_NAME
						}

						$scope.rig = {
							"RIG_ID": a.RIG_ID,
							"RIG_NAME": a.RIG_NAME
						}
						
						$scope.ass = {
							"AssetId": a.AssetId,
							"AssetName": a.AssetName
						};

						$scope.setAsset();
					case 4:
						break;
					default: 
						break;
				}	
			}
		},function(data){
			console.log(data);
		});
	}

	$scope.getData();

	menuInterval = setInterval(function(){
		$scope.getData();
	},30 * 1000);

	intervalsList.push(menuInterval);

	$scope.setArea=function(){
		if($scope.user.ROLE_ID < 4){
			$scope.areaOptions=[];
			if($scope.ass!="" && $scope.ass!=null && $scope.ass!=undefined){
				$scope.data.filter(function(value){
					(value.AssetId==($scope.ass).AssetId) ? (($scope.areaOptions.filter(function(val){return val.AREA_ID==value.AREA_ID?true:false;}).length==0)?$scope.areaOptions.push(value):1):1;
				});
			}
			$scope.area="";
			$scope.rig = '';
			$scope.asset = '';
			$scope.model = '';
		}
	};

	$scope.setRig=function(){
		
		if($scope.user.ROLE_ID == 1){
			$scope.rigOptions=[];
		
			if($scope.area!="" && $scope.area!=null && $scope.area!=undefined){
				$scope.data.filter(function(value){
					(value.AREA_ID==$scope.area.AREA_ID) ? (($scope.rigOptions.filter(function(val){return val.RIG_ID==value.RIG_ID?true:false;}).length==0)?$scope.rigOptions.push(value):1):1;
				});
			}
			$scope.rig = '';
			$scope.asset = '';
			$scope.model = '';
		}
	};
	
	$scope.setModel=function(){
		$scope.modelOptions=[];
		if($scope.area!="" && $scope.area!=null && $scope.rig!="" && $scope.rig!=null && $scope.asset!="" && $scope.asset!=null){
			$scope.data.filter(function(value){
				(value.DESCRIPTION.toLowerCase()==$scope.asset.toLowerCase() && 
					value.RIG_ID == $scope.rig.RIG_ID && 
					value.AREA_ID == $scope.area.AREA_ID) ?
						(($scope.modelOptions.filter(function(val){return val.EQUIPMENT_ID[0]==value.EQUIPMENT_ID[0]?true:false;}).length==0)?$scope.modelOptions.push(value):1):1;
			});
		}

		$scope.model = '';
		// if(!($scope.user.ROLE_ID >= 3 && $scope.user.ROLE_ID < 4)){
		// 	$scope.modelOptions=[];
		// 	if($scope.area!="" && $scope.area!=null && $scope.rig!="" && $scope.rig!=null && $scope.asset!="" && $scope.asset!=null){
		
		// 		$scope.data.filter(function(value){
		// 			(value.DESCRIPTION.toLowerCase()==$scope.asset.toLowerCase() && 
		// 				value.RIG_ID == $scope.rig.RIG_ID && 
		// 				value.AREA_ID == $scope.area.AREA_ID) ?
		// 					(($scope.modelOptions.filter(function(val){return val.EQUIPMENT_ID[0]==value.EQUIPMENT_ID[0]?true:false;}).length==0)?$scope.modelOptions.push(value):1):1;
		// 		});
		
		// 	}
		// 	$scope.model = '';
		// }
	};
	
	$scope.setAsset=function(){
		//if(!($scope.user.ROLE_ID >= 2 && $scope.user.ROLE_ID < 4)){
			$scope.assetOptions=[];
			if($scope.area!="" && $scope.rig!="" && $scope.ass!="" && 
				$scope.area!=null && $scope.rig!=null && $scope.ass!=null &&
				$scope.area!=undefined && $scope.rig!=undefined && $scope.ass!=undefined){
				var c = $scope.data.filter(function(value){
					return value.AREA_ID == $scope.area.AREA_ID && value.RIG_ID == $scope.rig.RIG_ID && value.ASSET_ID == $scope.ass.AssetId;
				});

				if($scope.user.ROLE_ID == 3){
					c = c.filter(function(t){
						return $.inArray(t.EQUIPMENT_ID[0],$scope.user.RIG_ID) > -1;
					})
				}

				$.each(c,function(index,value){
					$.inArray(value.DESCRIPTION , $scope.assetOptions)==-1?$scope.assetOptions.push(value.DESCRIPTION):1;
				})
			}
			$scope.asset = '';
			$scope.model = '';
		//}
	};
	
	 $scope.menuSubmit=function(){
		 $('#assetHierarchy').toggle();
		 MainService.clearArrayIntervals();
		  if($scope.area!=""&&$scope.rig!=""&&$scope.model!=""&&$scope.asset!="" && 
				$scope.area!=null && $scope.rig!=null && $scope.model!=null && $scope.asset!=null){
				$rootScope.$broadcast('addCrumb',[{'name':$scope.rig.RIG_NAME,'url':'app.dashboard.rig','params': {id: $scope.rig.RIG_ID,name: $scope.rig.RIG_NAME},'type': 'rig'},'rig'])
				var url = "app.dashboard.equipment";
				$state.go(url,{id: $scope.model.EQUIPMENT_ID,name: $scope.model.EQUIPMENT_NAME},{location: false,reload: true});
		 }else if($scope.area!=""&&$scope.rig!="" && $scope.area!=null && $scope.rig!=null)
			  $state.go('app.dashboard.rig',{id: $scope.rig.RIG_ID,name: $scope.rig.RIG_NAME},{location: false,reload: true});
		  else if($scope.area!="" && $scope.area!=null)
			  $state.go('app.dashboard.area',{id: $scope.area.AREA_ID,name: $scope.area.PREFERRED_NAME},{location: false,reload: true});
	 }

	 $scope.menuReset = function(){
		switch($scope.user.ROLE_ID){
			case 1:
				$scope.rig="";
				$scope.asset="";
				$scope.model="";
				break;
			case 2:
				$scope.asset="";
				$scope.model="";
				break;
			case 3:
				$scope.asset="";
				$scope.model="";
				break;
			default:
				$scope.rig="";
				$scope.asset="";
				$scope.model="";
				break;
		}
	 }
})

// function dateRangePickerFnct(modalDate,drop,open){
	
// 	setTimeout(function(){
// 		function getDaysInMonth(m, y)
// 		{
// 		    // months in JavaScript start at 0 so decrement by 1 e.g. 11 = Dec
// 		    //--m;

// 		    // if month is Sept, Apr, Jun, Nov return 30 days
// 		    if( /8|3|5|10/.test( m ) ) return 30;

// 		    // if month is not Feb return 31 days
// 		    if( m != 1 ) return 31;

// 		    // To get this far month must be Feb ( 1 )
// 		    // if the year is a leap year then Feb has 29 days
// 		    if( ( y % 4 == 0 && y % 100 != 0 ) || y % 400 == 0 ) return 29;

// 		    // Not a leap year. Feb has 28 days.
// 		    return 28;
// 		}
		
// 		function maxDate(){
// 			var date=new Date().getDate();
// 			var month=new Date().getMonth()+1;
// 			var year=new Date().getFullYear();
// 			var maxDate=month+"/"+date+"/"+year;
		
// 			return maxDate;
// 		}
		
// 		$(function() {
// 			$('.'+modalDate).eq(1).daterangepicker({
// 			    "ranges": {
// 			        "Today": [
// 			            $.now(),
// 			            $.now()
// 			        ],
// 			        "Yesterday": [
// 			             $.now()-86400*1000,
// 			             $.now()-86400*1000
// 			        ],
// 			        "Last 7 Days": [
// 			             $.now()-86400*1000*6,
// 			             $.now()
// 			        ],
// 			        "Last 30 Days": [
// 			            $.now()-86400*1000*29,
// 			            $.now()
// 			        ],
// 			        "This Month": [			                             
// 			            new Date().setDate(1),
// 			            new Date().setDate(getDaysInMonth(new Date().getMonth(),new Date().getFullYear()))
// 			        ],
// 			        "Last Month": [			         
// 			        	date=new Date().setMonth(new Date().getMonth()-1,1),
// 			            new Date().setMonth(new Date().getMonth()-1,getDaysInMonth(new Date().getMonth()-1,new Date().getFullYear()))
// 			        ]
// 			    },
// 			    "alwaysShowCalendars": true,
// 			    "startDate": $.now()-86400*1000*7,
// 			    "endDate": $.now(),
// 			    "drops":  "down",
// 			    "opens": "center",
// 			    "maxDate": maxDate()
// 			});		  
// 			$('.'+modalDate).eq(0).daterangepicker({
// 			    "ranges": {
// 			        "Today": [
// 			            $.now(),
// 			            $.now()
// 			        ],
// 			        "Yesterday": [
// 			             $.now()-86400*1000,
// 			             $.now()-86400*1000
// 			        ],
// 			        "Last 7 Days": [
// 			             $.now()-86400*1000*6,
// 			             $.now()
// 			        ],
// 			        "Last 30 Days": [
// 			            $.now()-86400*1000*29,
// 			            $.now()
// 			        ],
// 			        "This Month": [			                             
// 			            new Date().setDate(1),
// 			            new Date().setDate(getDaysInMonth(new Date().getMonth(),new Date().getFullYear()))
// 			        ],
// 			        "Last Month": [			         
// 			        	date=new Date().setMonth(new Date().getMonth()-1,1),
// 			            new Date().setMonth(new Date().getMonth()-1,getDaysInMonth(new Date().getMonth()-1,new Date().getFullYear()))
// 			        ]
// 			    },
// 			    "alwaysShowCalendars": true,
// 			    "startDate": $.now()-86400*1000*7,
// 			    "endDate": $.now(),
// 			    "drops":  drop,
// 			    "opens": open,
// 			    "maxDate": maxDate()
// 			});		  
// 		});
		
// 	},2000,false);	
// };

var intervalsList = [];

function dateRangePickerFnct(modalDate,drop,open,maxDateGiven){
	setTimeout(function(){
		function getDaysInMonth(m, y)
		{
		    // months in JavaScript start at 0 so decrement by 1 e.g. 11 = Dec
		    //--m;

		    // if month is Sept, Apr, Jun, Nov return 30 days
		    if( /8|3|5|10/.test( m ) ) return 30;

		    // if month is not Feb return 31 days
		    if( m != 1 ) return 31;

		    // To get this far month must be Feb ( 1 )
		    // if the year is a leap year then Feb has 29 days
		    if( ( y % 4 == 0 && y % 100 != 0 ) || y % 400 == 0 ) return 29;

		    // Not a leap year. Feb has 28 days.
		    return 28;
		}
		
		function maxDate(){
			if(maxDateGiven == "all"){
				return maxDateGiven;
			}
			var date=new Date().getDate();
			var month=new Date().getMonth()+1;
			var year=new Date().getFullYear();
			var maxDate=month+"/"+date+"/"+year;
		
			return maxDate;
		}
		
		var datePickerConfig = {
			    "ranges": {
			        "Today": [
			            $.now(),
			            $.now()
			        ],
			        "Yesterday": [
			             $.now()-86400*1000,
			             $.now()-86400*1000
			        ],
			        "Last 7 Days": [
			             $.now()-86400*1000*6,
			             $.now()
			        ],
			        "Last 30 Days": [
			            $.now()-86400*1000*29,
			            $.now()
			        ],
			        "This Month": [			                             
			            new Date().setDate(1),
			            new Date().setDate(getDaysInMonth(new Date().getMonth(),new Date().getFullYear()))
			        ],
			        "Last Month": [			         
			        	date=new Date().setMonth(new Date().getMonth()-1,1),
			            new Date().setMonth(new Date().getMonth()-1,getDaysInMonth(new Date().getMonth()-1,new Date().getFullYear()))
			        ]
			    },
			    "alwaysShowCalendars": true,
			    "startDate": moment().subtract(29, 'days'),
			    "endDate": moment(),
			    "drops":  drop,
				"opens": open
			    // "opens": open,
			    // "maxDate": maxDate()
			};
			
			if(maxDate() != 'all'){
				datePickerConfig["maxDate"] = maxDate();
			}
		$(function() {
			$('#'+modalDate).eq(0).daterangepicker(datePickerConfig);		  
		});
	},20,false);
}