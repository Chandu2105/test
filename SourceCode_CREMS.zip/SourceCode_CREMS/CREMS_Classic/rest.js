var request = require('request');
var proxyUrl = "http://Rahul_Nag@infosys.com:zephyr@12@10.68.248.98:80";

var httpGet = function(url,resp){
	
	var options = {
		url: url,
		headers: {
			'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.151 Safari/535.19'
		},
		proxy: proxyUrl
	}
	
	var callback = function (error, response, body) {
	  if (!error && response.statusCode == 200) {
		
		resp.send(body);
	  }
	}
	
	request(options,callback);
}

exports.httpGet = httpGet;