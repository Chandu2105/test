Steps to Restore data.

1. Restore postgres backup file - DOFIntegrated_tar.backup
2. Run UUID Script
3. Run remaining two scripts 