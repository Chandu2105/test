-- Table: sensor_attribute_audit

-- DROP TABLE sensor_attribute_audit;

CREATE TABLE sensor_attribute_audit
(
  audit_id serial NOT NULL,
  operation character varying,
  processed character varying,
  sensor_attr_id bigserial NOT NULL,
  attr_id bigint NOT NULL,
  sensor_id character varying(1000) NOT NULL,
  minimum_deviation bigint,
  maximum_deviation bigint,
  average_deviation bigint,
  minimum_threshold bigint,
  maximum_threshold bigint,
  attr_uom bigint,
  average_value bigint,
  tenant_id bigint,
  CONSTRAINT sensor_attribute_audit_pkey PRIMARY KEY (audit_id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE sensor_attribute_audit
  OWNER TO postgres;



-- Function: process_sensor_attribute_audit()

-- DROP FUNCTION process_sensor_attribute_audit();

CREATE OR REPLACE FUNCTION process_sensor_attribute_audit()
  RETURNS trigger AS
$BODY$

    BEGIN

        -- make use of the special variable TG_OP to work out the operation.


        IF (TG_OP = 'UPDATE') THEN

            INSERT INTO sensor_attribute_audit SELECT nextval('sensor_attribute_audit_audit_id_seq'),'U','N', NEW.*;

            RETURN NEW;

        ELSIF (TG_OP = 'INSERT') THEN

            INSERT INTO sensor_attribute_audit SELECT nextval('sensor_attribute_audit_audit_id_seq'),'I','N', NEW.*;

            RETURN NEW;

        END IF;

        RETURN NULL; -- result is ignored since this is an AFTER trigger

    END;

$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION process_sensor_attribute_audit()
  OWNER TO postgres;


DROP TRIGGER IF EXISTS sensor_audit ON sensor_attribute;
CREATE TRIGGER  sensor_audit
AFTER INSERT OR UPDATE OR DELETE ON sensor_attribute
    FOR EACH ROW EXECUTE PROCEDURE process_sensor_attribute_audit();