CREATE OR REPLACE FUNCTION equipment_incident_insert()
  RETURNS trigger AS
$BODY$

    BEGIN

        -- make use of the special variable TG_OP to work out the operation.

       IF(TG_OP = 'INSERT') THEN

            INSERT INTO equipment_incident 
            (rig_equipment_id, incident_datetime, incident_description,incident_assignee_comment,incident_assignee_id, incident_status,equip_incident_id, tenant_id,incident_type)
	    VALUES 
            (NEW.rig_equipment_id,NEW.event_datetime,NEW.event_desc,'',1,0, nextval('equipment_incident_equip_incident_id_seq'),1,'S');

            RETURN NEW;

        END IF;

        RETURN NULL; 

    END;

$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION equipment_incident_insert()
  OWNER TO postgres;


DROP TRIGGER IF EXISTS equipment_incident_insert_trigger ON equipment_event_log;
CREATE TRIGGER  equipment_incident_insert_trigger
AFTER INSERT OR UPDATE OR DELETE ON equipment_event_log
    FOR EACH ROW EXECUTE PROCEDURE equipment_incident_insert();
